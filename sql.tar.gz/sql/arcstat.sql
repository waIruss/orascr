set line 250 pagesize 300
set verify off
set termout off
def DT_FMT_ISO_S="YYYY-MM-DD"

col day new_val day noprint
col host new_val host noprint
col inst_name new_val inst_name noprint
select to_char(sysdate-1,'&DT_FMT_ISO_S') day,host_name as host,instance_name as inst_name from v$instance;
set termout on
set feedback on

ACCEPT day  DEFAULT '&day'  PROMPT 'Enter date as &&DT_FMT_ISO_S [&day]: '
ACCEPT days  DEFAULT '2'  PROMPT 'Number of days to show [2]: '
ACCEPT group_ DEFAULT 'HH'  PROMPT 'Round to hours [HH] or minutes [MI] - default [HH]: '

col redo_end_time form A16
col total_mb form 999G990D00
col max_mb_sec form 999G990D00
col avg_mb_sec form 999G990D00
col arclogs# form 999G999

with a1 as (
select first_time,next_time,sequence# seq
,blocks*block_size
,round((next_time-first_time)*24*60*60) as ela
,round((blocks*block_size/1024/1024),2) mb
,round((blocks*block_size/1024/1024)/((next_time-first_time)*24*60*60)) as mb_sec
from v$archived_log
where first_time >= to_date('&day','&DT_FMT_ISO_S')
   and next_time <= to_date('&day','&DT_FMT_ISO_S')+&days
   and dest_id=1
)
select
   --trunc(first_time,'&group_')
   to_char(trunc(next_time,'&group_'),'YYYY-MM-DD HH24:MI') redo_end_time
   ,sum(mb) total_mb
   --,(max(next_time)-min(first_time))*24*60*60 ela_sec
   ,round(max(mb/decode(ela,0,1,ela)),2) max_mb_sec
   ,round(avg(mb/decode(ela,0,1,ela)),2) avg_mb_sec
   ,count(*) arclogs#
from a1
group by trunc(next_time,'&group_')
order by 1;

col day clear
col host clear
col inst_name clear

