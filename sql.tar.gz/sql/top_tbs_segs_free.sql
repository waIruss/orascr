------------------------------------------------------------------------------
-- Display top n tablespaces segments + free space in segment
-- Usage: @top_tbs_segs_free <tbs_name> <top_n>
------------------------------------------------------------------------------
set verify off
set line 160
set pagesize 100
col owner form A12
col segment_type form A16
col segment_name form A36
col gb form 999G999G999D00
col free_gb form 999G999G999D00
col pct form 990D00
compute sum of gb on report
compute sum of pct on report
compute sum of free_gb on report
break on report


def TBS_NAME=&1
def TOP_N=&2

with function freebytes(
  p_seg_subtype varchar2,
  p_segment_owner varchar2,
  p_segment_name varchar2,
  p_segment_type varchar2,
  p_partition_name varchar2
 ) return number
 as
 unf number;
 unfb number;
 fs1 number;
 fs1b number;
 fs2 number;
 fs2b number;
 fs3 number;
 fs3b number;
 fs4 number;
 fs4b number;
 full number;
 fullb number;
 l_segment_size_blocks number;
 l_segment_size_bytes number;
 l_used_blocks number;
 l_used_bytes number;
 l_expired_blocks number;
 l_expired_bytes number;
 l_unexpired_blocks number;
 l_unexpired_bytes number;
begin
  if p_seg_subtype='ASSM' then
    dbms_space.space_usage(p_segment_owner,p_segment_name,p_segment_type,unf,unfb,fs1,fs1b,fs2,fs2b,fs3,fs3b,fs4,fs4b,full,fullb,partition_name=>p_partition_name);
    return unfb+fs1b+fs2b*0.25+fs3b*0.5+fs4b*0.75;
  elsif p_seg_subtype='SECUREFILE' then
    dbms_space.space_usage(segment_owner =>p_segment_owner,segment_name => p_segment_name,segment_type => p_segment_type,
                           segment_size_blocks => l_segment_size_blocks,
                           segment_size_bytes => l_segment_size_bytes,
                           used_blocks => l_used_blocks,
                           used_bytes => l_used_bytes,
                           expired_blocks => l_expired_blocks,
                           expired_bytes => l_expired_bytes,
                           unexpired_blocks => l_unexpired_blocks,
                           unexpired_bytes => l_unexpired_bytes
    );
    return l_expired_bytes;
  else
    return 0;
  end if;
end;
select owner, segment_type, segment_name, gb, pct,
  round(freebytes(segment_subtype,owner,seg_name,decode(segment_type,'LOBSEGMENT','LOB',segment_type),partition_name)/1024/1024/1024,2) free_gb
from (
  select
    s.owner
    ,s.segment_type
    ,s.segment_subtype
    ,s.partition_name
    ,s.segment_name as seg_name
    ,case when segment_type='LOBSEGMENT' then (select 'LOB: '||table_name||'.'||column_name from dba_lobs l where l.segment_name=s.segment_name and l.owner=s.owner) else s.segment_name end segment_name
    --,to_char(round(s.bytes/1024/1024,2),'fm999G999G990D00') MB
    ,round(s.bytes/1024/1024/1024,2) GB
    ,round(ratio_to_report(s.bytes) over()*100,2) pct
  from dba_segments s
  where tablespace_name = upper(trim('&TBS_NAME'))
  order by bytes desc
) where rownum <=&TOP_N
/


undef TBS_NAME
undef TOP_N
clear break
clear compute

