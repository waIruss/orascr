set verify off
set line 240
set pagesize 100
col table_name form A30
col partition_name form A20
col ins_per_day form 999G999G999G999
col upd_per_day form 999G999G999G999
col del_per_day form 999G999G999G999
col ins_per_hour form 999G999G999G999
col upd_per_hour form 999G999G999G999
col del_per_hour form 999G999G999G999



select tm.table_name
  ,tm.partition_name
  --  ,tm.inserts
  --  ,tm.updates
  --  ,tm.deletes
  ,to_char(tm.timestamp,'YYYY-MM-DD HH24:MI') tab_mod_tstamp
  ,to_char(ts.last_analyzed,'YYYY-MM-DD HH24:MI') last_analyzed
  ,ts.stattype_locked
  ,ts.user_stats
  --,round(tm.timestamp-ts.last_analyzed)
  ,round(inserts/(tm.timestamp-ts.last_analyzed)) ins_per_day
  ,round(updates/(tm.timestamp-ts.last_analyzed)) upd_per_day
  ,round(deletes/(tm.timestamp-ts.last_analyzed)) del_per_day
  ,round(inserts/(tm.timestamp-ts.last_analyzed)/24) ins_per_hour
  ,round(updates/(tm.timestamp-ts.last_analyzed)/24) upd_per_hour
  ,round(deletes/(tm.timestamp-ts.last_analyzed)/24) del_per_hour
from dba_tab_modifications tm
  , dba_tab_statistics ts
  , dba_tab_partitions tp
where tm.table_owner=ts.owner(+)
  and tm.table_name=ts.table_name(+)
  and nvl(tm.partition_name,'XXX999')=nvl(ts.partition_name(+),'XXX999')
  and tm.table_owner=upper(trim('&table_owner'))
  and tm.table_name=upper(trim('&table_name'))
  and tm.table_owner=tp.table_owner(+)
  and tm.table_name=tp.table_name(+)
  and tm.partition_name=tp.partition_name(+)
order by tp.partition_position nulls first;

