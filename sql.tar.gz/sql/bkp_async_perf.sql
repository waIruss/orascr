set line 240
col type form A7
col status form A8
col filename form A75
col start_time form A12
col close_time form A12
col elapsed form A13
col gb form 999G990D00
col mb_sec form 999G990D00
col io_count form 999G999G990
col io_time_total form A13
col io_time_max_sec form 999G990D000

select
  type
  ,status
  ,filename
  ,to_char(open_time,'MM/DD HH24:MI') start_time
  ,to_char(close_time,'MM/DD HH24:MI') close_time
  ,cast(numtodsinterval(elapsed_time/100,'SECOND') as interval day(1) to second(0)) elapsed
  ,round(bytes/1024/1024/1024,2) gb
  ,round(effective_bytes_per_second/1024/1024,2) mb_sec
  ,io_count
  ,buffer_size
  ,round((short_wait_time_total/decode(short_waits,0,1,short_waits)/100),3) avg_io_time
  ,cast(numtodsinterval(round((short_wait_time_total+long_wait_time_total)/100,2),'SECOND')  as interval day(1) to second(0)) io_time_total
  ,round(greatest(short_wait_time_max,long_wait_time_max)/100,3) io_time_max_sec
from v$backup_async_io
where filename is not null
order by open_time;
