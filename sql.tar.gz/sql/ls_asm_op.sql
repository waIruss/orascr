set line 200 pagesize 200
col dg_name form A8
col oper_type form A10
col state form A5
col power form 99 heading "PWR REQ"
col actual form 99 heading "PWR ACT"
col gb_moved form 999G990D0 heading "Moved GB"
col gb_remaining form 999G990D0 heading "Remaining GB"
col mb_per_sec form 999G990D0 heading "Rate|MB/sec"
col time_remaining form A16
col error_code form A44
col pct_done form 990D0 heading "% DONE"



SELECT dg.name dg_name,
  --Nvl(ao.operation,'-None-') operation,
  nvl(ao.pass,'-none-') oper_type,
  ao.state,
  ao.Power,
  ao.actual,
  round(ao.sofar*dg.allocation_unit_size/1024/1024/1024,2) gb_moved,
  round(ao.est_work*dg.allocation_unit_size/1024/1024/1024,2)-round(ao.sofar*dg.allocation_unit_size/1024/1024/1024,2) gb_remaining,
  round((ao.sofar/decode(ao.est_work,0,1,ao.est_work))*100,2) pct_done,
  round(ao.est_rate*dg.allocation_unit_size/1024/1024/60,2) mb_per_sec,
  cast(numtodsinterval(ao.est_minutes,'MINUTE') as interval day(1) to second(0)) time_remaining,
  ao.error_code
FROM v$asm_operation ao,v$asm_diskgroup dg
WHERE ao.group_number(+)=dg.group_number;

