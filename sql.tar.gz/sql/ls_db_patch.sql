set line 200 pagesize 200
col patch_id form 999999999
col version form a10
col action form a8
col status form a8
col action_time form a16
col psu_ver form a10
col description form a80

select
   patch_id,
   patch_type,
   action,
   status,
   to_char(action_time,'yyyy-mm-dd hh24:mi') action_time,
   description,
   SOURCE_VERSION,
   TARGET_VERSION
from dba_registry_sqlpatch drs
where action = 'APPLY'
  and not exists (select 1 from dba_registry_sqlpatch p where p.patch_uid=drs.patch_uid and p.action='ROLLBACK' and p.status='SUCCESS' and p.install_id > drs.install_id)
order by install_id,action_time;

