-------------------------------------------------------------------------------
-- DESCRIPTION:
--    Display long running operation v$session_longops
-------------------------------------------------------------------------------

set line 240
column sesid format a12 heading "SID,SER"
column status format a10 
column username format a10
column program format a20 truncate
column opname format a13 trunc
column target format a36 trunc
column progress format 900.00 head "PRG%"
column ela format A16 head "ELA"
column eta format A16 head "ETA"
SELECT l.sid||','||l.serial# AS sesid
   , s.status, s.username, s.program, l.opname,l.target, l.sql_id,
   CAST(NumToDSInterval(l.elapsed_seconds,'SECOND') AS INTERVAL DAY(1) TO SECOND(0)) ela,
   CAST(NumToDSInterval(l.time_remaining,'SECOND') AS INTERVAL DAY(1) TO SECOND(0)) eta,
   Round(sofar/totalwork*100,2) AS progress
FROM v$session_longops l, v$session s
WHERE l.time_remaining>0 AND l.sid=s.sid AND l.serial#=s.serial#
ORDER BY sesid;

