--settings taken from UATACP02
--select 'alter profile '||profile||' limit '||resource_name||' '||limit||';' from dba_profiles where profile in ('DEFAULT','USER_PROFILE') order by profile,limit;
@lsprofiles
set echo on
alter profile DEFAULT limit PASSWORD_LOCK_TIME 1;
alter profile DEFAULT limit FAILED_LOGIN_ATTEMPTS 6;
alter profile DEFAULT limit PASSWORD_GRACE_TIME 7;
alter profile DEFAULT limit PASSWORD_VERIFY_FUNCTION NULL;
alter profile DEFAULT limit LOGICAL_READS_PER_SESSION UNLIMITED;
alter profile DEFAULT limit CPU_PER_CALL UNLIMITED;
alter profile DEFAULT limit CPU_PER_SESSION UNLIMITED;
alter profile DEFAULT limit SESSIONS_PER_USER UNLIMITED;
alter profile DEFAULT limit COMPOSITE_LIMIT UNLIMITED;
alter profile DEFAULT limit PRIVATE_SGA UNLIMITED;
alter profile DEFAULT limit INACTIVE_ACCOUNT_TIME UNLIMITED;
alter profile DEFAULT limit PASSWORD_REUSE_MAX UNLIMITED;
alter profile DEFAULT limit PASSWORD_REUSE_TIME UNLIMITED;
alter profile DEFAULT limit PASSWORD_LIFE_TIME UNLIMITED;
alter profile DEFAULT limit CONNECT_TIME UNLIMITED;
alter profile DEFAULT limit IDLE_TIME UNLIMITED;
alter profile DEFAULT limit LOGICAL_READS_PER_CALL UNLIMITED;
alter profile USER_PROFILE limit PASSWORD_LOCK_TIME .0416;
alter profile USER_PROFILE limit FAILED_LOGIN_ATTEMPTS 6;
alter profile USER_PROFILE limit PASSWORD_GRACE_TIME 7;
alter profile USER_PROFILE limit COMPOSITE_LIMIT DEFAULT;
alter profile USER_PROFILE limit LOGICAL_READS_PER_SESSION DEFAULT;
alter profile USER_PROFILE limit PRIVATE_SGA DEFAULT;
alter profile USER_PROFILE limit CPU_PER_CALL DEFAULT;
alter profile USER_PROFILE limit CPU_PER_SESSION DEFAULT;
alter profile USER_PROFILE limit LOGICAL_READS_PER_CALL DEFAULT;
alter profile USER_PROFILE limit SESSIONS_PER_USER DEFAULT;
alter profile USER_PROFILE limit CONNECT_TIME DEFAULT;
alter profile USER_PROFILE limit INACTIVE_ACCOUNT_TIME DEFAULT;
alter profile USER_PROFILE limit PASSWORD_VERIFY_FUNCTION NULL;
alter profile USER_PROFILE limit IDLE_TIME UNLIMITED;
alter profile USER_PROFILE limit PASSWORD_REUSE_MAX UNLIMITED;
alter profile USER_PROFILE limit PASSWORD_LIFE_TIME UNLIMITED;
alter profile USER_PROFILE limit PASSWORD_REUSE_TIME UNLIMITED;
set echo off
@lsprofiles
