set linesize 200 pagesize 600
select * from table(dbms_xplan.display_cursor(null,null,'ALLSTATS LAST'));

