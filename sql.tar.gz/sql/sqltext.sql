def sql_id=&1

set line 200 pagesize 200 verify off long 5000000
col sql_fulltext FORM a140 wor

PROMPT ==========================================================================
PROMPT SQL full text for sql_id=&&sql_id
PROMPT ==========================================================================

SELECT sql_fulltext
from (
select sql_fulltext
FROM v$sql
WHERE sql_id='&&sql_id'
  AND ROWNUM <=1
union all
select sql_text
from dba_hist_sqltext
where sql_id='&&sql_id'
  and rownum<=1
)
where rownum <=1;


undef 1
undef sql_id
