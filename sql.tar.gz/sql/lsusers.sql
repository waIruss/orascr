set line 240 pages 100
col username form A20
col created form A18
col lock_date form A18
col expiration_date form A18
col account_status form A18
col default_tbs form A16
col temp_tbs form A16
col profile form A16
col last_pass_date form A18
set verify off

accept userpattern prompt 'Enter username pattern (default: all): ' default '%'

select username,user_id,
  to_char(created,'YYYY-MM-DD HH24:MI') created,
  account_status,
  to_char(lock_date,'YYYY-MM-DD HH24:MI') lock_date,
  to_char(expiry_date,'YYYY-MM-DD HH24:MI') expiration_date,
  default_tablespace default_tbs,
  temporary_tablespace temp_tbs,
  profile,
  to_char(last_login,'YYYY-MM-DD HH24:MI') last_login,
  to_char(PASSWORD_CHANGE_DATE,'YYYY-MM-DD HH24:MI') last_pass_change
  --(select to_char(max(password_date),'YYYY-MM-DD HH24:MI') from sys.user_history$ uh where uh.user#=dba_users.user_id) last_pass_change
from dba_users
where username like upper('&userpattern')
order by username;

