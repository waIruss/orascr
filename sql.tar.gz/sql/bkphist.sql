set linesize 140
col STATUS form A10
col TIME_TAKEN form A10
col start_time form A22
col IN_TYPE form A15
col OUT_DEV form A10
col SIZE_IN form A10
col SIZE_OUT form A10
col "IN_RATE/sec" form A10
col "OUT_RATE/sec" form A10
set verify off

accept bkptype prompt 'Enter backup type [DB|ARC|%] (default: %): ' default '%'
accept bkpdays prompt 'Enter days to display  (default: 14): ' default '14'


select
  b.status,
  to_char(b.start_time,'YYYY-MM-DD Dy HH24:MI') start_time,
  to_char(b.end_time,'MM-DD HH24:MI') end_time,
  b.time_taken_display           as time_taken,
  b.input_type                   as in_type,
  b.output_device_type           as out_dev,
  b.input_bytes_display          as size_in,
  b.output_bytes_display         as size_out,
  b.input_bytes_per_sec_display  as "IN_RATE/sec",
  b.output_bytes_per_sec_display as "OUT_RATE/sec"
from v$rman_backup_job_details b
where
  (
    b.start_time > (sysdate - &bkpdays)
    and b.input_type like upper('&bkptype%')
  )
order by b.start_time;

