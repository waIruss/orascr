set line 240 pagesize 200 verify off
def owner=&1
def tabname=&2

col index_name form A25
col index_type form A20 trunc
col uniqueness form A10 trunc heading "UNIQ"
col partitioned form A5 heading "Parti|oned"
col num_rows form 999G999G999G999
col clustering_factor form 999G999G999G999 heading "Clustering|factor"
col leaf_blocks form 999G999G999 heading "Leaf blocks"
col distinct_keys form 999G999G999 heading "Distinct|keys"
col blevel form 99 heading "Blev"
col column_name form A16
col column_position form 99 heading "Pos"
col descend form A8 heading "Sort"

break on index_name on index_type on uniqueness on num_rows on clustering_factor on leaf_blocks on distinct_keys on blevel skip 1


PROMPT ==========================================================================
PROMPT Indexes on &owner..&tabname
PROMPT ==========================================================================
SELECT i.index_name,i.index_type,i.partitioned,i.uniqueness,i.num_rows,i.clustering_factor,i.leaf_blocks,i.distinct_keys,i.blevel,
  ic.column_name,ic.column_position,ic.descend
FROM dba_indexes i, dba_ind_columns ic
WHERE i.table_owner=upper('&owner')
  AND i.table_name=upper('&tabname')
  AND i.table_owner=ic.table_owner
  AND i.table_name=ic.table_name
  AND i.index_name=ic.index_name
  AND i.owner=ic.index_owner
ORDER BY i.index_name,ic.column_position;
