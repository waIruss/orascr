set linesize 220 pagesize 800 verif off
col plan_table_output form A200

def sql_id=&1

select child_number, parsing_schema_name,
   cursor(select * from table(dbms_xplan.display_cursor(sql_id, child_number,'TYPICAL PEEKED_BINDS'))) plan 
from v$sql where sql_id = trim('&sql_id'); 


undef sql_id 1
