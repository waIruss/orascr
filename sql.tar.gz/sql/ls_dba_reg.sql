column comp_name format a40
column version format a15
column status format a10
select comp_name,version,status from dba_registry order by comp_name;
