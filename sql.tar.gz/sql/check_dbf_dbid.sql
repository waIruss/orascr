
whenever sqlerror exit 3
declare
  v_cnt number;
begin
  select count(*) into v_cnt from x$kcvfh where fhdbi <> (select dbid from v$database);
  if v_cnt > 0 then
     raise_application_error(-20001,'Foreign DBID found in datafile headers on source DB! Aborting clone!');
  end if;
end;
/
exit;
