set line 200 pagesize 200
col "PROFILE [#USERS]" form A25
col resource_type form A13
col resource_name form A25
col limit form A30

BREAK ON "PROFILE [#USERS]" skip 1 ON RESOURCE_TYPE

select profile
  ||' ['
  ||nvl(usercnt,0)
  ||']' "PROFILE [#USERS]",
  resource_type,
  resource_name,
  limit
from dba_profiles
left outer join
  (
    select profile,
      count(*) usercnt
    from dba_users
    group by profile
  )
  using(profile)
where limit <> 'DEFAULT'
order by decode(profile,'DEFAULT','0',profile),
  resource_type,
  resource_name;


