set line 200
col action form A45
col ela form A20
col start_time form A16
col last_time form A16
col ela form A15
col ESTIMATED_END form A15
col pct_progress form 990D00
col total_prg form 990D00

with act as (
select 10 ord,'START ANONYMISATION' as action, 3 pct from dual union all
select 20 ord,'anon#upd_tab: obj_name' as action, 24 pct from dual union all
select 30 ord,'anon#upd_tab: obj_name_intl' as action, 21 pct from dual union all
select 40 ord,'anon#upd_tab: obj_addr_hist' as action, 12 pct from dual union all
select 50 ord,'anon#upd_tab: obj_addr_hist_invalid' as action, 3 pct from dual union all
select 60 ord,'anon#upd_tab: obj_person_name_hist' as action, 6 pct from dual union all
select 70 ord,'anon#upd_tab: obj_person_name_hist_invalid' as action, 0 pct from dual union all
select 80 ord,'anon#obj_prl' as action, 24 pct from dual union all
select 90 ord,'END ANONYMISATION' as action, 7 pct from dual
),
prg as (
select min(timestp) start_time,max(timestp) last_time
 --,regexp_substr(ctx,'anon#upd_tab: \w+')  action
 ,regexp_substr(ctx,'anon#upd_tab: \w+|anon#obj_prl')  action
 ,max(to_number(regexp_substr(ctx,'(\d+)( of )(\d+)',1,1,'i',1))) cnt
 ,max(to_number(regexp_substr(ctx,'(\d+)( of )(\d+)',1,1,'i',3))) total
from k.anon_log
where
  --trunc(timestp) = trunc(sysdate)
  timestp > (select max(timestp) from k.anon_log where ctx = 'START INSERT APO$ANON_KEY_MAP_OBJ_ID') 
  --trunc(timestp) = to_date('2021-08-25','YYYY-MM-DD')
  and
    (
      ctx like 'anon#upd_tab:%finished%'
      or
      ctx like 'anon#obj_prl%Finished%'
    )
group by regexp_substr(ctx,'anon#upd_tab: \w+|anon#obj_prl')
  --order by timestp desc
union all
select (select min(l2.timestp) from k.anon_log l2 where l2.timestp  >= (select max(timestp) from k.anon_log where ctx = 'START INSERT APO$ANON_KEY_MAP_OBJ_ID')) start_time, timestp last_time,trim(substr(ctx,1,20)) action,1,1
from k.anon_log l where  ctx like 'START ANON%' and timestp > (select max(timestp) from k.anon_log where ctx = 'START INSERT APO$ANON_KEY_MAP_OBJ_ID')
union
select timestp start_time, (select max(l2.timestp) from k.anon_log l2 where l2.timestp between l.timestp and l.timestp + 1),replace(trim(substr(ctx,1,20)),'.'),1,1
from k.anon_log l where  ctx like 'END ANONYMISATION%' and timestp > (select max(timestp) from k.anon_log where ctx = 'START INSERT APO$ANON_KEY_MAP_OBJ_ID')
)
select
  act.action
  ,to_char(start_time,'Mon-DD HH24:MI') start_time
  ,to_char(last_time,'Mon-DD HH24:MI') last_time
  ,nvl(round(cnt/total,4)*100,0) pct_progres
  ,cast(numtodsinterval(last_time-start_time,'DAY') as interval day(2) to second(0)) ela
  --,ratio_to_report((last_time-start_time)*24*60) over()*100
  ,to_char(start_time+(last_time-start_time)/(cnt/total),'Mon-DD HH24:MI') estimated_end
  ,round(sum(nvl(round(cnt/total,4),0)*pct) over(order by start_time),2) total_prg
  --,sum(pct) over( order by start_time)
  --,to_char(start_time+(last_time-start_time)/(cnt/total),'Mon-DD HH24:MI') estimated_end2
  ,
  to_char(
    min(start_time) over(order by start_time)
    +
    numtodsinterval((max(last_time) over(order by start_time)-min(start_time) over(order by start_time))*100
    /round(sum(nvl(round(cnt/total,4),0)*pct) over(order by start_time),2),'DAY')
   ,'Mon-DD HH24:MI') est_total_end
from act left outer join prg on act.action=prg.action
order by start_time,ord;
