set line 220 pagesize 200 verify off

col sid_ser form A10
col username form A10
col program form A20
col osuser_machine form A40 wor
col sql_id form A15
col wait_class_event form A40
col state form A8
col wait_time form 99999
col sec_in_wait form 999G999
col inst_id form 999
col pga_alloc_gb form 990D99

accept userpattern prompt 'Enter username pattern (default: all): ' default '%'
accept progpattern prompt 'Enter program pattern (default: all): ' default '%'
accept serverpattern prompt 'Enter server pattern (default: all): ' default '%'
accept modulepattern prompt 'Enter module pattern (default: all): ' default '%'
accept sql_id prompt 'Enter sql_id pattern (default: all): ' default '%'
accept ifactive prompt 'Display only active sessions? Y/N (default: N): ' default 'N'
accept fgonly prompt 'Display only foreground sessions? Y/N (default: Y): ' default 'Y'


select s.inst_id,s.sid||','||s.serial# sid_ser
  ,s.username
  ,coalesce(rj.job_name,nvl2(bp.name,bp.name||' - '||bp.description,null),s.program) program
  ,osuser||'@'||machine osuser_machine
  ,nvl(sql_id,'P:'||prev_sql_id) sql_id
  ,to_char(logon_time,'YYYY-MM-DD HH24:MI') logon_time
  ,decode(state,'WAITING',wait_class||': '||event,'ON CPU') wait_class_event
  ,state
  ,wait_time
  ,seconds_in_wait sec_in_wait
  ,round(p.pga_alloc_mem/1024/1024/1024,2) pga_alloc_gb
from gv$session s left join gv$process p on(s.inst_id=p.inst_id and s.paddr=p.addr)
left outer join dba_scheduler_running_jobs rj on rj.session_id=s.sid
left outer join v$bgprocess bp on bp.paddr = s.paddr
where (s.type = 'USER' or '&FGONLY' = 'N')
   and (s.username like upper('&userpattern') or trim('&userpattern')='%')
   and (upper(coalesce(rj.job_name,nvl2(bp.name,bp.name||' - '||bp.description,null),s.program)) like upper('&progpattern') or trim('&progpattern')='%')
   and (upper(s.module) like upper('&modulepattern') or trim('&modulepattern')='%')
   and (upper(s.machine) like upper('&serverpattern') or trim('&serverpattern')='%')
   and (s.sql_id like trim('&sql_id') or trim('&sql_id')='%')
   and ( s.status like decode('&ifactive','Y','ACTIVE','N','%ACTIVE%') and (wait_class <> decode('&ifactive','Y','Idle','N','%') or upper('&ifactive') = 'N'))
;

