set line 200 pagesize 200
col group_number form 99 heading "GROUP#"
col name form A8 
col au form A3
col state form A10
col type form A10 heading "REDUNDANCY"
col total_gb form 999G990D0
col free_gb form 999G990D0
col used_gb form 999G990D0
col usable_gb form 999G990D0
col compatible_asm form A12 heading "Compatible|ASM"
col compatible_rdbms form A12 heading "Compatible|RDBMS"
col voting_files form A6 head "VOTING"
col pct_used form 990D0 heading "% USED"

compute sum of total_gb on report
compute sum of free_gb on report
compute sum of usable_gb on report
break on report

SELECT 
  group_number,
  name,
  round(allocation_unit_size/1024/1024)||'M' au,
  state,
  type,
  Round(total_mb/1024,2) total_gb,
  Round((total_mb-free_mb)/1024,2) used_gb,
  Round(free_mb/1024,2) free_gb,
  Round(usable_file_mb/1024,2) usable_gb,
  --Round((total_mb-usable_file_mb)/total_mb*100,1) as pct_used,
  Round((total_mb-usable_file_mb)/(decode(total_mb,0,0.00000000000001,total_mb))*100,1) as pct_used,
  compatibility compatible_asm,
  database_compatibility compatible_rdbms,
  voting_files 
FROM v$asm_diskgroup
order by name;

clear computes
clear breaks
