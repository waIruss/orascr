--------------------------------
-- Export audit data to CSV file
--------------------------------
whenever sqlerror exit
set verify on
set trimspool on
set feedback off
set linesize 10000
set termout off
set echo on
set pagesize 0

column sdate new_val sdate noprint
column edate new_val edate noprint
select trunc(sysdate) edate, trunc(sysdate-1) sdate from dual;

column spool_name NEW_VALUE spool_name NOPRINT
column instance_name NEW_VALUE instance_name NOPRINT
select 'aud_exp_' || instance_name || '_' || host_name || '_' || trunc(sysdate) || '.csv'  spool_name FROM v$instance;
select instance_name from v$instance;

--------------------------------
-- Config
--------------------------------
def DBUSERNAME="(&1)"
def RETENTION_DAYS=60
def PATH=/oracle/&instance_name/dba/aud_exp
--------------------------------
host [ -d "&PATH" ] || mkdir -p &PATH

set markup csv on
spool &PATH/&spool_name
select * from audsys.unified_audit_trail
where event_timestamp between '&sdate' and '&edate'
and dbusername in &DBUSERNAME
order by event_timestamp asc;

spool off
set markup csv off

host find &PATH -type f -name "*.csv" | xargs gzip
host find &PATH -mtime +&RETENTION_DAYS -type f -name "*.csv.gz" -delete

exit
