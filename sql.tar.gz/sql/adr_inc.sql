-------------------------------------------------------------------------------
-- DESCRIPTION:
--    Display recent incident from ADR repositoroy
-- Usage:
--   @sqlmon_rep <sql_id> <sql_exec_id>
-------------------------------------------------------------------------------
set verify off  feedback off 

col err_time form a16
col error form a10
col args form a60
col signalling_component form A16
set line 200

-- optional params
col par1 new_val 1 noprint

select 'dummy' par1 from dual where 1 <> 1;
col nLastLimit new_val nLastLimit noprint
select case when '&1' is not null then '&1' else '10' end nLastLimit from dual;

set feedback 6 termout on
PROMPT ==========================================================================
PROMPT Last &nLastLimit incident(s) registerd in ADR 
PROMPT ==========================================================================

select * 
from (
   select 
     to_char(create_time,'yyyy-mm-dd hh24:mi') err_time
     ,error_facility||'-'||error_number error
     ,'['||error_arg1||'],['||error_arg2||'],['||error_arg3||'],['||error_arg4||'],['||error_arg5||'],['||error_arg6||'],['||error_arg7||']' args
     ,signalling_component
   from v$diag_incident
   order by create_time desc
) where rownum <= &nLastLimit;



undef nLastLimit 1