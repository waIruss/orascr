set line 200
set pagesize 0
set trimspool on
set feedback off
set echo off

--All
prompt [all_db_servers]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%' and sid not like 'APOD%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt


--All Agents
prompt [all_agents_servers]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt



--ASM
prompt [all_asm_servers]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='osm_instance'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'osm_instance'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt

--ACP only
prompt [acp_only]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%'
and (sid like '%ACP%' or sid like '%STR%')
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt


--NON ACP only
prompt [non_acp_only]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%'
and sid not like '%ACP%' 
and sid not like '%STR%'
and sid not like '%APOD%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt


--prod acp only
prompt [prd_acp_only]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%'
and (sid like '%ACP%' or sid like '%STR%')
and sid like '%PRD%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt


--non prod acp only
prompt [non_prd_acp_only]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%'
and sid not like '%PRD%'
and (sid like '%ACP%' or sid like '%STR%')
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt


--PRD NON ACP only
prompt [prd_non_acp_only]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%'
and sid not like '%ACP%'
and sid not like '%STR%'
and sid not like '%APOD%'
and sid like '%PRD%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt


--NON PRD NON ACP only
prompt [non_prd_non_acp_only]
with tgt as (
select
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', '')) as hostname
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  --,t.target_name
  --,t.target_guid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  --lower(replace(upper(t.host_name), '.APOBANK.LAN', ''))
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  host_name||'       #'||sid
from tgt
where sid not like 'RCAT%'
and sid not like '%ACP%'
and sid not like '%STR%'
and sid not like '%APOD%'
and sid not like '%PRD%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt


--single by SID
with tgt as (
select
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  --host_name,count(*)
  --host_name||'       #'||sid
  '['||sid||']'||chr(10)||host_name||'      #'||sid||chr(10)||chr(10)
from tgt
where sid not like 'RCAT%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
--group by host_name having count(*) > 1
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
order by sid
;
prompt
prompt

--By 3letter prefix
with tgt as (
select
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  '['||substr(sid,1,3)||']'||chr(10)||listagg(host_name||'      #'||sid||chr(10)) within group (order by sid)  ||chr(10)||chr(10)
  --'['||sid||']'||chr(10)||host_name||chr(10)||chr(10)
from tgt
where sid not like 'RCAT%'
  --and host_name not in('defrapovl0588.apobank.lan','derlapovl0372.apobank.lan','derlapovl0447.apobank.lan')
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
  and sid not like 'APOD%'
  --and (group_name = 'SIT Databases' or sid like 'SIT%' or sid like 'DEV%')
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
group by substr(sid,1,3)
--order by sid
;
prompt
prompt


--By 6letter prefix
with tgt as (
select
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  '['||regexp_replace(substr(sid,1,6),'[0-9]','')||']'||chr(10)||listagg(host_name||'      #'||sid||chr(10)) within group (order by sid)||chr(10)||chr(10)
  --substr(sid,1,6)
  --,regexp_replace(substr(sid,1,6),'[0-9]','')
from tgt
where sid not like 'RCAT%'
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
  and sid not like 'APOD%'
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
group by substr(sid,1,6)
--order by sid
;
prompt
prompt


--By 6letter prefix
with tgt as (
select
  lower(t.host_name) host_name
  ,min(replace(t.target_name, '.apobank.lan', '')) as sid
  ,grp.group_name
from sysman.mgmt_targets t left outer join
  (select aggregate_target_name group_name,member_target_name target_name,member_target_guid target_guid
  from sysman.MGMT$TARGET_FLAT_MEMBERS where aggregate_target_type='composite' and member_target_type='oracle_database'
  ) grp on t.target_guid=grp.target_guid
where t.target_type = 'oracle_database'
group by
  lower(t.host_name)
  ,grp.group_name
order by 1
)
select
  '['||lower(replace(group_name,' ','_'))||']'||chr(10)||listagg(host_name||'      #'||sid||chr(10)) within group (order by sid)||chr(10)||chr(10)
  --substr(sid,1,6)
  --,regexp_replace(substr(sid,1,6),'[0-9]','')
from tgt
where sid not like 'RCAT%'
  and host_name not in('derlapovl0372.apobank.lan','derlapovl0478.apobank.lan')
  and sid not like 'APOD%'
  --and (group_name = 'UAT Databases' or sid like 'UAT%')
group by lower(replace(group_name,' ','_'))
--order by sid
;
prompt
prompt

exit;



