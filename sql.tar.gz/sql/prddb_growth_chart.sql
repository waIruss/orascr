/*
 * Script for generating DB growth charts for PRD*01 databases from OEM repository 
 * Run on OEM repository db
*/

set linesize 2000 pagesize 0 long 2000000
set termout off
set trimspool on echo off feedback off 
set verify off
set define '&'
set serveroutput on size unlimited
set sqlblanklines on

--defines 
col db_target new_val db_n noprint

SELECT db_target FROM ( 
   SELECT target_name AS db_target 
   FROM sysman.mgmt_targets 
   WHERE target_type='oracle_database'
     AND target_name LIKE 'PRD%01%'
   ORDER BY 1
) WHERE ROWNUM <=1;


--avoid comma as decimal separator in outputs
alter session set nls_numeric_characters='.,';


col bdate new_val bdate noprint
col edate new_val edate noprint
def DT_FMT_REP="YYYY-MM-DD"
def DT_FMT_ISO="YYYY-MM-DD HH24:MI"
var v_db_target varchar2(200)

set termout on

prompt ==================================================================================
prompt Available databases
prompt ==================================================================================

SELECT target_name 
FROM sysman.mgmt_targets 
WHERE target_type='oracle_database'
  AND target_name LIKE 'PRD%01%'
ORDER BY 1;

prompt ==================================================================================
ACCEPT vDbName DEFAULT '&DB_N' PROMPT 'Select database target for analysis [&DB_N] : '
prompt ==================================================================================

begin
   :v_db_target := trim('&vDbName');
end;
/


whenever sqlerror exit


prompt Preparing report, please wait...

declare  
   v_obj_cnt number;
begin
   select count(*) into v_obj_cnt
   from dba_objects 
   where object_name in('MGMT_TARGETS','MGMT$METRIC_DAILY') and owner = 'SYSMAN';
   if v_obj_cnt != 2 then
      raise_application_error(-20101,'SYSMAN.MGMT% objects not avaialable, You must run this script on OEM repository db!');
   end if;    
end;
/    

select 
  to_char(min(rollup_timestamp),'&&DT_FMT_REP') as bdate, 
  to_char(max(rollup_timestamp),'&&DT_FMT_REP') as edate 
from sysman.mgmt$metric_daily;

set termout on


whenever sqlerror continue

set termout off

var stime number
var etime number
var bdate varchar2(30)

begin
  :stime := dbms_utility.get_time();
  :bdate := '2020-05-20';
end;
/


def REPTITLE="Data growth report for &&vDbName"

def MAINREPORTFILE=db_growth_&&vDbName._&&bdate._&&edate..html
spool &&MAINREPORTFILE

prompt <html>
prompt <!-- DB growth report/graph -->
prompt <!-- Author: Tomasz Kania -->
prompt <head>
prompt   <title>&&REPTITLE.</title>

---------------------------------------------------
-- GoogleChart JS
---------------------------------------------------
prompt   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
prompt     <script type="text/javascript">
prompt       google.charts.load('current', {'packages':['table', 'corechart', 'controls']});;
prompt       google.charts.setOnLoadCallback(drawDBSizeChart);;  
prompt       google.charts.setOnLoadCallback(drawTbsSizeChart);;  
prompt       google.charts.setOnLoadCallback(drawTopSegsChart);;  
prompt 
prompt 

spool off
set termout on
prompt Gathering database growth statistics...
set termout off
spool &&MAINREPORTFILE append
---------------------------------------------------
-- DB Size chart
---------------------------------------------------
prompt     function drawDBSizeChart() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('date', 'Snapshot');;
prompt       data.addColumn('number', 'Allocated GB');;
prompt       data.addColumn('number', 'Used GB');;
prompt       data.addColumn('number', 'Daily change GB');;
prompt       data.addColumn('number', 'Weekly change GB');;
prompt       data.addColumn('number', 'Monthly change GB');;
prompt       data.addColumn('number', 'Yearly change GB');;
prompt 
prompt       data.addRows([

WITH tbsp_usage AS (
SELECT
  target_name
  ,rollup_timestamp AS snap_time
  ,to_char(rollup_timestamp,'YYYY')||','||to_char(to_number(to_char(rollup_timestamp,'MM'))-1)||','||to_char(rollup_timestamp,'DD,HH24,MI') chart_dt
  --,metric_name
  ,metric_column
  --,column_label
  --,key_value tbs_name
  ,Sum(Round(maximum/1024,2)) GB
FROM sysman.mgmt$metric_daily
WHERE target_type='oracle_database'
  and target_name = :v_db_target
  and metric_name = 'tbspAllocation'
  and metric_column in ('spaceAllocated', 'spaceUsed')
  and rollup_timestamp > to_date(:bdate,'YYYY-MM-DD')
GROUP BY target_name,rollup_timestamp,metric_column
), piv1 AS (
SELECT 
  target_name
  , snap_time
  , chart_dt
  --, tbs_name
  , allocated_gb
  , used_gb
  ,(allocated_gb-lag(allocated_gb) over(order by snap_time)) daily_growth
  ,(allocated_gb-lag(allocated_gb,7) over(order by snap_time)) weekly_growth
  ,(allocated_gb-lag(allocated_gb,30) over(order by snap_time)) monthly_growth
  ,(allocated_gb-lag(allocated_gb,365) over(order by snap_time)) yearly_growth
  , Row_Number() OVER (ORDER BY snap_time desc) rn
FROM
tbsp_usage
  pivot (
    Max(gb) AS gb
    FOR (metric_column) IN('spaceAllocated' AS allocated, 'spaceUsed' AS used)
  )
)
select
  '[new Date('||chart_dt||'),'||
  allocated_gb||','||
  used_gb||','||
  nvl(daily_growth,0)||','||
  nvl(weekly_growth,0)||','||
  nvl(monthly_growth,0)||','||
  nvl(yearly_growth,0)||
  ']'||case when rn=1 then '' else ',' end
FROM piv1 
ORDER BY snap_time;


prompt       ]);;
prompt 
prompt       var options = {
prompt            isStacked: false,
prompt            title: 'Database growth',
prompt            backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt            explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt            titleTextStyle: {fontSize: 16, bold: true},
prompt            focusTarget: 'category',
prompt            legend: {position: 'right', textStyle: {fontSize: 12}},
prompt            tooltip: {textStyle: {fontSize: 11}},
prompt            hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt            vAxis: {title: 'GB', textStyle: {fontSize: 10}}
prompt       };;
prompt 
prompt		 var chartView = new google.visualization.DataView(data);;
prompt		 chartView.setColumns([0,1,2]);;
prompt       var chart = new google.visualization.LineChart(document.getElementById('div_db_size_chart'));;
prompt       chart.draw(chartView, options);;
prompt       var table = new google.visualization.Table(document.getElementById('div_db_size_tab'));;
prompt       table.draw(data, {width: '100%', height: '100%', sortColumn:0, sortAscending:false, cssClassNames:{headerCell:'gcharttab'}});;
prompt	}
prompt

---------------------------------------------------
-- DB Size chart end
---------------------------------------------------

spool off
set termout on
prompt Gathering db size by tablespace...
set termout off
spool &&MAINREPORTFILE append

---------------------------------------------------
-- TBS chart
---------------------------------------------------
var gdata_cols varchar2(4000)

prompt     function drawTbsSizeChart() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('date', 'Snapshot');;
prompt       data.addColumn('string', 'Space usage');;

declare
  type t_str_tab is table of varchar2(64);
  v_tablespaces t_str_tab;
  v_gdata_cols varchar2(4000);
  v_tbs_cnt   number;
  v_tbs_inlist varchar2(4000);
  v_sqlstmt   varchar2(8000);
  v_sqlstmt2   varchar2(8000);
  v_pivot     varchar2(4000);
  v_dyn_cols  varchar2(4000);
  v_gchart_cols   varchar2(4000);
  v_cid           number;
  t_desctab      dbms_sql.desc_tab;
  v_colcnt       number;
  v_colval       varchar2(4000);
  v_rowcnt       number;
  v_gchart_data  varchar2(4000);

begin
  --select distinct tablespace_name bulk collect into v_tablespaces from v_hist_tbs order by tablespace_name desc;
  select tablespace_name bulk collect into v_tablespaces
  from (
      SELECT
        case when target_name = 'PRDACP01.apobank.lan' AND  key_value like 'AGING%' then 'AGING_ALL' else key_value end tablespace_name
        ,Sum(Round(maximum/1024,2)) GB
      FROM sysman.mgmt$metric_daily
      WHERE target_type='oracle_database'
        and target_name = :v_db_target
        and metric_name = 'tbspAllocation'
        and metric_column = 'spaceAllocated'
        and rollup_timestamp > to_date(:bdate,'YYYY-MM-DD')
        --AND rollup_timestamp > To_Date('2020-05-01','YYYY-MM-DD')
      GROUP BY case when target_name = 'PRDACP01.apobank.lan' AND key_value like 'AGING%' then 'AGING_ALL' else key_value END
      ORDER BY gb desc
   ) where rownum <=30;

  for i in 1..v_tablespaces.count
    loop
      v_pivot := v_pivot||''''||v_tablespaces(i)||''' as "'||substr(v_tablespaces(i),1,25)||'",';
      v_dyn_cols := v_dyn_cols||'"'||substr(v_tablespaces(i),1,25)||'",';
      v_tbs_inlist := v_tbs_inlist||''''||v_tablespaces(i)||''',';
      --Dbms_Output.Put_Line('event: '||v_tablespaces(i));
      v_gchart_cols := v_gchart_cols||'data.addColumn(''number'', '''||v_tablespaces(i)||''');;'||chr(10);
      v_gdata_cols := v_gdata_cols||to_char(i+1)||',';
    end loop;
  v_pivot := rtrim(v_pivot,',');
  v_dyn_cols := rtrim(v_dyn_cols,',');
  v_tbs_inlist := rtrim(v_tbs_inlist,',');
  :gdata_cols := rtrim(v_gdata_cols,',');
  --dbms_output.put_line(v_pivot);
  --dbms_output.put_line(v_tbs_inlist);
  dbms_output.put_line(v_gchart_cols);
  dbms_output.put_line('');
  dbms_output.put_line('data.addRows([');

  v_sqlstmt := q'[
        WITH tbs AS
        (
        SELECT
          --target_name
          rollup_timestamp
          ,to_char(rollup_timestamp,'YYYY')||','||to_char(to_number(to_char(rollup_timestamp,'MM'))-1)||','||to_char(rollup_timestamp,'DD,HH24,MI') chart_dt
          --,metric_name
          ,metric_column
          --,column_label
          ,case when target_name = 'PRDACP01.apobank.lan' AND  key_value like 'AGING%' then 'AGING_ALL' else key_value end tbs_name
          ,Sum(Round(maximum/1024,2)) GB
        FROM sysman.mgmt$metric_daily
        WHERE target_type='oracle_database'
          and target_name = trim('&vDbName')
          and metric_name = 'tbspAllocation'
          and metric_column in ('spaceAllocated', 'spaceUsed')
          AND rollup_timestamp > To_Date('2020-05-20','YYYY-MM-DD')
          and case when target_name = 'PRDACP01.apobank.lan' AND  key_value like 'AGING%' then 'AGING_ALL' else key_value end in(]'||v_tbs_inlist||q'[)
        GROUP BY rollup_timestamp,metric_column, case when target_name = 'PRDACP01.apobank.lan' AND  key_value like 'AGING%' then 'AGING_ALL' else key_value end,key_value
        ORDER BY 1,3,2
        )
        select
          chart_dt,metric_column as usage,]'||v_dyn_cols||q'[
        from tbs
          pivot (
            sum(gb)
            for tbs_name in(]'||v_pivot||')) order by rollup_timestamp,metric_column';

    --dbms_output.put_line(v_sqlstmt);
    v_cid := dbms_sql.open_cursor;

    dbms_sql.parse(
        v_cid,
        v_sqlstmt,
        dbms_sql.native
    );

    --dbms_sql.bind_variable(v_cid, 'bsnap', :bsnap);
    --dbms_sql.bind_variable(v_cid, 'esnap', :esnap);
    --dbms_sql.bind_variable(v_cid, 'nTopEvents', :nTopEvents);

    dbms_sql.describe_columns(
        v_cid,
        v_colcnt,
        t_desctab
    );
    for i in 1..v_colcnt loop
      dbms_sql.define_column(
          v_cid,
          i,
          v_colval,
          4000
        );
    end loop;

    v_rowcnt := dbms_sql.execute(v_cid);

    v_gchart_data := '';
    while ( dbms_sql.fetch_rows(v_cid) > 0 ) loop
      for i in 1..v_colcnt loop
        dbms_sql.column_value(
          v_cid,
          i,
          v_colval
        );
        --dbms_output.put_line(rpad(t_desctab(i).col_name,30)||': '|| v_colval);
        if t_desctab(i).col_name = 'CHART_DT' then
          v_gchart_data := v_gchart_data||'[new Date('||v_colval||')';
        elsif t_desctab(i).col_name = 'USAGE' then
          v_gchart_data := v_gchart_data||','''||nvl(v_colval,0)||'''';
        else
          v_gchart_data := v_gchart_data||','||nvl(v_colval,0);
        end if;
      end loop;
      v_gchart_data :=  v_gchart_data||']';
      Dbms_Output.Put_Line(v_gchart_data);
      v_gchart_data := ',';

    end loop;

    dbms_sql.close_cursor(v_cid);
exception
  when others then
  if dbms_sql.is_open(v_cid) then
    dbms_sql.close_cursor(v_cid);
  end if;
  raise;
end;
/



prompt
prompt       ]);;
prompt		var dashboard = new google.visualization.Dashboard(document.getElementById('div_tbs'));;
prompt
prompt        var tbsCatFilter = new google.visualization.ControlWrapper({
prompt          controlType: 'CategoryFilter',
prompt          containerId: 'div_tbs_filter',
prompt          options: {
prompt            filterColumnLabel: 'Space usage',
prompt			ui: {
prompt				allowMultiple: false,
prompt				allowNone: false
prompt			}
prompt          },
prompt			state: {selectedValues: ['Allocated space']}
prompt        });;
prompt
prompt       var chart = new google.visualization.ChartWrapper({
prompt          chartType: 'AreaChart',
prompt          containerId: 'div_tbs_chart',
prompt          options: {
prompt				isStacked: 'true',
prompt				title: 'DB size by tablespace',
prompt				backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt				explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt				titleTextStyle: {fontSize: 16, bold: true},
prompt				focusTarget: 'category',
prompt				lineWidth: 1,
prompt				legend: {position: 'right', textStyle: {fontSize: 8}},
prompt				tooltip: {textStyle: {fontSize: 9}},
prompt				hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt				vAxis: {title: 'GB', textStyle: {fontSize: 10}}
prompt				},
exec dbms_output.put_line('view: {columns: [0,'||:gdata_cols||']}');
--prompt		    view: {columns: [0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]}  
prompt        });;	
prompt
prompt		var table = new google.visualization.ChartWrapper({
prompt          chartType: 'Table',
prompt          containerId: 'div_tbs_tab',
prompt          options: {width: '100%', height: '100%', sortColumn:0, sortAscending:false, cssClassNames:{headerCell:'gcharttab'}},
exec dbms_output.put_line('view: {columns: [0,'||:gdata_cols||']}');
--prompt		  view: {columns: [0,2,3,6,7,8,4,5]}  
prompt        });;	
prompt
prompt
prompt        dashboard.bind([tbsCatFilter], [chart, table]);;
prompt        dashboard.draw(data);;		
prompt 
prompt 	}
prompt

---------------------------------------------------
-- TBS size chart end
---------------------------------------------------

spool off
set termout on
prompt Gathering segments statistics...
set termout off
spool &&MAINREPORTFILE append

---------------------------------------------------
-- TBS segments chart end
---------------------------------------------------
prompt     function drawTopSegsChart() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('date', 'Snapshot');;
prompt       data.addColumn('string', 'Tablespace name');;
prompt       data.addColumn('number', 'Tablespace used MB');;
prompt       data.addColumn('number', 'Tablespace allocated MB');;
prompt 
prompt       data.addRows([

WITH tbs AS
(
SELECT
  --target_name
  rollup_timestamp
  ,to_char(rollup_timestamp,'YYYY')||','||to_char(to_number(to_char(rollup_timestamp,'MM'))-1)||','||to_char(rollup_timestamp,'DD,HH24,MI') chart_dt
  --,metric_name
  ,metric_column as usage
  --,column_label
  ,case when target_name = 'PRDACP01.apobank.lan' AND  key_value like 'AGING%' then 'AGING_ALL' else key_value end tbs_name
  ,Sum(Round(maximum/1024,2)) GB  
FROM sysman.mgmt$metric_daily
WHERE target_type='oracle_database'
  and target_name = :v_db_target
  and metric_name = 'tbspAllocation'
  and metric_column in ('spaceAllocated', 'spaceUsed')
  and rollup_timestamp > to_date(:bdate,'YYYY-MM-DD')
  --AND rollup_timestamp > To_Date('2020-05-01','YYYY-MM-DD')
GROUP BY rollup_timestamp,metric_column, case when target_name = 'PRDACP01.apobank.lan' AND  key_value like 'AGING%' then 'AGING_ALL' else key_value end,key_value
ORDER BY 1,3,2
)
,chart_data as
(
select 
  chart_dt
  ,rollup_timestamp
  ,tbs_name
  ,used_gb
  ,allocated_gb
  ,row_number() over (order by rollup_timestamp desc,tbs_name desc) rn
from tbs
  pivot (
    sum(gb)
    for usage in('spaceUsed' as "USED_GB",'spaceAllocated' as "ALLOCATED_GB")
  )
  order by rollup_timestamp,tbs_name
)
select
  '[new Date('||chart_dt||'),'||
  ''''||tbs_name||''','||
  nvl(used_gb,0)||','||
  nvl(allocated_gb,0)||
  ']'||case when rn=1 then '' else ',' end 
from chart_data
order by rollup_timestamp ,tbs_name
;



prompt       ]);;
prompt
prompt		var dashboard = new google.visualization.Dashboard(document.getElementById('div_tbs_segs'));;
prompt
prompt        var filter = new google.visualization.ControlWrapper({
prompt          controlType: 'CategoryFilter',
prompt          containerId: 'div_tbs_segs_filter',
prompt          options: {
prompt            filterColumnLabel: 'Tablespace name',
prompt			  ui: {
prompt		        allowMultiple: false,
prompt				allowNone: false
prompt			  }
prompt          }
prompt        });;
prompt
prompt       var chart = new google.visualization.ChartWrapper({
prompt          chartType: 'ComboChart',
prompt          containerId: 'div_tbs_segs_chart',
prompt          options: {
prompt            	isStacked: true,
prompt            	title: 'Tablespace growth',
prompt            	backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt            	explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt            	titleTextStyle: {fontSize: 16, bold: true},
prompt            	focusTarget: 'category',
prompt            	legend: {position: 'right', textStyle: {fontSize: 10}},
prompt            	seriesType: 'area',
prompt				   lineWidth: 1,
prompt            	series: {0: {type: 'line'}},
prompt            	tooltip: {textStyle: {fontSize: 10}},
prompt            	hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt            	vAxis: {title: 'GB', textStyle: {fontSize: 10}}
prompt				},
prompt		  	view: {columns: [0,2,3]}  
prompt        });;	
prompt
prompt
prompt        dashboard.bind([filter], [chart]);;
prompt        dashboard.draw(data);;		
prompt 
prompt 	}
prompt

---------------------------------------------------
-- TBS segments chart end
---------------------------------------------------




prompt   </script>
---------------------------------------------------
-- CSS
---------------------------------------------------
prompt <style type="text/css">
prompt   body {font-family: Arial,Helvetica,Geneva,sans-serif; font-size:8pt; text-color: black; background-color: white;}
prompt   table.sql {font-size:8pt; color:#333366; width:70%; border-width: 2px; border-color: #000000; border-collapse: collapse; margin-left:10px;} 
prompt   th {border-width: 1px; background-color:#d9d9d9; padding: 3px; border-style: solid; border-color: #000000;} 
prompt   tr:nth-child(even) {background: #f2f2f2}
prompt   tr:nth-child(odd) {background: #FFFFFF}
prompt   tr:hover {color:black; background:#e6f2ff;}
prompt   td {border-width: 1px; padding: 2px; border-style: solid; border-color: #000000; color:#000000;} 
prompt   th.gcharttab {font-size:8pt;font-weight:bold; background: linear-gradient(to top, #9494b8 0%, #c2c2d6 100%);}
prompt   td.gcharttab {font-size:8pt;}
prompt   h1 {font-size:16pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px; text-align:center;}
prompt   h2 {font-size:12pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px;}
prompt   h3 {font-size:10pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px;}
prompt   pre {font:8pt monospace;Monaco,"Courier New",Courier;}
prompt   font.footnote {font-size:8pt; font-style:italic; color:#555;}
prompt   li.footnote {font-size:8pt; font-style:italic; color:#555;}
prompt   a.toc:link, a.toc:visited {font-size:10pt; font-weight:bold; text-decoration:none; color:#333366;}
prompt   a.toc:hover {font-size:10pt; font-weight:bold; text-decoration:underline; color:#333366; background-color:#eeeef6}
prompt   a.fnnav:link, a.fnnav:visited {font-size:8pt; font-weight:bold; text-decoration:none; color:#333366;font-style:italic;}
prompt   a.fnnav:hover {font-size:8pt; font-weight:bold; text-decoration:underline; color:#333366; background-color:#eeeef6;font-style:italic;}
prompt   div.tab1200 {width:1200px; resize: vertical; overflow:auto;}
prompt   div.tab100pct {width:100%; resize: vertical; overflow:auto;}
prompt   .google-visualization-table-table *  { font-size:8pt; }
prompt </style>
prompt </head>
---------------------------------------------------
-- BODY
---------------------------------------------------
prompt <body>
prompt <h1> Data growth report for database: &&vDbName., interval: &&bdate - &&edate </h1>
prompt <h2> Database info </h2>
set markup html on head "" TABLE "class='sql' style='width:900px;'"
set pagesize 100
SELECT target_name as database_name,host_name
FROM sysman.mgmt_targets
WHERE target_type='oracle_database'
  AND target_name = :v_db_target;


set pagesize 0
set markup html off

prompt <h2 id="h_toc"> Reports list </h2>
prompt <ul>
prompt  <li><a class="toc" href="#h_total_db_size">Database size</a></li> 
prompt  <li><a class="toc" href="#h_db_size_by_tbs">DB size by tablespace</a></li> 
prompt  <li><a class="toc" href="#h_tbs_segs">Tablespace growth history</a></li> 
prompt </ul>

prompt <h2 id="h_db_size"> Database size </h2>
prompt <div id="div_db_size_chart" style='width:100%; height: 500px;'></div>
prompt <font class="footnote">Graph note: drag to zoom, right click to reset. </font>
prompt <div id="div_db_size_tab" class="tab100pct" style='height: 200px;'></div>
prompt <a class="fnnav" href="#h_toc">back to top</a>


prompt <h2 id="h_db_size_by_tbs"> DB size by tablespace (limited to top 30 tablespaces)</h2>
prompt <div id="div_tbs">
prompt 	<div id="div_tbs_filter" style='width:100%;padding:10px;'></div>
prompt 	<div id="div_tbs_chart" style='width:100%; height: 700px;'></div>
prompt <font class="footnote">Graph note: drag to zoom, right click to reset. <br> </font>	
prompt <div id="div_tbs_tab" class="tab100pct" style='height: 200px;'></div>
prompt </div>
prompt <a class="fnnav" href="#h_toc">back to top</a>


prompt <h2 id="h_tbs_segs"> Tablespace growth history </h2>
prompt <div id="div_tbs_segs">
prompt 	<div id="div_tbs_segs_filter" style='width:100%;padding:10px;'></div>
prompt 	<div id="div_tbs_segs_chart" style='width:100%; height: 600px;'></div>
prompt <font class="footnote">Graph note: drag to zoom, right click to reset. <br> </font>	
prompt </div>
prompt <a class="fnnav" href="#h_toc">back to top</a>


prompt 
prompt <hr>
prompt </body>
prompt </html>
prompt 

spool off

begin
  :etime := dbms_utility.get_time();
end;
/


col host_grep_cmd new_val host_grep_cmd noprint
select 
  case 
    when upper('&&_EDITOR') = 'NOTEPAD' then
      'findstr "^ORA- ^PLS- ^SP2-"'
    else
      'grep -E "^ORA-|^PLS-|^SP2-"'
  end host_grep_cmd
from dual;


set termout on
prompt ==================================================================
prompt Generated report: &&MAINREPORTFILE
prompt ==================================================================

col "Elapsed time" form A15
select cast(numtodsinterval((:etime-:stime)/100,'SECOND') as interval day(0) to second(0)) as "Elapsed time" from dual;

prompt ==================================================================
prompt  Checking for errors in generated report...
prompt  If anything is reported below, charts will not display properly...
prompt ==================================================================
host &&host_grep_cmd &&MAINREPORTFILE

exit;

