set verify off feedback off
set serveroutput on
set linesize 250 pagesize 800 long 100000 
col owner form A10 
col is_bind_sensitive form A6 heading "Bind|sensi"
col is_bind_aware form A6 heading "Bind|aware"
col is_shareable form A6 heading "Is|sharea"
col sql_profile form A35 heading "SQL|Profile"
col sql_patch form A35 heading "SQL|Patch"
col sql_plan_baseline  form A35 heading "SQL Plan|Baseline"
col is_rolling_invalid form A6 heading "roll|inval"
col first_load_time form A14 heading "First|load time"
col last_active_time form A14 heading "Last|active time"
col sql_id new_val _sql_id noprint
col fms new_val _fms noprint
col sql_text new_val _sql_text noprint
col program_id new_val _program_id noprint
col program_line# new_val _program_line noprint
col prog_name new_val prog_name noprint

col buffer_gets form 999G999G999G999
col execs form 999G999G999G999
col rows_total form 999G999G999G999
col "PhysReadMB" form 999G999G999D00
col ela_time form A12
col io_time form A12
col cpu_time form A12
col cc_time form A12
col ap_time form A12


def sql_id=&1

select s.sql_id, to_char(s.force_matching_signature) fms,s.sql_text,program_id,program_line# from v$sql s where sql_id='&&sql_id' and rownum <=1;
select object_type||': '||owner||'.'||object_name||', line: &_program_line' as prog_name from dba_objects where  object_id=to_number(nvl(trim('&_program_id'),-1));

prompt ==========================================================================
prompt sql_id=&&_sql_id
prompt force_matching_signature=&&_fms
prompt
prompt &&_sql_text
prompt
prompt called from: &&prog_name
prompt ==========================================================================
prompt Current execution statistics 
prompt ==========================================================================
select 
   --s.sql_id, s.force_matching_signature fms,s.sql_text, 
   s.child_number child#, s.parsing_schema_name owner, s.plan_hash_value plan_hash, 
   --s.fetches, 
   s.executions execs, 
   --s.parse_calls, s.loads, 
   s.buffer_gets,
   round(s.buffer_gets/decode(s.executions,0,1,s.executions),2) AS gets_exe,
   cast(numtodsinterval(round(s.elapsed_time/1000000,2),'SECOND') as interval day(2) to second(0)) ela_time,
   cast(numtodsinterval(round(s.cpu_time/1000000,2),'SECOND') as interval day(2) to second(0)) cpu_time,
   cast(numtodsinterval(round(s.concurrency_wait_time/1000000,2),'SECOND') as interval day(2) to second(0)) cc_time,
   --round(s.concurrency_wait_time/1000000,2) "Concur(s)", 
   --round(s.cpu_time/1000000,2) AS "CPU(s)",
   --round(s.elapsed_time/1000000,2) AS "Ela(s)",
   round(s.elapsed_time/1000000/decode(s.executions,0,1,s.executions),4) AS "Ela/exec(s)",
   cast(numtodsinterval(round(s.user_io_wait_time/1000000,2),'SECOND') as interval day(2) to second(0)) io_time,
   --round(s.physical_read_bytes/1024/1024,2) "PhysReadMB", 
   round(s.disk_reads*8/1024,2) "PhysReadMB",
   --s.OPTIMIZER_COST,  
   s.rows_processed AS rows_total,
   round(s.rows_processed/decode(s.executions,0,1,s.executions),2) rows_exec, 
   round(s.buffer_gets/decode(s.rows_processed,0,1,s.rows_processed),2) gets_row
from v$sql s  
where sql_id='&&SQL_ID'
order by child_number;


prompt 
 
select 
  s.child_number child#  
  --,loaded_versions,open_versions,fetches,end_of_fetch_count,loads
  ,substr(first_load_time,6,15) first_load_time
  --,invalidations,parse_calls
  --,substr(last_load_time,6,15) last_load_time
  ,to_char(last_active_time, 'MM/DD HH24:MI:SS') last_active_time
  --,is_obsolete
  ,is_bind_sensitive
  ,is_bind_aware
  ,is_shareable
  ,sql_profile
  ,sql_patch
  ,sql_plan_baseline 
  ,is_rolling_invalid
from v$sql s  
where sql_id='&&SQL_ID'
order by child_number;




DECLARE 
   v_count number; 
   v_childs VARCHAR2(4000); 
   v_sql varchar2(1000); 
   v_sql_id varchar2(40) := '&sql_id'; 
BEGIN 
   v_sql_id := lower(v_sql_id); 
   execute immediate 'alter session set cursor_sharing=force'; 
   dbms_output.put_line(chr(13)||chr(10)); 
   dbms_output.put_line('----------------------------------------------------------------------------'); 
   dbms_output.put_line('- Child cursors - reasons'); 
   dbms_output.put_line('- sql_id: '||v_sql_id); 
   dbms_output.put_line('----------------------------------------------------------------------------'); 
   FOR c1 in 
      (select column_name 
         from dba_tab_columns 
         where table_name ='V_$SQL_SHARED_CURSOR' 
            and column_name not in ('SQL_ID', 'ADDRESS', 'CHILD_ADDRESS', 'CHILD_NUMBER', 'REASON', 'CON_ID') 
         order by column_id
      ) 
   LOOP 
      v_sql := 'select count(*),listagg(child_number,'','') within GROUP (ORDER BY child_number) childs from V_$SQL_SHARED_CURSOR 
               where sql_id='||''''||v_sql_id||''''||' 
               and '||c1.column_name||'='||''''||'Y'||''''; 
      execute immediate v_sql into v_count,v_childs; 
      IF v_count > 0 THEN 
         dbms_output.put_line(' - '||rpad(c1.column_name,30)||' count: '||v_count||', childs: '||v_childs); 
      END IF; 
   END LOOP; 
   execute immediate 'alter session set cursor_sharing=exact'; 
   dbms_output.put_line('----------------------------------------------------------------------------'); 
END; 
/ 

undef sql_id
undef 1

col sql_id clear
col sql_text clear
set feedback 6
