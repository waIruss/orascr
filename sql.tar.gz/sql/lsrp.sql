set line 200
col name form A35 
col guaranteed form A5
col size_mb form 999G999G999
col time form A20
col scn form 9999999999999999999999
PROMPT ==========================================================================
prompt  Existing restore points
PROMPT ==========================================================================
select 
  name,
  guarantee_flashback_database guaranteed,
  round(storage_size/1024/1024) size_mb,
  to_char(time,'YYYY-MM-DD HH24:MI:SS') time,
  scn 
from v$restore_point
order by time;
