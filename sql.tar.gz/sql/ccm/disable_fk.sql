set serveroutput on size unlimited
set line 200
set pagesize 1000

declare
  v_user varchar2(100);
  v_sql varchar2(1000);
begin
  select sys_context('userenv','session_user') into v_user from dual;
  if v_user in('SYS','SYSTEM') then
    raise_application_error(-20001,'Script is protected against modifying SYS/SYSTEM schemas!');
  end if;
  for c in(select table_name,constraint_name from user_constraints where constraint_type='R' and status='ENABLED') 
  loop
    v_sql := 'alter table '||c.table_name||' disable constraint '||c.constraint_name;
    dbms_output.put(v_sql);
    begin
      execute immediate v_sql;
    exception
      when others then
        dbms_output.put_line(sqlerrm);
    end;
    dbms_output.put_line(' - OK');
  end loop; 
end;
/

