set serveroutput on size unlimited
set line 250 pagesize 1000
set verify off

def user_to_kill="&1"

declare
  v_kills_ok number;
  v_kills_warn number;
  v_sql varchar2(1000);
begin
  v_kills_ok := 0;
  v_kills_warn := 0;
  for s in(select sid,serial# from v$session where username=upper(trim('&user_to_kill')))
  loop
    v_sql := 'alter system kill session '''||s.sid||','||s.serial#||''' immediate';
    begin
      --dbms_output.put_line(v_sql);
      execute immediate v_sql;
      v_kills_ok := v_kills_ok + 1;
    exception
      when others then 
        v_kills_warn := v_kills_warn + 1;
    end;        
  end loop;
  dbms_output.put_line('Killed '||to_char(v_kills_ok)||' sessions successfully');
  dbms_output.put_line('Killed '||to_char(v_kills_warn)||' sessions with warnings');
end;
/

