whenever sqlerror exit failure
whenever oserror exit failure

set serveroutput on size unlimited
set feedback off echo off
set line 2000
set heading off 
set pagesize 0
set trimspool on
set verify off
define CCMSCHEMA="&1"
define DB_LINK="&2"
define spoolfile="&3"

--list of REPOSITORYSCHEMA_ID to exclude
define REPOSCHEMA_ID_EXCL_LIST="749123032,1165821,4349711,829554"
--define REPOSCHEMA_ID_EXCL_LIST="749123032,1165821,4349711"

col repositoryschema_id form 999999999999999
col contenttype form A20
col name form A40
select repositoryschema_id, contenttype, name from &CCMSCHEMA..repositoryschema
where repositoryschema_id in(&REPOSCHEMA_ID_EXCL_LIST);


spool &spoolfile
declare
  output varchar2(32000);
  v_own varchar2(100);
  v_tab varchar2(100);
  v_init_filter varchar2(4000);
  v_db_link varchar2(200);
function gen_exp(v_owner varchar2, v_parent_tab varchar2,v_init_f varchar2, v_dbl varchar2) return varchar2
is
  v_tmp_f varchar2(4000);
  v_fin_f varchar2(4000);
  v_curr_f varchar2(4000);
  v_cur_tab varchar2(100);
  v_prev_tab varchar2(100) := null;
  v_out varchar2(1000);
begin
  for c1 in (select * from (
              select c.owner
              ,c.table_name
              ,c.constraint_name r_cons
              ,r_cc.column_name r_col
              --,constraint_type
              ,r_constraint_name p_cons
              ,row_number() over(partition by c.table_name order by r_cc.column_name) rn
              ,(select table_name from dba_cons_columns cc2 where cc2.constraint_name=c.r_constraint_name and cc2.owner=c.owner)  p_tab
              ,(select column_name from dba_cons_columns cc2 where cc2.constraint_name=c.r_constraint_name and cc2.owner=c.owner)  p_col
             from dba_constraints c,dba_cons_columns r_cc
             --,dba_cons_columns p_cc
             where c.owner=v_owner
                and c.constraint_type='R' and c.delete_rule='CASCADE'
                and c.owner=r_cc.owner and c.table_name=r_cc.table_name and r_cc.constraint_name=c.constraint_name
                --and c.r_owner=p_cc.owner and c.r_constraint_name=p_cc.constraint_name
                and exists (select 1 from dba_constraints c2
                            where c.r_constraint_name=c2.constraint_name
                              and c.owner=c2.owner
                              and c2.constraint_type in('P','U')
                              and c2.table_name=v_parent_tab
                            )
              order by c.table_name
              ) order by table_name, rn desc
            )
  loop
    --Dbms_Output.Put_Line('RN:'||c1.rn|| ' - Child table: '|| c1.table_name||', Child Cons: '||c1.r_cons||', parent tab:' ||v_parent_tab||', Parent cons:'||c1.p_cons);
    if v_prev_tab <> c1.table_name or v_prev_tab is null then
       v_fin_f := '';
       v_tmp_f := replace(v_init_f,'#NEW_TAB#',', '||c1.owner||'.'||c1.p_tab||v_dbl||' #NEW_TAB#');
       v_tmp_f := replace(v_tmp_f,'#NEW_JOIN#',' AND '||c1.owner||'.'||c1.table_name||'.'||c1.r_col||'='||c1.owner||'.'||c1.p_tab||'.'||c1.p_col||' #NEW_JOIN#');
       v_fin_f := v_tmp_f;
    else
       v_tmp_f := replace(v_init_f,'#NEW_TAB#',', '||c1.owner||'.'||c1.p_tab||v_dbl||' #NEW_TAB#');
       v_tmp_f := replace(v_tmp_f,'#NEW_JOIN#',' AND '||c1.owner||'.'||c1.table_name||'.'||c1.r_col||'='||c1.owner||'.'||c1.p_tab||'.'||c1.p_col||' #NEW_JOIN#');
       v_fin_f := v_fin_f||' AND '||v_tmp_f;
    end if;
    v_prev_tab := c1.table_name;
    if c1.rn = 1 then
      Dbms_Output.Put_Line('QUERY='||c1.owner||'.'||c1.table_name||':"WHERE '||replace(replace(replace(v_fin_f,'#NEW_JOIN#',''),'#NEW_TAB#',''),c1.owner||'.'||c1.table_name||'.','ku$.')||'"');
    end if;
    v_out := gen_exp(c1.owner,c1.table_name,v_fin_f,v_dbl);
  end loop;
  return 0;
end;
begin
  v_own := upper(trim('&CCMSCHEMA'));
  if upper(trim('&DB_LINK')) = 'NULL' then
      v_db_link := ' ';
  else
      v_db_link := '@'||upper(trim('&DB_LINK'));
  end if;
  dbms_output.put_line('QUERY='||v_own||'.DELIVERYOBJECT:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.DELOBJ_PPODATA:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.ENVELOPE:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.ENV_PPODATA:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.ERRORINFO:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.ERRORREF:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.JOBINFO:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.POSTPROCINDATA:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.POSTPROCOUTDATA:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_ENVELOPE:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_EXECUTION:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_METADATA:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_METADATA_KEY_MAP:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_METADATA_SEGMENT_1:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_METADATA_SEGMENT_2:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_METADATA_SEGMENT_3:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_METADATA_SEGMENT_4:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_METADATA_SEGMENT_5:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_PPOD:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_PPOD_ENV:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_RESTORE:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_RESTORE_ENV:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_RESTORE_STREAM:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_STREAM:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_STREAM_ENV:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_STREAM_QUEUE:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.PPE_W:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.SOURCEOBJECT:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.TASKINFO:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_EM_EOB_MESSAGES:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_ER_EOB_REGISTRY:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_JR_JOB_REGISTRY:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_MA_MESSAGE_ADDRESS:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_MP_MESSAGE_PPOD:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_MR_MESSAGE_REGISTRY:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_OUT_MESSAGES:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_RM_RESOURCE_MAP:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_TP_TICKET_PRIVILEGE:"where 1=0"');
  dbms_output.put_line('QUERY='||v_own||'.CCM_TR_TICKET_REGISTRY:"where 1=0"');
  v_tab := 'COCKPITELEMENT';
  v_init_filter := ' EXISTS (SELECT /*+ first_rows(1) */ 1 FROM '||v_own||'.REPOSITORYFOLDER'||v_db_link||' RF #NEW_TAB# WHERE '||v_own||'.COCKPITELEMENT.REPOSITORYFOLDER_ID = RF.REPOSITORYFOLDER_ID AND RF.REPOSITORYSCHEMA_ID NOT IN(&REPOSCHEMA_ID_EXCL_LIST) #NEW_JOIN# )';
  Dbms_Output.Put_Line('QUERY='||v_own||'.REPOSITORYFOLDER:"WHERE REPOSITORYSCHEMA_ID NOT IN(&REPOSCHEMA_ID_EXCL_LIST)"');
  Dbms_Output.Put_Line('QUERY='||v_own||'.'||v_tab||':"WHERE '||replace(replace(replace(v_init_filter,'#NEW_JOIN#',''),'#NEW_TAB#',''),v_own||'.'||v_tab||'.','ku$.')||'"');
  output := gen_exp(v_own,v_tab,v_init_filter,v_db_link);
end;
/
spool off
exit;

