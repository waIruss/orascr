set verify off echo off

whenever sqlerror exit failure

col passw_ new_val Passwd noprint


with function
  gen_new_pass(v_user varchar2, v_acc_type varchar2 default 'S', v_old_pass varchar2 default null)
  return varchar2
  as
    type chararr is table of char(1) index by binary_integer;
    pass_chars chararr;
    --v_user varchar2(50) := 'USER_123455';
    --v_old_pass varchar2(50);
    v_new_pass varchar2(50);
    --v_acc_type char(1) := 'S';  -- U - user, S - service
    v_pass_len pls_integer;
    v_pass_ok boolean := false;
    v_att pls_integer := 1;
  begin
    if v_acc_type = 'U' then
      v_pass_len := 8;
    elsif v_acc_type = 'S' then
      v_pass_len := 12;
    else
      v_pass_len := 16;
    end if;

    select c
      bulk collect into pass_chars
    from
      (select chr(to_number(column_value)) c, to_number(column_value) n from xmltable('1 to 128'))
    where (
      n between 48 and 57 --[0-9]
      or n between 65 and 90 --[a-z]
      or n between 97 and 122 --[A-Z]
      or c in('[',']','-','.','^','{','}') --allowed special chars
    );

    while (not v_pass_ok)
    loop
      v_new_pass := chr(round(dbms_random.value(65,90)));
      v_att := v_att+1;
      for i in 1..20
        loop
          v_new_pass := v_new_pass||pass_chars(round(dbms_random.value(1,pass_chars.count)));
        end loop;
          v_new_pass := substr(regexp_replace(v_new_pass,'(.)\1+','\1'),1,v_pass_len+1);
      begin
        if v_acc_type = 'S' then
          v_pass_ok := sys.passwd_verify_function_service(v_user,v_new_pass,v_old_pass);
        elsif v_acc_type = 'U' then
          v_pass_ok := sys.passwd_verify_function_user(v_user,v_new_pass,v_old_pass);
        end if;
      exception
        when others then
          null;
      end;
      exit when v_att >= 20;
    end loop;
    return v_new_pass;
  end;
select gen_new_pass('CCM_RO_DXC_','U') passw_ from dual
/

prompt
prompt ============================================================
prompt Script will created Read-Only user for CCM
prompt ============================================================
ACCEPT uName  PROMPT 'Define username (prefix with: CCM_RO_DXC_):'
ACCEPT Passwd DEFAULT '&&Passwd' PROMPT 'Define password for &uName [default: "&&Passwd" ]:'
prompt ============================================================



create user &uName identified by "&Passwd" default tablespace users profile user_profile;
grant create session,alter session,select any table,select any dictionary to &uName;

@@../ls_user_privs &uName

prompt ============================================================
prompt Created user: &uName/&&Passwd
prompt ============================================================

