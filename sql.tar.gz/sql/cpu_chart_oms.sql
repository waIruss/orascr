/*
 * Script for CPU/Memory reports
 * Author: Tomasz Kania
 * Usage: Run on OMS repository, @cpu_chart_oms.sql <hostname> <days_back>
*/

whenever sqlerror exit failure
set linesize 2000 pagesize 0 long 32000 longchunksize 32000
set termout off
set trimspool on echo off feedback off 
set verify off
set define '&'
set serveroutput on size unlimited
set sqlblanklines on

--defines 
col global_name new_val db_n noprint
col instance_name new_val inst_name noprint
col instance_number new_val inst_num noprint
select global_name from global_name;
select instance_name,trim(instance_number) as instance_number from v$instance;

--avoid comma as decimal separator in outputs
alter session set nls_numeric_characters='.,';


var bsnap number
var esnap number
var nTopEvents number
var nTopSqls number


col bdate new_val bdate noprint
col edate new_val edate noprint
def DT_FMT_REP="Mon-DD"
def DT_FMT_ISO="YYYY-MM-DD HH24:MI"


def hostname=&1
def n_days=&2

whenever sqlerror continue

select
  to_char(min(collection_time),'&&DT_FMT_REP') as bdate,
  to_char(max(collection_time),'&&DT_FMT_REP') as edate
from sysman.gc_metric_values
where metric_group_name = 'Load'
and metric_column_name in('memUsedPct','cpuUtil')
and (entity_name like '&&hostname.%' )
and collection_time > sysdate-&&n_days;

set termout on
prompt Generating report, it may take few minutes.... Please wait...
prompt
set termout off

var stime number
var etime number

begin
  :stime := dbms_utility.get_time();
end;
/

def REPTITLE="CPU and Memory usage on &&hostname"

def MAINREPORTFILE=cpu_mem_util_&&hostname._&&bdate._&&edate..html
spool &&MAINREPORTFILE

prompt <html>
prompt <!-- CPU/Memory reports/graphs -->
prompt <!-- Author: Tomasz Kania -->
prompt <head>
prompt   <title>&&REPTITLE.</title>

---------------------------------------------------
-- GoogleChart JS
---------------------------------------------------
prompt   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
prompt     <script type="text/javascript">
prompt       google.charts.load('current', {'packages':['table', 'corechart', 'controls']});;
prompt       google.charts.setOnLoadCallback(drawCPUMemChart);;
prompt 
prompt 


spool off
set termout on
prompt Gathering CPU and Memory usage...
set termout off
spool &&MAINREPORTFILE append

---------------------------------------------------
-- CPU/MEM chart
---------------------------------------------------
prompt     function drawCPUMemChart() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('datetime', 'Snapshot');;
prompt       data.addColumn('number', 'CPU util (%)');;
prompt       data.addColumn('number', 'Mem util (%)');;
prompt
prompt       data.addRows([
with stat as (
select entity_name,metric_column_name metric_name,collection_time,short_name,value 
from sysman.gc_metric_values
where metric_group_name = 'Load'
and metric_column_name in('memUsedPct','cpuUtil')
and (entity_name like '&&hostname.%' )
and collection_time > sysdate-&&n_days
order by collection_time 
)
,stat2 as (
select collection_time
,to_char(cast(collection_time as date),'YYYY')||','||to_char(to_number(to_char(cast(collection_time as date),'MM'))-1)||','||to_char(cast(collection_time as date),'DD,HH24,MI') chart_dt
,metric_name
,value
from stat where value is not null
),
chart_data as(
select collection_time,chart_dt,cpu_util,mem_util,row_number() over (order by collection_time desc) rn
from 
stat2
  pivot(
    max(value) for metric_name in (
      'cpuUtil' as cpu_util,
      'memUsedPct' as mem_util
      )
  )
order by collection_time
)
select
  decode(rownum,1,'',',')||
  '[new Date('||chart_dt||'),'||
  '{v:'||round(cpu_util,2)||', f:'''||cpu_util||'%''}'||','||
  '{v:'||round(mem_util,2)||', f:'''||mem_util||'%''}'||','||
  ']'
from chart_data where cpu_util is not null and mem_util is not null;


prompt       ]);;
prompt
prompt       var options = {
prompt            isStacked: false,
prompt            title: '',
prompt            backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt            explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt            titleTextStyle: {fontSize: 16, bold: true},
prompt            focusTarget: 'category',
prompt            legend: {position: 'right', textStyle: {fontSize: 12}},
prompt            tooltip: {textStyle: {fontSize: 11}},
prompt            hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt            vAxis: {title: 'Utilization (%)', textStyle: {fontSize: 10}}
prompt       };;
prompt
prompt           var chartView = new google.visualization.DataView(data);;
prompt           chartView.setColumns([0,1,2]);;
prompt       var chart = new google.visualization.LineChart(document.getElementById('div_cpumem_chart'));;
prompt       chart.draw(chartView, options);;
prompt       var table = new google.visualization.Table(document.getElementById('div_cpumem_tab'));;
prompt       table.draw(data, {width: '100%', height: '100%', sortColumn:0, sortAscending:false, cssClassNames:{headerCell:'gcharttab'}});;
prompt  }
prompt




---------------------------------------------------
--  CPU/MEM chart end
---------------------------------------------------


spool off
spool &&MAINREPORTFILE append

prompt   </script>
---------------------------------------------------
-- CSS
---------------------------------------------------
prompt <style type="text/css">
prompt   body {font-family: Arial,Helvetica,Geneva,sans-serif; font-size:8pt; text-color: black; background-color: white;}
prompt   table.sql {font-size:8pt; color:#333366; width:70%; border-width: 2px; border-color: #000000; border-collapse: collapse; margin-left:10px;} 
prompt   th {border-width: 1px; background-color:#d9d9d9; padding: 3px; border-style: solid; border-color: #000000;} 
prompt   tr:nth-child(even) {background: #f2f2f2}
prompt   tr:nth-child(odd) {background: #FFFFFF}
prompt   tr:hover {color:black; background:#e6f2ff;}
prompt   td {border-width: 1px; padding: 2px; border-style: solid; border-color: #000000; color:#000000;} 
prompt   th.gcharttab {font-size:8pt;font-weight:bold; background: linear-gradient(to top, #9494b8 0%, #c2c2d6 100%);}
prompt   td.gcharttab {font-size:8pt;}
prompt   h1 {font-size:16pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px; text-align:center;}
prompt   h2 {font-size:12pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px;}
prompt   h3 {font-size:10pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px;}
prompt   pre {font:8pt monospace;Monaco,"Courier New",Courier;}
prompt   font.footnote {font-size:8pt; font-style:italic; color:#555;}
prompt   li.footnote {font-size:8pt; font-style:italic; color:#555;}
prompt   a.toc:link, a.toc:visited {font-size:10pt; font-weight:bold; text-decoration:none; color:#333366;}
prompt   a.toc:hover {font-size:10pt; font-weight:bold; text-decoration:underline; color:#333366; background-color:#eeeef6}
prompt   a.fnnav:link, a.fnnav:visited {font-size:8pt; font-weight:bold; text-decoration:none; color:#333366;font-style:italic;}
prompt   a.fnnav:hover {font-size:8pt; font-weight:bold; text-decoration:underline; color:#333366; background-color:#eeeef6;font-style:italic;}
prompt   div.tab1200 {width:1200px; resize: vertical; overflow:auto;}
prompt   div.tab100pct {width:100%; resize: vertical; overflow:auto;}
prompt   .google-visualization-table-table *  { font-size:8pt; }
prompt </style>
prompt </head>
---------------------------------------------------
-- BODY
---------------------------------------------------
prompt <body>
prompt <h1> CPU and memory utilization on &&hostname., interval: &&bdate - &&edate </h1>

set pagesize 0
set markup html off

prompt <h2 id="h_wait_class_time_single"> CPU and Memory utilization (%) </h2>
prompt <div id="div_cpumem_chart" style='width:100%; height: 500px;'></div>
prompt <font class="footnote">Graph note: drag to zoom, right click to reset. </font>
prompt <div id="div_cpumem_tab" class="tab100pct" style='height: 200px;'></div>
prompt <a class="fnnav" href="#h_toc">back to top</a>


prompt 
prompt <hr>
prompt </body>
prompt </html>
prompt 

spool off

begin
  :etime := dbms_utility.get_time();
end;
/

col host_grep_cmd new_val host_grep_cmd noprint
select 
  case 
    when upper('&&_EDITOR') = 'NOTEPAD' then
      'findstr "^ORA- ^PLS- ^SP2-"'
    else
      'grep -E "^ORA-|^PLS-|^SP2-"'
  end host_grep_cmd
from dual;

set termout on
prompt ==================================================================
prompt Generated report: &&MAINREPORTFILE
prompt ==================================================================

col "Elapsed time" form A15
select cast(numtodsinterval((:etime-:stime)/100,'SECOND') as interval day(0) to second(0)) as "Elapsed time" from dual;

prompt ==================================================================
prompt  Checking for errors in generated report...
prompt  If anything is reported below, charts will not display properly...
prompt ==================================================================
host &&host_grep_cmd &&MAINREPORTFILE

exit;
