set line 250
col lock_path form a35
col sid_serial form a13
col username form a15
col osinfo form a25 trunc
col program form a25 trunc
col wait_class form a12 trunc
col event form a25 trunc
col wait_time form a12
col obj_wait form A40
col sql_id form a13

accept min_wait_sec prompt 'Enter min. wait time in sec.  (default: 1): ' default '1'

select lpad(' ', level-1)||ltrim(sys_connect_by_path(sid, '->'),'->') lock_path
  ,sid||','||serial#||',@'||inst_id sid_serial
  ,username
  ,osinfo
  ,case when program like 'oracle%(J%' then (select job_name from dba_scheduler_running_jobs rj where rj.session_id=sid) else program end program
  ,sql_id
  ,wait_class
  ,event
  ,obj_wait
  ,wait_time
from (
  select sid,serial#,inst_id,username, process,osuser||'@'||machine osinfo,program,
    nvl(sql_id,prev_sql_id) sql_id,sql_address, blocking_session,blocking_instance, wait_class, event, p1, p2, p3,seconds_in_wait,
    case when row_wait_obj# > 0 then (select object_type||' - '||object_name from dba_objects where data_object_id = row_wait_obj#) ||chr(10) else null end||
    case when row_wait_row# > 0 then ('ROWID: '||dbms_rowid.rowid_create(1,row_wait_obj#,row_wait_file#,row_wait_block#,row_wait_row#)) else null end obj_wait,
    cast(numtodsinterval(seconds_in_wait,'SECOND') as interval day(0) to second(0)) wait_time
  from gv$session
  where blocking_session_status = 'VALID'
    and seconds_in_wait > &min_wait_sec
  union
  select sid,serial#,inst_id,username, process,osuser||'@'||machine osinfo,program,
    nvl(sql_id,prev_sql_id) sql_id,sql_address, blocking_session,blocking_instance, wait_class, event, p1, p2, p3,seconds_in_wait,
    case when row_wait_obj# > 0 then (select object_type||' - '||object_name from dba_objects where data_object_id = row_wait_obj#) ||chr(10) else null end||
    case when row_wait_row# > 0 then ('ROWID: '||dbms_rowid.rowid_create(1,row_wait_obj#,row_wait_file#,row_wait_block#,row_wait_row#)) else null end obj_wait,
    cast(numtodsinterval(seconds_in_wait,'SECOND') as interval day(0) to second(0)) wait_time
from gv$session
where (sid,inst_id) in (select blocking_session,blocking_instance from gv$session where blocking_session_status = 'VALID' and seconds_in_wait > &min_wait_sec)
) connect by nocycle prior sid=blocking_session and inst_id=blocking_instance
  start with blocking_session is null
order siblings by wait_time desc ;

