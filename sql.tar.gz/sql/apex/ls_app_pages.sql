set line 250 pagesize 200
col app_id form 99999
col page_name form A45
col page_title form A45
col last_updated_by form A12
col auth_required form A13
set verify off

accept WORKSPACE prompt 'Enter workspace name: '
accept APP_ID  prompt 'Enter application id: '

--------------------------------------------
-- pages
--------------------------------------------
select page_id
  ,page_name
  ,page_title
  ,regions reg_cnt#
  ,items item_cnt#
  ,buttons btn_cnt#
  ,to_char(last_updated_on,'YYYY-MM-DD HH24:MI') last_updated
  ,last_updated_by
  ,page_requires_authentication auth_required
from apex_application_pages
where workspace=upper(trim('&WORKSPACE'))
  and application_id=&APP_ID
order by page_id;

