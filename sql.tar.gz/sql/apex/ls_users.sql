set line 240 pagesize 200
col workspace form A12
col user_name form A12
col first_last_n form A20
col email form A35
col is_admin form A8
col is_dev form A6
col locked form A6
--------------------------------------------
-- apex users
--------------------------------------------
select workspace_name as workspace
  ,user_name
  ,first_name||' '||last_name as first_last_n
  ,email
  ,to_char(date_created,'YYYY-MM-DD HH24:MI') created_on
  ,is_admin
  ,is_application_developer is_dev
  ,account_locked locked
  ,to_char(date_last_updated,'YYYY-MM-DD HH24:MI') last_updated
  ,to_char(account_expiry,'YYYY-MM-DD HH24:MI') account_expiry
from apex_workspace_apex_users
order by workspace,user_name;

