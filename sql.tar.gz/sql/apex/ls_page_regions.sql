accept APP_ID  prompt 'Enter application id: '
accept PAGE_ID prompt 'Enter page id: '

set line 250 pagesize 200 verify off
col page_name form A40 wor
col region_name form A40 wor
col source_type form A15
col query_type form A12
col table_owner form A10
col table_name form A10
col where_clause form A30
col region_source form A70 wor
--------------------------------------------
-- page regions
--------------------------------------------
select page_id,page_name
  ,region_name
  ,source_type
  ,query_type, table_owner, table_name, where_clause
  ,region_source
from apex_application_page_regions
where application_id=&APP_ID
and page_id=&PAGE_ID;

