set line 240 pagesize 200
col workspace form A12
col app_id form 99999
col application_name form A40
col alias form A12
col auth_scheme form A30
col compat_mode form A11
--------------------------------------------
-- apps
--------------------------------------------
select workspace
  ,application_id as app_id
  ,application_name
  ,alias
  ,authentication_scheme_type auth_scheme
  ,to_char(last_updated_on,'YYYY-MM-DD HH24:MI') last_updated
  ,pages page_cnt#
  ,compatibility_mode compat_mode
from apex_applications
where workspace_id > 1e6
order by workspace,application_id;

