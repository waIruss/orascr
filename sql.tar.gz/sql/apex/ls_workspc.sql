set line 240 pagesize 200
col workspace_id form 999999999999999999999
col workspace form A12
col schemas form A60
--------------------------------------------
-- workspaces
--------------------------------------------
select workspace_id,workspace,to_char(created_on,'YYYY-MM-DD HH24:MI') created_on
  ,applications as app_cnt#
  ,application_pages as page_cnt#
  ,apex_users as users_cnt#
  ,(select listagg(schema,chr(10)) within group (order by schema_created) from apex_workspace_schemas aws where aws.workspace_id=aw.workspace_id group by workspace_id) schemas
from apex_workspaces aw
where workspace_id > 1e6;

