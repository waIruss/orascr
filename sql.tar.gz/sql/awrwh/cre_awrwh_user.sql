set verify off 

def usname="dxc_awrwh" 
create user &usname identified by "xY5gd^v3p2XpM9";
grant CREATE SESSION to &usname;
grant EXECUTE ON SYS.DBMS_SWRF_INTERNAL to &usname;
grant EXECUTE ON UTL_FILE to &usname;
grant EXECUTE ON DBMS_LOCK to &usname;
grant EXECUTE ON DBMS_WORKLOAD_REPOSITORY to &usname;
grant RESOURCE to &usname;
grant SCHEDULER_ADMIN to &usname;
grant CREATE PUBLIC SYNONYM to &usname;
grant SELECT ANY DICTIONARY to &usname;
grant CREATE ANY INDEX to &usname;
grant CREATE ANY TABLE, ALTER ANY TABLE, DROP ANY TABLE to &usname;
grant SELECT ANY TABLE, INSERT ANY TABLE, UPDATE ANY TABLE to &usname;
grant CREATE ANY SEQUENCE, DROP ANY SEQUENCE, SELECT ANY SEQUENCE to &usname;
grant CREATE ANY PROCEDURE, EXECUTE ANY PROCEDURE, DROP ANY PROCEDURE to &usname;
grant CREATE ANY DIRECTORY, DROP ANY DIRECTORY to &usname;
alter user &usname profile service_profile;


GRANT INHERIT PRIVILEGES ON USER SYS TO DBSNMP;

conn dxc_awrwh/"xY5gd^v3p2XpM9"

show user;

