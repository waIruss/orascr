Rem
Rem $Header: emdb/source/oracle/sysman/emdrep/sql/db/latest/caw/caw_extract_pkgdef.sql /main/10 2020/08/03 10:41:00 abhagaba Exp $
Rem
Rem caw_extract_pkgdef.sql
Rem
Rem Copyright (c) 2013, 2020, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      caw_extract_pkgdef.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    prakiran    07/23/20 - Add public synonyms
Rem    prakiran    05/08/20 - Bumping up pkg version
Rem    abhagaba    03/18/20 - Fixing JIRA 8774 - Adding support for non SYSDBA
Rem                           credentials while adding source to AWR warehouse
Rem    prakgupt    09/28/15 - fix deadlock at extract due to unavailable space
Rem    shmahaja    04/02/15 - Bug 19188917 - SNAPSHOT UPLOAD INTERVAL SET TO 1
Rem                           HOUR DOES NOT UPLOAD SNAPSHOTS IN TIME
Rem    shmahaja    03/30/15 - let any user (dba) run extract scheduler job
Rem    shmahaja    03/12/15 - update pkg version
Rem    prakiran    07/21/14 - Merge changes from PS3 patch txn (already merged
Rem                           in 13.1)
Rem    prakiran    06/27/14 - Backport prakgupt_awr_combined_13_1 from
Rem                           st_emgc_pt-13.1mstr
Rem    prakiran    05/29/14 - Support synchronous job run
Rem    prakiran    03/27/14 - Add option for 'schedule now'
Rem    prakiran    03/01/14 - Enhance retry logic
Rem    prakiran    02/19/14 - Start time randomization, Test mode changes
Rem    shmahaja    02/07/14 - have to use sys_guid()
Rem                           instead of db_host, db_name, instance_name
Rem    prakiran    11/12/13 - Package for Central AWR Extract
Rem    prakiran    11/12/13 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

set serveroutput on size 1000000;

CREATE OR REPLACE PACKAGE DBSNMP.MGMT_CAW_EXTRACT authid current_user
IS

  -- * IMPORTANT *
  -- Supports creating a singleton DBMS_SCHEDULER job 

  -- This package version must be in sync with CAWRConstants 
  CAW_RELEASE_VERSION constant varchar2(32) := '13.4.5';

  -- CAW_EXTRACT_JOB_OWNER constant varchar2(32) := 'DBSNMP';
  CAW_EXTRACT_JOB_NAME constant varchar2(32) := 'MGMT_CAW_EXTRACT_JOB';
  CAW_EXTRACT_JOB_DESC constant varchar2(128) := 'Scheduler Job to extract AWR data to staging location for CAW';
  CAW_EXTRACT_DUMP_DIR constant varchar2(30) := 'CAW_EXTR';  -- TODO: correct default dir
  CAW_EXTRACT_SCHEDULE constant varchar2(255) := 'FREQ=HOURLY;INTERVAL=3'; -- runs every 3 hour
  CAW_EXTRACT_INTERVAL constant number := 3;
  -- status values
  CAW_EXTRACT_PURGED constant number := -1; 
  CAW_EXTRACT_BEGIN constant number := 1;
  CAW_EXTRACT_SUCCESS constant number := 2;
  CAW_EXTRACT_ERROR constant number := 3;
  CAW_EXTRACT_NON_RECOVERABLE constant number := 99;
  CAW_TRANSFER_SUCCESS constant number := 5;
  -- custom exceptions
  CAW_NO_NEW_SNAPSHOTS constant number := -20137;
  CAW_INSUFF_SNAPSHOTS constant number := -20138;
  CAW_ERR	       constant number := -20139;
  CAW_NO_SUCH_JOB      constant number := -20140;
  -- others
  MAX_SNAP_RANGE constant number := 500;
  MAX_TRANSFER_PENDING constant number := 10;
  MAX_TRANSFER_PENDING_SIZE constant number := 2*1024; -- in MB
  MAX_RETRY constant number := 3;
  TEST_MODE constant number := 1;

  ---------------------------------------------------------------------------
  -- Setup CAW Extract
  ---------------------------------------------------------------------------

  procedure setup(extract_interval in number := CAW_EXTRACT_INTERVAL,
                  start_now in varchar2 := 'N');

  procedure setup(
            extract_schedule in varchar2 := CAW_EXTRACT_SCHEDULE,
            start_now in varchar2 := 'N',
            start_time in timestamp := null);

  function get_version return varchar2;

  ---------------------------------------------------------------------------
  -- Scheduler Job Management                                              --
  ---------------------------------------------------------------------------

  -- Return CAW job name if exists
  function get_job_name(ret_new boolean := false) return varchar2;

  function is_scheduled return number;

  -- run job
  -- if is_synch = 'Y', wait for the job to complete
  procedure run_job(is_synch in varchar2 := 'N');

  -- run job synchronously
  procedure run_job_now;

  -- remove old dump and log
  procedure remove_old_dump(filename in varchar2);

  function extract_filename(filename in varchar2) return varchar2;

  -- setup job
  procedure schedule_job(
      extract_schedule in varchar2 := CAW_EXTRACT_SCHEDULE,
      start_now        in varchar2 := 'N',
      start_time       in timestamp := null);

  -- remove job
  procedure drop_job;

  -- clean up schema
  procedure drop_schema;

  procedure create_schema;

  ---------------------------------------------------------------------------
  -- Scheduler Job Internals                                               --
  ---------------------------------------------------------------------------
 
  -- execute on every job run
  procedure run_extract;

  -- AWR extract wrapper
  procedure awr_extract(
	dump_file	in varchar2,
	dump_dir	in varchar2,
	begin_snap 	in number,
	end_snap 	in number,
	dbid	 	in number,
        is_non_sys      in boolean default false);
 

  function inst_tzr return varchar2;

  function system_tzr return varchar2; 

  type extract_metadata is record
  (
	extract_id	number,
	dbid		number,
	begin_snap	number,
	end_snap	number,
	start_time	timestamp,
	end_time 	timestamp,
	filename	varchar2(256),
	status 		integer
  );

  type e_metadata_tab is table of extract_metadata;

  procedure retry_all_non_recov(
        em_id in number,
        support_non_sys in boolean default false);
 
  procedure update_metadata(
        extract_id in number,
        status in number,
        err_msg in varchar2 := '',
        log_file in varchar2 := ''
  );

  procedure save_properties(
        em_id            in number,
        dump_dir_path    in varchar2,  
        upload_interval  in number, 
        extract_schedule in varchar2, 
        max_snaps        in number,
        flag             in number);

  function get_dump_size(extract_id number)
	return number;

  type caw_props_t is table of varchar2(4000) index by varchar2(64);

  procedure set_property(
        name    in varchar2,
        value   in varchar2);

END MGMT_CAW_EXTRACT;
/
show errors

