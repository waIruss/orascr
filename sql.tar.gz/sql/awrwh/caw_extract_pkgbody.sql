Rem
Rem $Header: emdb/source/oracle/sysman/emdrep/sql/db/latest/caw/caw_extract_pkgbody.sql /main/8 2020/08/03 10:41:00 abhagaba Exp $
Rem
Rem caw_extract_pkgbody.sql
Rem
Rem Copyright (c) 2013, 2020, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      caw_extract_pkgbody.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    prakiran    07/23/20 - Add public synonyms
Rem    abhagaba    10/09/19 - for pdbs, fetching dbid from v dollar containers
Rem                           while extract
Rem    prakgupt    09/28/15 - fix deadlock at extract due to unavailable space
Rem    shmahaja    04/02/15 - Bug 19188917 - SNAPSHOT UPLOAD INTERVAL SET TO 1
Rem                           HOUR DOES NOT UPLOAD SNAPSHOTS IN TIME
Rem    shmahaja    03/30/15 - let any user (dba) run extract scheduler job
Rem    prakiran    07/21/14 - Merge changes from PS3 patch txn (already merged
Rem                           in 13.1)
Rem    prakiran    06/26/14 - Fix run_job_now
Rem    prakiran    06/04/14 - Bug 18814414 - preserve filename during retry
Rem    prakiran    06/03/14 - Synch support for run_ETL_now
Rem    vgoli       05/30/14 - remove precision for retry count columns
Rem    prakiran    05/29/14 - non-SYSDBA req for adding src dbs
Rem    prakiran    04/15/14 - Support 'run ETL now'
Rem    prakiran    03/27/14 - Add option for 'schedule now'
Rem    prakiran    03/19/14 - Use dynamic properties
Rem    prakiran    03/18/14 - Fix query for fetching instance number
Rem    shmahaja    03/18/14 - continue does not exist on 10.2
Rem    prakiran    03/12/14 - Add instance number; Add properties table
Rem    prakiran    02/26/14 - Enhance retry logic
Rem    prakiran    02/21/14 - fix retry logic
Rem    prakiran    02/19/14 - Start time randomization, Test mode changes
Rem    shmahaja    02/07/14 - have to use em_id, target_name, target_type
Rem                           instead of db_host, db_name, instance_name
Rem    prakiran    11/12/13 - Package for Central AWR Extract
Rem    prakiran    11/12/13 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

set serveroutput on size 1000000;

CREATE OR REPLACE PACKAGE BODY DBSNMP.MGMT_CAW_EXTRACT
IS

-- * IMPORTANT *
-- EM Package to schedule job  and store it in dbsnmp schema
-- Supports creating a singleton DBMS_SCHEDULER job 
-- TODO: Maintenance Window option


-- CAW version
function get_version return varchar2 is
begin
	return CAW_RELEASE_VERSION;
end;

-- get the owner of the extract job.
function get_extract_job_owner
return varchar2
is
  v_job_owner varchar2(256);
  v_sql     varchar2(32767);
begin
  v_sql := ' select owner ' ||
           '   from dba_scheduler_jobs ' ||
           '  where job_name = :1 ' ||
           '    and job_subname is null';
  execute immediate v_sql
               into v_job_owner
              using CAW_EXTRACT_JOB_NAME;
  return v_job_owner;
end get_extract_job_owner;

-- Return job name of default job
-- ret_new used for creating a new job eg inside schedule_job
function get_job_name(ret_new boolean := false)
  return varchar2
is
  job_name varchar2(256);
begin
    if ret_new then
      job_name := USER || '.' || CAW_EXTRACT_JOB_NAME;
    elsif is_scheduled() > 0 then
      job_name := get_extract_job_owner() || '.' || CAW_EXTRACT_JOB_NAME;
    end if;
    return job_name;
END get_job_name;

-- log errors
procedure log_error( 
	extract_id in number,
	err_msg in varchar2,
	log_file in varchar2)
is
	sql_txt varchar2(4000);
begin
	sql_txt := 'update dbsnmp.caw_extract_metadata set err_msg = :1, log_file = :2' ||
			' where extract_id = :3';
	execute immediate sql_txt using err_msg, log_file, extract_id;
	commit;
end log_error;	

-- get dump file size (in bytes)
function get_dump_size(extract_id number)
return number
is
	l_is_exist boolean;
	l_dump_size number := null;
	l_block_size number;
	qry_txt varchar2(4000);
	l_filename varchar2(256);
begin
	qry_txt := 'select filename from dbsnmp.caw_extract_metadata where extract_id = :1';
	execute immediate qry_txt into l_filename using extract_id;

	begin
		UTL_FILE.FGETATTR(CAW_EXTRACT_DUMP_DIR, l_filename, l_is_exist, l_dump_size, l_block_size);
	exception 
		when others then
			dbms_output.put_line('Error fetching dump file size: ' || sqlerrm(sqlcode));
	end;
	return l_dump_size;
end get_dump_size; 

-- update entry in metadata table
procedure update_metadata(
        extract_id in number,
        status in number,
        err_msg in varchar2 := '',
        log_file in varchar2 := '')
is
        qry_txt varchar2(4000);
	l_dump_size number;
begin
	-- update file size for successful extract
	l_dump_size := case 
			when status = CAW_EXTRACT_SUCCESS
			then get_dump_size(extract_id)
			else null
			end;
        qry_txt := 'update DBSNMP.CAW_EXTRACT_METADATA ' ||
                'set END_TIME = systimestamp, STATUS = :1,  ' ||
                'ERR_MSG = :2, LOG_FILE = :3, DUMP_SIZE = nvl(:4, DUMP_SIZE) ' ||
                'where EXTRACT_ID = :5';
        execute immediate qry_txt using status, err_msg, log_file, l_dump_size, extract_id;
        commit;
end update_metadata;

/* Retry all non-recoverable extracts until purged */
procedure retry_all_non_recov(
	em_id in number,
	support_non_sys in boolean := false )
is
	l_md 	e_metadata_tab := e_metadata_tab();
	qry 	varchar2(4000);
	l_dmpfile varchar2(256) := null;
    	l_begin_snap number;
   	l_end_snap number;
	l_new_begin number;
	l_extract_id number;
	l_dbid number;
	dump_name_sep varchar2(1) := '_';
begin
	begin
		-- get a list of all non-recoverable extracts
		qry := 'select extract_id, dbid, begin_snap_id, end_snap_id, start_time, end_time, filename, status ' ||
		       'from dbsnmp.caw_extract_metadata where status in (:1) ' ||
		       'order by begin_snap_id';
		execute immediate qry 
		bulk collect into l_md using CAW_EXTRACT_NON_RECOVERABLE;
		if l_md.COUNT = 0 then
			raise no_data_found;
		end if;
	exception 
		when others then
			dbms_output.put_line('No non-recoverable extracts to retry. ');
			return;
	end;
	
	dbms_output.put_line('Retrying any non-recoverable extracts... ');
	-- for each extract
	for i in 1..l_md.COUNT
	loop
		-- get begin_snap and end_snap
		l_dbid := l_md(i).dbid;
		l_extract_id := l_md(i).extract_id;
		l_begin_snap := l_md(i).begin_snap;
		l_end_snap := l_md(i).end_snap;
		l_dmpfile := extract_filename(l_md(i).filename);

		-- remove any leftovers
		remove_old_dump(l_dmpfile);

		-- determine new unpurged begin_snap and end_snap
		begin
			qry := 'select min(snap_id) from DBA_HIST_SNAPSHOT ' ||
			       'where snap_id >= :1 and snap_id < :2 ' ||
			       'and dbid = :3 ';
			execute immediate qry
			into l_new_begin 
			using l_begin_snap, l_end_snap, l_dbid;
		exception 
			when others then
				l_new_begin := null;
		end;
		
		-- if new snap range is invalid, mark metadata entry as purged. Skip.
		if l_new_begin is null then
			dbms_output.put_line('Cannot recover purged snapshots in range [' || 
						l_begin_snap || ', ' || l_end_snap || '). Skipping. ');
			update_metadata(l_extract_id, CAW_EXTRACT_PURGED);
			goto end_loop;
		end if;

		-- if snap range has changed (partial purge), generate new dmp file, update MD entry.
		if l_begin_snap != l_new_begin then
			l_begin_snap := l_new_begin;
		
			-- generate new file name	
		 	l_dmpfile := em_id || dump_name_sep ||
                     		sys_guid || dump_name_sep ||
                     		l_dbid || dump_name_sep ||
                     		l_begin_snap || dump_name_sep ||
                     		l_end_snap;
		end if;
		
		dbms_output.put_line('Generating dump file: ' || l_dmpfile || ' ');

		qry := 'update DBSNMP.CAW_EXTRACT_METADATA ' ||
               'set START_TIME = :1, FILENAME = :2, E_RETRY_COUNT = E_RETRY_COUNT + 1, ' ||
		       'begin_snap_id = :3, end_snap_id = :4, status = :5, ' ||
               'instance_number = (select instance_number from v$instance) ' ||
               'where EXTRACT_ID = :6';
                execute immediate qry using systimestamp, l_dmpfile || '.dmp', 
			l_begin_snap, l_end_snap, CAW_EXTRACT_BEGIN, l_extract_id;
		commit;

		-- awr extract
	        begin
        	        awr_extract(
                	        dump_file       =>  l_dmpfile, 
                        	dump_dir        =>  CAW_EXTRACT_DUMP_DIR,
	                        begin_snap      =>  l_begin_snap,
        	                end_snap        =>  l_end_snap,
                	        dbid            =>  l_dbid,
				is_non_sys	=>  support_non_sys
	                );
        	exception
                	when others then
                        	-- NOTE: log file may not  be created in some cases
	                        dbms_output.put_line('Errors during non-recov AWR Extract: ' || sqlerrm(sqlcode));
        	                update_metadata(l_extract_id, CAW_EXTRACT_NON_RECOVERABLE, sqlerrm(sqlcode), l_dmpfile || '.log');
                	        goto end_loop;
        	end;

		update_metadata(l_extract_id, CAW_EXTRACT_SUCCESS);
	<<end_loop>>
	null;
	end loop;
	commit;

end retry_all_non_recov;

-- drop all schema and dir obj
procedure drop_schema
is
begin
	execute immediate 'DROP TABLE DBSNMP.CAW_EXTRACT_METADATA';
	execute immediate 'DROP TABLE DBSNMP.CAW_EXTRACT_PROPERTIES';
	execute immediate 'DROP SEQUENCE DBSNMP.CAW_EXTRACT_ID_SEQ';
	execute immediate 'DROP DIRECTORY ' || CAW_EXTRACT_DUMP_DIR; 	
end drop_schema;

-- Create CAW schema on source database (if does not exist)
-- To re-create schema, drop schema first
procedure create_schema
is
	sql_txt varchar2(4000);
	l_exists number;
begin
	-- ensure metadata table exists
  	select count(*) into l_exists from dba_tables 
		where table_name = 'CAW_EXTRACT_METADATA' and owner =  'DBSNMP';
  	if l_exists = 0 then
    		execute immediate 
			'CREATE TABLE DBSNMP.CAW_EXTRACT_METADATA(
                EXTRACT_ID            NUMBER,
				DBID                  NUMBER,
				INSTANCE_NUMBER       NUMBER,
				BEGIN_SNAP_ID         NUMBER,
				END_SNAP_ID           NUMBER,
				START_TIME            TIMESTAMP,
				END_TIME              TIMESTAMP,
				FILENAME              VARCHAR2(256),
				DUMP_SIZE             NUMBER,
				STATUS                INTEGER,
			    JOB_ID		RAW(16),
				EXEC_ID		RAW(16),
				T_START_TIME	DATE,
				T_END_TIME	DATE,
				E_RETRY_COUNT	NUMBER DEFAULT 0,
				T_RETRY_COUNT	NUMBER DEFAULT 0,
                ERR_MSG         VARCHAR2(4000),
                LOG_FILE        VARCHAR2(2000),
				CONSTRAINT CAW_EXTR_MD_PK  PRIMARY KEY (EXTRACT_ID) USING INDEX
                     	)';
    		dbms_output.put_line('Metadata Table created successfully.');
  	else
    		dbms_output.put_line('Metadata Table already exists.');
  	end if;

        -- ensure properties table exists
        select count(*) into l_exists from dba_tables
                where table_name = 'CAW_EXTRACT_PROPERTIES' and owner =  'DBSNMP';
        if l_exists = 0 then
                execute immediate
                        'CREATE TABLE DBSNMP.CAW_EXTRACT_PROPERTIES(
                                PROPERTY_NAME	VARCHAR2(64),
                                PROPERTY_VALUE	VARCHAR2(4000),
				CONSTRAINT CAW_EXTR_PROP_UK UNIQUE (PROPERTY_NAME) USING INDEX
                        )';
                dbms_output.put_line('Properties Table created successfully.');
        else
                dbms_output.put_line('Properties Table already exists.');
        end if;

	-- ensure sequence exists
	select count(*) into l_exists from dba_sequences
                where sequence_name = 'CAW_EXTRACT_ID_SEQ' and sequence_owner =  'DBSNMP';
        if l_exists = 0 then
                execute immediate
			'CREATE SEQUENCE DBSNMP.CAW_EXTRACT_ID_SEQ
                          	MINVALUE 1
                          	START WITH 1
                          	INCREMENT BY 1
	                        NOMAXVALUE
        	                NOCYCLE
                	        CACHE 20
                        	NOORDER';
                dbms_output.put_line('Metadata Sequence created successfully.');
        else
                dbms_output.put_line('Metadata Sequence already exists.');
        end if;

end create_schema;

-- create directory object for dump dir
procedure create_dir_obj(dump_dir_path in varchar2)
is
	sql_txt  varchar2(4000);
begin 
	-- ensure dump dir exists
	sql_txt := 'create or replace directory ' || CAW_EXTRACT_DUMP_DIR || 
		   ' as ''' || dump_dir_path || '''';
	execute immediate sql_txt;
	--dbms_output.put_line('Created dump dir object for: ' || dump_dir_path);
end create_dir_obj;

-- save all user-specified properties
procedure save_properties(
	em_id		 in number,
	dump_dir_path    in varchar2,  -- EM staging dir from job
	upload_interval  in number, -- in hrs (TEST_MODE - in mins)
	extract_schedule in varchar2, 
	max_snaps        in number,
        flag 		 in number) -- used for TEST_MODE
is
	qry_txt varchar2(4000);
        caw_props caw_props_t;
        i varchar2(64);
begin
        caw_props('EM_ID') := em_id;
        caw_props('CAW_EXTRACT_DUMP_DIR') := dump_dir_path;
        caw_props('CAW_UPLOAD_INTERVAL') := upload_interval;
        caw_props('CAW_EXTRACT_INTERVAL') := extract_schedule;
        caw_props('MAX_SNAP_RANGE') := max_snaps;
        caw_props('TEST_FLAG') := flag;

        qry_txt := 'insert into dbsnmp.caw_extract_properties(property_value, property_name) values(:1, :2)';

        i := caw_props.first;
        while i is not null loop
                execute immediate qry_txt using caw_props(i), i;
                i := caw_props.next(i);
        end loop;

	commit;

end save_properties;

-- update all user-specified properties
procedure update_properties(
        em_id            in number,
        dump_dir_path    in varchar2,  -- EM staging dir from job
        upload_interval  in number, -- in hrs (TEST_MODE - in mins)
        extract_schedule in varchar2,
        max_snaps        in number,
        flag             in number) -- used for TEST_MODE
is
        qry_txt varchar2(4000);
	caw_props caw_props_t;
	i varchar2(64);
begin
	caw_props('EM_ID') := em_id;
	caw_props('CAW_EXTRACT_DUMP_DIR') := dump_dir_path;
	caw_props('CAW_UPLOAD_INTERVAL') := upload_interval;
	caw_props('CAW_EXTRACT_INTERVAL') := extract_schedule;
	caw_props('MAX_SNAP_RANGE') := max_snaps;
	caw_props('TEST_FLAG') := flag;

        qry_txt := 'update dbsnmp.caw_extract_properties set property_value = nvl(:1, property_value) where property_name = :2';

	i := caw_props.first;
	while i is not null loop
		execute immediate qry_txt using caw_props(i), i;
		i := caw_props.next(i);
	end loop;

	commit;
	
end update_properties;

-- insert or update a property
procedure set_property(
           name in varchar2,
           value in varchar2)
is
    qry_txt varchar2(4000);
begin
    begin
        qry_txt := 'insert into dbsnmp.caw_extract_properties(property_name, property_value) values(:1, :2)';
        execute immediate qry_txt using name, value;
    exception
        when DUP_VAL_ON_INDEX then
            qry_txt := 'update dbsnmp.caw_extract_properties set property_value = :1 where property_name = :2';
            execute immediate qry_txt using value, name;
    end;
    commit;
end set_property;

-- give access to the scheduler job to all dbas
procedure grant_job_access
is
  sql_get_dba varchar2(32767);
  sql_grant   varchar2(32767);
  jobname     varchar2(256);
  type v_string_list is table of varchar2(256);
  dba_list v_string_list;
begin
  sql_get_dba := ' select grantee ' ||
                 '   from dba_role_privs ' ||
                 '  where granted_role = :1 ';
  if (is_scheduled() > 0) then
    jobname := get_job_name();
    execute immediate sql_get_dba
    bulk collect into dba_list
                using 'DBA';
    for i in 1..dba_list.count loop
      sql_grant := 'grant alter on ' || jobname || ' to ' || dba_list(i);
      begin
        execute immediate sql_grant;
      exception
        when others then
          dbms_output.put_line('unable to grant access on job ' || jobname || ' to ' || dba_list(i));
          dbms_output.put_line(sqlerrm(sqlcode));
      end;
    end loop;
  end if;
end grant_job_access;

-- if upload interval <6 hrs then use it else schedule the job every 3 hrs
function create_extract_schedule(extract_interval in number)
return varchar2
is
  extr_sch varchar2(30);
  extr_int number;
begin
  extr_int := extract_interval;
  if extr_int >= 2*CAW_EXTRACT_INTERVAL then
    extr_int := CAW_EXTRACT_INTERVAL;
  end if;
  extr_sch := 'FREQ=HOURLY;INTERVAL=' || extr_int;
  return extr_sch;
end create_extract_schedule;

procedure setup(extract_interval in number := CAW_EXTRACT_INTERVAL,
                start_now        in varchar2 := 'N')
is
  v_start_time timestamp := null;
begin
  if start_now = 'N' then
    dbms_random.seed(to_char(systimestamp, 'YYYYDDMMHH24MISSFFFF'));
    v_start_time := systimestamp + interval '1' hour * dbms_random.value(0, extract_interval);
  end if;
  setup(create_extract_schedule(extract_interval), start_now, v_start_time);
end setup;

-- Setup CAW Extract
procedure setup(
                extract_schedule in varchar2 := CAW_EXTRACT_SCHEDULE,
                start_now in varchar2 := 'N',
                start_time in timestamp := null)
is
begin
    create_schema;  -- if not exists
    schedule_job(extract_schedule, start_now, start_time);
    if (upper(USER) = 'SYS') then
      grant_job_access();
    end if;
end setup;

-- Schedule Job
procedure schedule_job(extract_schedule in varchar2 := CAW_EXTRACT_SCHEDULE,
                       start_now        in varchar2 := 'N',
                       start_time       in timestamp := null)
is
  jobname varchar2(256);
  p_job_action varchar2(32767);
  l_start_date timestamp := null;
BEGIN
	set_property('extract_schedule', extract_schedule);
    	jobname := get_job_name(true);

  l_start_date := start_time;
	if start_now = 'N' then
		-- randomize start_time
    if l_start_date is null then
		  dbms_random.seed(to_char(systimestamp, 'YYYYDDMMHH24MISSFFFF'));
		  l_start_date := systimestamp + interval '1' hour * trunc(dbms_random.value(1, 24));
    end if;
	end if;

	/* For now, always begin by dropping previous job */
	drop_job();

	p_job_action := 'begin dbsnmp.mgmt_caw_extract.run_extract; end;';
                            
	 -- setup dbms schedular job 
  	if (is_scheduled() = 0) then
      		dbms_scheduler.create_job(
          		job_name => jobname,
          		job_type => 'PLSQL_BLOCK',
          		job_action => p_job_action,  -- will just proc name do?
			start_date => l_start_date,
			repeat_interval => extract_schedule,
          		comments => CAW_EXTRACT_JOB_DESC, -- TODO: fix desc
          		auto_drop => FALSE,
          		enabled => TRUE);
      		dbms_scheduler.set_attribute( name => jobname, attribute => 'logging_level', value => DBMS_SCHEDULER.LOGGING_OFF);
	      	dbms_scheduler.set_attribute( name => jobname, attribute => 'job_weight', value => 1);
      		dbms_scheduler.set_attribute( name => jobname, attribute => 'instance_stickiness', value => FALSE);
	      	dbms_scheduler.set_attribute( name => jobname, attribute => 'stop_on_window_close', value => FALSE);
      		dbms_scheduler.set_attribute( name => jobname, attribute => 'restartable', value => TRUE);
	      	dbms_scheduler.enable( jobname );
	end if;

END schedule_job;

-- Check if scheduled
function is_scheduled
  return number
is
  num_jobs NUMBER := 0;
  v_sql    varchar2(32767);
begin
  v_sql := ' SELECT count(*) ' ||
           '   FROM dba_scheduler_jobs ' ||
           '  WHERE job_name = :1 ' ||
           '    AND job_subname is NULL';
  execute immediate v_sql
               into num_jobs
              using CAW_EXTRACT_JOB_NAME;

  return num_jobs;

EXCEPTION
    when others then
        raise;
end is_scheduled;

-- Run now
procedure run_job(is_synch in varchar2 := 'N')
is
  jobname varchar2(256);
  job_running exception;
  pragma exception_init(job_running, -27478);
begin
  if (is_scheduled() > 0 ) then
    jobname := get_job_name();
    begin
      dbms_scheduler.run_job(
          job_name => jobname,
          use_current_session =>
            case
              when is_synch = 'N' then FALSE 
              else TRUE
              end);
    exception
      when job_running then
        null;
      when others then
        dbms_output.put_line('Error running job ' || jobname || ' as user ' || USER);
        dbms_output.put_line(sqlerrm(sqlcode));
        raise;
    end;
  else
    dbms_standard.raise_application_error(CAW_NO_SUCH_JOB, 'NO EXTRACT JOB EXISTS');
  end if;
end run_job;

-- return true if extract job is running
function is_job_running return boolean
is
  qry_txt varchar2(4000);
  l_state varchar2(15);
  v_owner varchar2(256) := null;
begin
  if (is_scheduled > 0) then
    v_owner := get_extract_job_owner();
  end if;
  qry_txt := 'select state from dba_scheduler_jobs where owner = :1 and job_name = :2';
  execute immediate qry_txt into l_state using v_owner, CAW_EXTRACT_JOB_NAME;
  return l_state = 'RUNNING';
exception 
  when others then
    dbms_standard.raise_application_error(CAW_NO_SUCH_JOB, 'NO EXTRACT JOB EXISTS');
end is_job_running;

-- Run Asynch Extract job for run_ETL_now
-- No exception means a snapshot dump was generated
procedure run_job_now
is
  l_status number;
  l_err_msg varchar2(4000);
  qry_txt varchar2(4000);
  last_extract_id number;
begin
  -- get last extract id (if any)
  begin
	qry_txt := 'select nvl(max(extract_id), -1) from dbsnmp.caw_extract_metadata';
	execute immediate qry_txt into last_extract_id;
  exception
	when others then null;
  end;

  -- attempt to run my job
  set_property('run_etl_now', 'true');
	run_job;

  -- wait for job to start running (max 1 m)
  for i in 1..2
  loop
        exit when is_job_running;
        execute immediate 'begin dbms_lock.sleep(30); end;'; -- sleep for 30 s
  end loop;

  -- wait for my job or already running job to finish
  loop
        exit when not is_job_running;
        execute immediate 'begin dbms_lock.sleep(30); end;'; -- sleep for 30 s
  end loop;

  -- check if any new dump was generated post proc call
  begin
	qry_txt := 'select status, err_msg from dbsnmp.caw_extract_metadata ' || 
		   'where extract_id  > :1 and rownum < 2';
	execute immediate qry_txt into l_status, l_err_msg using last_extract_id;	
  exception
	when no_data_found then
		-- if no newer metadata entry, assume there were no new snapshots 
		-- TODO: edge case - when last extract was abrupted and end_time not updated	
		dbms_standard.raise_application_error(
	    		CAW_NO_NEW_SNAPSHOTS, 'NO NEW SNAPSHOTS TO EXTRACT');
	when others then
		raise;
  end;
	
  if l_status != CAW_EXTRACT_SUCCESS then
	dbms_standard.raise_application_error(
	        CAW_ERR, 'ERRORS DURING EXTRACT: ' || l_err_msg);
  end if;

  dbms_output.put_line('run_job_now completed.');

end run_job_now;

-- Drop Job
procedure drop_job
is
    jobname varchar2(256);
BEGIN

    if (is_scheduled() > 0) then
      jobname := get_job_name();
      begin
        dbms_scheduler.drop_job( job_name => jobname, force => TRUE);
      exception
      when others then
        dbms_output.put_line('Unable to drop job ' || jobname || ' as ' || USER);
      end;
    end if;

END drop_job;

-- try remove old dump
procedure remove_old_dump(filename in varchar2)
is
begin
	begin
		utl_file.fremove(CAW_EXTRACT_DUMP_DIR, filename || '.dmp');
		utl_file.fremove(CAW_EXTRACT_DUMP_DIR, filename || '.log');
	exception
		-- file doesn't exist or can't be removed
		when others then
			null;
	end;
end remove_old_dump;

function extract_filename(filename in varchar2)
return varchar2
is
begin
	return substr(filename, 1, instr(filename, '.dmp')-1);
end extract_filename;

-- execute on each scheduler run
procedure run_extract
is
	l_found number;
	l_hostname varchar2(256);
	l_dbname varchar2(30);
	l_instname varchar2(30);
	l_dmpfile varchar2(256) := null;
	l_dmpdir varchar2(256);
	l_dbid number;
	l_bid number;
	last_eid number := null;
	l_eid number;
	l_extract_id number ;
	l_retry_count number;
	l_last_e_time timestamp;
	l_curr_time timestamp;
	l_time_diff number;
	l_status number := 0;
	qry_txt varchar2(4000);
    dump_name_sep varchar2(1) := '_';
    l_pending_count number := 0;
	l_is_retry boolean := false;
	my_inst_num number;
    caw_props caw_props_t;
    props_cur sys_refcursor;
    p_name varchar2(64);
    p_val varchar2(4000);
	l_pending_size number;
    em_id number;
    upload_interval number;
    max_snaps number;
    max_retry number;
    max_transfer_pending_mb number;
    dump_dir varchar2(4000);
    flag number;
    run_etl_now boolean := false;
    target_type varchar2(100);
    support_non_sys boolean := false;
    l_nonsys number;
begin
    dbms_output.put_line('Starting CAW Extract... ');

    -- get my instance number
    qry_txt := 'select instance_number from v$instance';
    execute immediate qry_txt into my_inst_num;

    -- fetch CAW properties
    qry_txt := 'select property_name, property_value from dbsnmp.caw_extract_properties';
    open props_cur for qry_txt;
    loop
        fetch props_cur into p_name, p_val;
        exit when props_cur%notfound;

        caw_props(p_name) := p_val;
    end loop;

    begin
        -- process CAW properties
        em_id := to_number(caw_props('em_id'));
        upload_interval := to_number(caw_props('upload_interval'));
        max_snaps := to_number(caw_props('max_snaps'));
        max_transfer_pending_mb := to_number(caw_props('max_transfer_pending_mb'));
        max_retry := to_number(caw_props('max_retry'));
        flag := to_number(caw_props('flag'));
        dump_dir := caw_props('dump_dir_' || my_inst_num);
        target_type := caw_props('target_type');
	begin
		run_etl_now := upper(caw_props('run_etl_now')) = 'TRUE';
	 	-- reset after use
		set_property('run_etl_now', 'FALSE');
	exception 
		when others then null;
	end;
	begin
		support_non_sys := upper(caw_props('support_non_sys')) = 'TRUE';
		dbms_output.put_line('Non-SYSDBA is supported. ');
	exception 
		when NO_DATA_FOUND then
			-- add property for the first time
			qry_txt := 'select count(*) from dba_procedures '  ||
				   'where object_name = :1 and procedure_name = :2';
			execute immediate qry_txt into l_nonsys
				using 'DBMS_WORKLOAD_REPOSITORY', 'EXTRACT';
			support_non_sys := (l_nonsys > 0);
			set_property('support_non_sys', case support_non_sys when true then 'TRUE' else 'FALSE' end);
		when others then null;
	end;
        -- create dir obj
        create_dir_obj(dump_dir);
        dbms_output.put_line('Fetched CAW properties. ');
    exception
        when others then
            dbms_output.put_line('Could not fetch CAW properties. Quitting. ');
            raise;
    end;


	-- DO NOT extract if pending transfers exceed max_transfer_pending_mb
        qry_txt := ' SELECT ROUND(SUM(DUMP_SIZE)/1024/1024, 2) ' || -- in MB
                   ' FROM DBSNMP.CAW_EXTRACT_METADATA ' ||
                   ' WHERE STATUS != :1';
	execute immediate qry_txt
                     into l_pending_size
		    using CAW_TRANSFER_SUCCESS;
	if l_pending_size >= max_transfer_pending_mb and not run_etl_now then
		dbms_output.put_line('Dump files pending transfer exceed ' || max_transfer_pending_mb || ' MB. Quitting. ');
		--retry_all_non_recov(em_id);
		return;
	end if;

	-- retry the most recent failure (incomplete / failed)
	dbms_output.put_line('Retrying most recent failure... ');
	begin
		qry_txt := 'select extract_id, dbid, begin_snap_id, end_snap_id, e_retry_count, filename ' ||
			   'from dbsnmp.caw_extract_metadata where status in (:1, :2) ';
		execute immediate qry_txt
			into l_extract_id, l_dbid, l_bid, l_eid, l_retry_count, l_dmpfile
			using CAW_EXTRACT_BEGIN, CAW_EXTRACT_ERROR;

		l_dmpfile := extract_filename(l_dmpfile);

		 -- remove any leftovers
                remove_old_dump(l_dmpfile);

		if l_retry_count >= max_retry then
			-- set non-recoverable error
			qry_txt := 'update dbsnmp.caw_extract_metadata set status = :1' ||
				   ' where extract_id = :2';
			execute immediate qry_txt using CAW_EXTRACT_NON_RECOVERABLE, l_extract_id;
			commit;
		else
			l_is_retry := true;
		end if;
	exception
		when others then
			dbms_output.put_line('No recent failure to retry. ');
			l_extract_id := null;
	end;
	
	if not l_is_retry then
	  begin 
		-- Fresh extract. Not a retry.	
 		dbms_output.put_line('Preparing for new Extract... ');

		-- get dbid
                if target_type = 'oracle_pdb' then
                    qry_txt := 'select dbid from v$containers';                    
                elsif support_non_sys then 
		    qry_txt := 'select dbms_workload_repository.local_awr_dbid from dual';
		else
		    qry_txt := 'select sys.dbms_swrf_internal.get_awr_dbid from dual';
		end if;
		execute immediate qry_txt into l_dbid;

		-- get begin snaphot id

		begin
			-- get last non-failed end_snap_id 
		        qry_txt := 'select max(end_snap_id)  from DBSNMP.CAW_EXTRACT_METADATA ' ||
				   'where dbid = :1 and status not in (:2, :3) ';
			execute immediate qry_txt 
				into last_eid 
				using l_dbid, CAW_EXTRACT_BEGIN, CAW_EXTRACT_ERROR;

			-- get last extract time
			qry_txt := 'select start_time from DBSNMP.CAW_EXTRACT_METADATA ' ||
				   'where dbid = :1 and end_snap_id = :2 ';
			execute immediate qry_txt
				into l_last_e_time
				using l_dbid, last_eid;
		exception
			when others then
				dbms_output.put_line('No earlier successful extract was found. ');
				l_last_e_time := null;
		end;

		-- get new begin snap id
		qry_txt := 'select min(snap_id) from DBA_HIST_SNAPSHOT where dbid = ' || l_dbid;

		if target_type = 'oracle_pdb' then
            		qry_txt := 'select min(snap_id) from CDB_HIST_SNAPSHOT where dbid = ' || l_dbid;
        	end if;

		if last_eid is not null then 
	        	-- not the first extract
			qry_txt := qry_txt || ' and snap_id > ' || last_eid;
		end if;
	
		execute immediate qry_txt into l_bid;

		-- if no new snapshots
		if l_bid is null then
			dbms_output.put_line('No new snapshots to extract. Quitting. ');
			/*
			if run_etl_now then
				dbms_standard.raise_application_error(
					CAW_NO_NEW_SNAPSHOTS, 'NO NEW SNAPSHOTS TO EXTRACT');
			end if;
			*/
			retry_all_non_recov(em_id, support_non_sys);
			return;
		end if;

		-- get end snapshot id (<= begin + MAX)
		-- TODO: refine this logic (don't rely on +/-)
		qry_txt := 'select max(snap_id) from DBA_HIST_SNAPSHOT where dbid = :1 ';

		if target_type = 'oracle_pdb' then
            		qry_txt := 'select max(snap_id) from CDB_HIST_SNAPSHOT where dbid = :1 ';
        	end if;		

		execute immediate qry_txt into l_eid using l_dbid;

		if l_eid is not null and (l_eid - l_bid + 1 > max_snaps) then
			-- max out 
			 dbms_output.put_line('Max snapshots available. ');
			l_eid := l_bid + max_snaps - 1;
		end if;

		l_curr_time := SYSTIMESTAMP;
		
		dbms_output.put_line('Upload interval is ' || upload_interval || ' ' ||
				     case when flag = TEST_MODE then 'min. ' else 'hr. ' end);
		-- check time elapsed since last extract
		-- (skip for first-time extract and catch up mode)
		if l_last_e_time is not null and (l_eid - l_bid + 1 < max_snaps) then
			if flag = TEST_MODE then
				-- compute time diff in minutes
				l_time_diff := extract(day from (l_curr_time - l_last_e_time))*24*60 +
	                                	extract(hour from (l_curr_time - l_last_e_time))*60 +
	                                	extract(minute from (l_curr_time - l_last_e_time));
				 dbms_output.put_line('Time elapsed since last successful extract: ' || l_time_diff || ' min. ');
			else
				-- compute time diff in hours
				l_time_diff := extract(day from (l_curr_time - l_last_e_time))*24 +
					 	extract(hour from (l_curr_time - l_last_e_time));
				 dbms_output.put_line('Time elapsed since last successful extract: ' || l_time_diff || ' hr. ');
			end if;
	
			-- not enough time elapsed
			if l_time_diff < upload_interval and not run_etl_now then 
				dbms_output.put_line('Not enough time elapsed. Quitting. ');
				retry_all_non_recov(em_id, support_non_sys);
				return;	 -- no op 		
			end if;
		end if;

		-- bad snap range
		if l_bid >= l_eid then
			dbms_output.put_line('Bad snapshot range [' || l_bid || ', ' || l_eid || ']. Quitting. ');
			/*
			if run_etl_now then
                                dbms_standard.raise_application_error(
					CAW_INSUFF_SNAPSHOTS, 'NOT ENOUGH SNAPSHOTS TO EXTRACT');
                        end if;
			*/
			retry_all_non_recov(em_id, support_non_sys);
			return;
		end if;
	  end;
	end if; -- fresh extract

	if not l_is_retry then
		-- new filename for fresh extract
		l_dmpfile := em_id || dump_name_sep ||
			sys_guid || dump_name_sep ||
                     	l_dbid || dump_name_sep ||
                     	l_bid || dump_name_sep ||
		     	l_eid;
	end if;

	dbms_output.put_line('Generating dump file: ' || l_dmpfile || '. ');

	-- create/update entry in metadata table
	if not l_is_retry then
		qry_txt := 'select DBSNMP.CAW_EXTRACT_ID_SEQ.nextval from dual';
		execute immediate qry_txt into l_extract_id;

		qry_txt := 'insert into DBSNMP.CAW_EXTRACT_METADATA' || 
			'(EXTRACT_ID, DBID, BEGIN_SNAP_ID, END_SNAP_ID, START_TIME, FILENAME, STATUS, INSTANCE_NUMBER) ' ||
			'values(:1, :2, :3, :4, systimestamp, :5, :6, :7)';
		execute immediate qry_txt using l_extract_id, l_dbid, l_bid, l_eid, l_dmpfile || '.dmp', 
			CAW_EXTRACT_BEGIN, my_inst_num;
	else
                qry_txt := 'update DBSNMP.CAW_EXTRACT_METADATA ' ||
                        'set START_TIME = systimestamp, STATUS = :1, FILENAME = :2, E_RETRY_COUNT = E_RETRY_COUNT + 1, ' ||
                        'instance_number = :3 ' ||
			            'where EXTRACT_ID = :4';
                execute immediate qry_txt using CAW_EXTRACT_BEGIN,  l_dmpfile || '.dmp', my_inst_num, l_extract_id;
	end if;
	commit;

	-- awr extract
	begin
		awr_extract(
			dump_file  	=>  l_dmpfile,
			dump_dir   	=>  CAW_EXTRACT_DUMP_DIR,
			begin_snap  =>  l_bid,
			end_snap    =>  l_eid,
			dbid   		=>  l_dbid,
			is_non_sys => support_non_sys
		);
		update_metadata(l_extract_id, CAW_EXTRACT_SUCCESS);
	exception 
		when others then
			-- NOTE: log file may not  be created in some cases
			dbms_output.put_line('Errors during AWR Extract: ' || sqlerrm(sqlcode));
			update_metadata(l_extract_id, CAW_EXTRACT_ERROR, sqlerrm(sqlcode), l_dmpfile || '.log');
			if run_etl_now then
                        	raise;
                        end if; 
	end;
	
	retry_all_non_recov(em_id, support_non_sys);

end run_extract;

-- AWR extract wrapper
procedure awr_extract( 
        dump_file       in varchar2,
        dump_dir        in varchar2,
        begin_snap      in number,
        end_snap        in number,
        dbid            in number,
	is_non_sys	in boolean := false)
is
	sql_txt varchar2(4000);
begin
  if is_non_sys then 
  	sql_txt := 'begin ' ||
		'dbms_workload_repository.extract( ' ||
                '    dmpfile  => :1, ' ||
                '    dmpdir   => :2, ' ||
                '    bid      => :3, ' ||
                '    eid      => :4, ' ||
                '    dbid     => :5); ' ||
		'end;';
  else
  	sql_txt :=  	'begin ' ||
		'  sys.dbms_swrf_internal.awr_extract( ' ||
			    'dmpfile  => :1, ' ||
                'dmpdir   => :2, ' ||
                'bid      => :3, ' ||
                'eid      => :4, ' ||
                'dbid     => :5); ' ||
  		'  sys.dbms_swrf_internal.clear_awr_dbid; ' ||
		'end;';
  end if;
  execute immediate sql_txt using dump_file, dump_dir, begin_snap, end_snap, dbid;
end awr_extract;

function inst_tzr
return varchar2
is
begin
	return to_char(systimestamp,'TZR');
end inst_tzr;

function system_tzr
return varchar2
is
	type instidTab is table of number;
	type tzrTab    is table of varchar2(32);
	instids   instidTab;
	tzrs      tzrTab;
	ptzr      VARCHAR2(32);
	tzr       VARCHAR2(32);
begin
	execute immediate 'select inst_id, dbsnmp.mgmt_caw_extract.inst_tzr
			from gv$instance'
	bulk collect into instids, tzrs;

	-- if there is more than one instance, check that they all have
	-- the same time zone
	if instids.count > 1
	then
		-- find distinct tzrs
		for i in tzrs.first .. tzrs.last
		loop
			if tzrs(i) != ptzr and ptzr is not null then
				return to_char(null);
			end if;
			ptzr := tzrs(i);
		end loop;
		tzr := tzrs(1);
	else
	-- otherwise, force retrieval of timezone information using PQ
	-- for this single instance
	execute immediate 'select /*+ parallel(d 2) */ dbsnmp.mgmt_caw_extract.inst_tzr
			     from dual d
			    where dummy=''X'''
		     into tzr;
	end if;

	-- free elements
	instids.DELETE;
	tzrs.DELETE;

	return tzr;
end system_tzr;
	
END MGMT_CAW_EXTRACT;
/

-- create public synonyms
begin
  execute immediate ' CREATE OR REPLACE PUBLIC SYNONYM MGMT_CAW_EXTRACT FOR DBSNMP.MGMT_CAW_EXTRACT ';
  execute immediate ' CREATE OR REPLACE PUBLIC SYNONYM CAW_EXTRACT_METADATA FOR DBSNMP.CAW_EXTRACT_METADATA ';
  execute immediate ' CREATE OR REPLACE PUBLIC SYNONYM CAW_EXTRACT_PROPERTIES FOR DBSNMP.CAW_EXTRACT_PROPERTIES ';
  execute immediate ' CREATE OR REPLACE PUBLIC SYNONYM CAW_EXTRACT_ID_SEQ FOR DBSNMP.CAW_EXTRACT_ID_SEQ ';
end;
/

show errors


