set line 240 pagesize 100
col start_time form A19
col done_gb form 999G990D00
col remaining_gb form 999G990D00
col avg_mb_sec form 9G990D00
col ela form A18
col eta form A18
col est_finish_time form A19
with r as (
select type
   --,filename
   ,min(open_time) start_time
   ,max(nvl(close_time,sysdate)) end_time
   --,elapsed_time/100 ela_sec
   ,sum(bytes) bytes
from v$backup_async_io
where filename is not null
group by type
)
--, f as (select /*+ materialize */ sum(bytes) fbytes from dba_data_files)
, f as (select /*+ materialize */ (select sum(bytes) fbytes from dba_data_files)-(select sum(bytes) from dba_free_space) as fbytes from dual)
select to_char(start_time,'YYYY-MM-DD HH24:MI') start_time
   --,end_time
   ,round(bytes/1024/1024/1024,2) done_gb
   ,round(bytes/fbytes*100,2) pct_done
   ,round((fbytes-bytes)/1024/1024/1024,2) remaining_gb
   , round(bytes/1024/1024/((end_time-start_time)*24*60*60),2) avg_mb_sec
   ,cast(numtodsinterval((end_time-start_time)*24*60*60,'SECOND') as interval day(1) to second(0)) ela
   ,cast(numtodsinterval(((end_time-start_time)*24*60*60)*fbytes/bytes - (((end_time-start_time)*24*60*60)),'SECOND') as interval day(1) to second(0)) eta
   , to_char( sysdate + (((end_time-start_time))*fbytes/bytes - (((end_time-start_time)))),'YYYY-MM-DD HH24:MI') est_finish_time
from r, f;

