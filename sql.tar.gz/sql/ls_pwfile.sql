set line 240 pagesize 100
col username form A20
col account_status form A15
col profile form A15
col sysdba form A6
col sysoper form A7
col sysasm form A6
col sysbackup form A9
col sysdg form A6
col syskm form A6

col file_name form A80
col is_asm form A6
select file_name, format, is_asm from v$passwordfile_info;


select username,account_status,to_char(last_login,'YYYY-MM-DD HH24:MI') last_login, sysdba,sysoper,sysasm,sysbackup,sysdg,syskm
from v$pwfile_users
order by username;

