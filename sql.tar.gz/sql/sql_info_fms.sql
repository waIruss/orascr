set verify off feedback off
set serveroutput on
set linesize 250 pagesize 800 long 100000 
col owner form A10 
col is_bind_sensitive form A6 heading "Bind|sensi"
col is_bind_aware form A6 heading "Bind|aware"
col is_shareable form A6 heading "Is|sharea"
col sql_profile form A25 heading "SQL|Profile"
col sql_patch form A25 heading "SQL|Patch"
col sql_plan_baseline  form A35 heading "SQL Plan|Baseline"
col is_rolling_invalid form A6 heading "roll|inval"
col first_load_time form A14 heading "First|load time"
col last_active_time form A14 heading "Last|active time"
col sql_id new_val _sql_id noprint
col fms new_val _fms noprint
col sql_text new_val _sql_text noprint

col buffer_gets form 999G999G999G999
col execs form 999G999G999G999
col "rows total" form 999G999G999G999
col "PhysReadMB" form 999G999G999D00


def fms=&1

select s.sql_id, s.sql_text from v$sql s where force_matching_signature= &fms and rownum <=1;

prompt ==========================================================================
prompt sql_id=&&_sql_id
prompt force_matching_signature=&fms
prompt
prompt &&_sql_text
prompt
prompt ==========================================================================
prompt Current execution statistics 
prompt ==========================================================================

select 
   --s.sql_id, s.force_matching_signature fms,s.sql_text, 
   min(s.sql_id) sqlid,
   s.parsing_schema_name owner,
   s.plan_hash_value plan_hash, 
   --s.fetches, 
   sum(s.executions) "execs", 
   --s.parse_calls, s.loads, 
   sum(s.buffer_gets) buffer_gets,
   sum(round(s.buffer_gets/decode(s.executions,0,1,s.executions),2)) AS "gets/exec",
   sum(round(s.concurrency_wait_time/1000000,2)) "Concur(s)", 
   sum(round(s.cpu_time/1000000,2)) AS "CPU(s)",
   sum(round(s.elapsed_time/1000000,2)) AS "Ela(s)",
   round(sum(s.elapsed_time/1000000)/sum(decode(s.executions,0,1,s.executions)),4) AS "Ela/exec(s)",
   sum(round(s.user_io_wait_time/1000000,2)) AS "IO wait(s)",
   sum(round(s.physical_read_bytes/1024/1024,2)) "PhysReadMB", 
   --s.OPTIMIZER_COST,  
   sum(s.rows_processed) AS "rows total",
   round(sum(s.rows_processed)/sum(decode(s.executions,0,1,s.executions)),2) "rows/exec", 
   round(sum(s.buffer_gets)/sum(decode(s.rows_processed,0,1,s.rows_processed)),2) "gets/row" 
from v$sql s  
where force_matching_signature=&fms
group by s.parsing_schema_name , s.plan_hash_value;

prompt 
 
undef fms
undef 1

col sql_id clear
col sql_text clear
set feedback 6
