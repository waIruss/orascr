set verify off
set serveroutput on size unlimited

accept logseq prompt 'Enter log sequence: '
accept tab_owner prompt 'Enter table owner: '
accept tab_name prompt 'Enter table name: '
accept nMaxRows prompt 'Enter max records to return (default: 50): ' default '50'


declare
   vLogName varchar2(300);
begin
  select name
    into vLogName
  from v$archived_log
  where dest_id=1
    and name is not null
    and sequence#=&LOGSEQ
    and rownum <= 1;

  dbms_logmnr.add_logfile(vLogName, options => dbms_logmnr.new);
  dbms_logmnr.start_logmnr(
    options => dbms_logmnr.dict_from_online_catalog
    -- + dbms_logmnr.committed_data_only
    -- + dbms_logmnr.skip_corruption
  );
exception
  when no_data_found then
    raise_application_error(-20001,'Archivelog seq: &LOGSEQ does not exists!');
end;
/


col timestamp form A22
col sess_id form A12
col operation form A15 trunc
col sql_redo form A140 wor
set line 240
set pagesize 100


select * from (
select
  to_char(timestamp,'YYYY-MM-DD HH24:MI:SS') timestamp_
  ,session#||','||serial# as sess_id
  ,operation
  ,sql_redo
from v$logmnr_contents
where seg_owner=upper(trim('&tab_owner'))
and table_name=upper(trim('&tab_name'))
) where rownum <= &nMaxRows;


execute dbms_logmnr.end_logmnr;


undef logseq tab_owner tab_name nMaxRows

