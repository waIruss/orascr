-------------------------------------------------------------------------------
-- DESCRIPTION:
--    Display monitored SQL execution for given sql_id and sql_exec_id
--      enter "null" as sql_exec_id to display info about last exec
--    DIAGNOSTIC and TUNNING  packs are required
-- Usage:
--   @xplan_xqlmon <sql_id> <sql_exec_id>
-------------------------------------------------------------------------------

def SQL_ID=&1
def EXEC_ID=&2
set verif off
set feedback off

col sql_exec_id new_val sql_exec_id noprint
select max(sql_exec_id) sql_exec_id from v$sql_monitor where sql_id=trim('&SQL_ID') and (sql_exec_id=&EXEC_ID or &EXEC_ID is null);

whenever sqlerror exit failure;

declare
  v_pval varchar2(4000);
begin
  select upper(value) into v_pval
    from v$parameter
     where upper(name)='CONTROL_MANAGEMENT_PACK_ACCESS';
  if v_pval != 'DIAGNOSTIC+TUNING' then
    raise_application_error(-20001, 'License for Tuning Pack is required to use this script!');
  end if;
end;
/

whenever sqlerror continue;

set feedback on
set linesize 250 pagesize 1000 long 10000000 
set longchunksize 1000000
col rep form A250 

select dbms_sqltune.report_sql_monitor(sql_id=>'&SQL_ID', report_level=> 'ALL',sql_exec_id=>&EXEC_ID) rep from dual; 

col otherstats form A120
col plan_line_id form 9999

select plan_line_id
,case when otherstat_1_id is not null then (select name from v$sql_monitor_statname where id=otherstat_1_id)||':'||otherstat_1_value||chr(10) else null end||
case when otherstat_2_id is not null then (select name from v$sql_monitor_statname where id=otherstat_2_id)||':'||otherstat_2_value||chr(10) else null end||
case when otherstat_3_id is not null then (select name from v$sql_monitor_statname where id=otherstat_3_id)||':'||otherstat_3_value||chr(10) else null end||
case when otherstat_4_id is not null then (select name from v$sql_monitor_statname where id=otherstat_4_id)||':'||otherstat_4_value||chr(10) else null end||
case when otherstat_5_id is not null then (select name from v$sql_monitor_statname where id=otherstat_5_id)||':'||otherstat_5_value||chr(10) else null end||
case when otherstat_6_id is not null then (select name from v$sql_monitor_statname where id=otherstat_6_id)||':'||otherstat_6_value||chr(10) else null end||
case when otherstat_7_id is not null then (select name from v$sql_monitor_statname where id=otherstat_7_id)||':'||otherstat_7_value||chr(10) else null end||
case when otherstat_8_id is not null then (select name from v$sql_monitor_statname where id=otherstat_8_id)||':'||otherstat_8_value||chr(10) else null end||
case when otherstat_9_id is not null then (select name from v$sql_monitor_statname where id=otherstat_9_id)||':'||otherstat_9_value||chr(10) else null end||
case when otherstat_10_id is not null then (select name from v$sql_monitor_statname where id=otherstat_10_id)||':'||otherstat_10_value||chr(10) else null end otherstats
from V$SQL_PLAN_MONITOR 
where sql_id=trim('&SQL_ID')
and sql_exec_id=&sql_exec_id
and (otherstat_1_id is not null 
   or otherstat_2_id is not null
   or otherstat_3_id is not null
   or otherstat_4_id is not null
   or otherstat_5_id is not null
   or otherstat_6_id is not null
   or otherstat_7_id is not null
   or otherstat_8_id is not null
   or otherstat_9_id is not null
   or otherstat_10_id is not null
   );


undef SQL_ID EXEC_ID 1 2 
