set line 250
col pct_pga_usage form 9990D00 heading "% PGA usage"
col pga_mem_gb form 9G999D00

prompt ===========================================================================
prompt = PGA memory usage
prompt ===========================================================================
select pga_mem_conf_gb,pga_mem_alloc_gb,round(pga_mem_alloc_gb/pga_mem_conf_gb*100,2) pct_pga_usage,
  case when pga_mem_alloc_gb/pga_mem_conf_gb < .9 then 'OK'
    when pga_mem_alloc_gb/pga_mem_conf_gb < 1 then 'Warning'
    else 'Alarm'
  end status
from (
select
  (select round(value/1024/1024/1024) from v$parameter where lower(name) = 'pga_aggregate_target') pga_mem_conf_gb
  ,(select round(value/1024/1024/1024) from v$pgastat where name = 'total PGA allocated') pga_mem_alloc_gb
from dual
);

prompt ===========================================================================
prompt = PGA memory usage by program (top 10)
prompt ===========================================================================
select * from (
  select prog_ ,count(*) no_of_proc,round(sum(pga_alloc_mem)/1024/1024/1024,2) pga_mem_gb
  from (
    select s.sid,s.client_info,s.program,s.machine,drj.job_name,module,action
      ,pga_alloc_mem
      ,case
        when client_info like 'BGP_OS%' then
          'BGP_'||regexp_substr(substr(client_info,1,10),'[0-9]+')
        when drj.job_name like 'AVQ$AAA_BGP%' then
          substr(drj.job_name,9,7)
        when drj.job_name like 'AVQ$ISM%' then
          substr(drj.job_name,1,7)||' - install'
        when s.program = 'IntegrationServer.exe' then
          'SmartClient'
        else
          'Other'
      end prog_
    from v$session s,v$process p,dba_scheduler_running_jobs drj
    where s.paddr=p.addr
      and s.sid=drj.session_id(+)
      and s.type='USER'
    )
  group by prog_
order by pga_mem_gb desc
) where rownum <= 10 ;




col task_template form A50
col task_id form A12
col userstamp form A12
col username form A18
col start_time form A16
col end_time form A16
col exec_time form A14
col task_name form A50
col status form A10
col session_id form 9999999
col pga_gb form 990D00
col pga_mb form 999G990

prompt ===========================================================================
prompt = PGA memory usage by running tasks
prompt ===========================================================================

select
  ttv.user_id task_template
  ,to_char(oj.id) task_id
  ,oj.userstamp username
  ,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI') start_time
  --,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI')) end_time
  , oj.parallel_exec_nr_prc prl_proc
  ,(to_char(cast(sysdate-oj.timestamp_start  as interval day(1) to second(0)))) as exec_time
  ,k.task_def#.task#name(oi.obj_id) task_name
  --,oi.name_intl task_name
  ,s.name status
  ,oj.err_log_id
  ,case when oj.out_status_id = 3 then
    (select round(sum(pga_alloc_mem/1024/1024)) pga_alloc_mb
      from k.out_job j, v$session s, v$process p
      where (id=oj.id or parent_task_id=oj.id)
        and j.sid=s.sid and s.paddr=p.addr
        and j.out_status_id = 3
    )
    else
      null
   end pga_mb
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
  oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
  and (oj.parent_task_id is null)
  and (oj.out_status_id = 3)
order by oj.id;


prompt ===========================================================================
prompt = Top 20 session - by PGA usage
prompt ===========================================================================

set line 250 pagesize 100
col sid_ser form A14
col username form A10
col program form A26
col osuser form A6
col machine form A16 trunc
col module form A16
col action form A20
col spid form A5
col pga_alloc_mb form 999G999
col pga_used_mb like pga_alloc_mb
col sql_alloc_mb like pga_alloc_mb
col plsql_alloc_mb like pga_alloc_mb
col plsql_used_mb like pga_alloc_mb
col other_alloc_mb like pga_alloc_mb
col other_used_mb like pga_alloc_mb
compute sum of pga_alloc_mb on report
break on report
with pm as
(
  select pid, serial#, sql_allocated, sql_used, sql_max_allocated, plsql_allocated, plsql_used, plsql_max_allocated, other_allocated, other_used, other_max_allocated
  from v$process_memory
    pivot (
      max(allocated) as allocated,
      max(used) as used,
      max(max_allocated) as max_allocated
      for category in
        (
          'SQL' as "SQL",
          'PL/SQL' as "PLSQL",
          'Other' as "OTHER",
          'Freeable' as "FREEABLE"
        )
    )
)
select * from(
  select s.sid||','||s.serial# sid_ser
    ,s.username
    ,coalesce(rj.job_name,s.program) program
    ,replace(replace(lower(s.machine),'apobank\',''),'.apobank.lan','') machine
    --s.osuser,s.program,s.machine,
    --s.logon_time
    --s.module,s.action
    ,s.status
    --,s.sql_id,
    --,p.pid,p.spid,
    ,round(p.pga_alloc_mem/1024/1024) pga_alloc_mb,
    round(p.pga_used_mem/1024/1024) pga_used_mb,
    --p.pga_alloc_mem,
    --round(p.pga_max_mem/1024/1024) pga_max_mb,
    --,sql_allocated, sql_used,
    round(sql_allocated/1024/1024) sql_alloc_mb,
    --round(sql_max_allocated/1024/1024) sql_max_mb,
    --plsql_allocated, plsql_used,
    round(plsql_allocated/1024/1024) plsql_alloc_mb,
    round(plsql_used/1024/1024) plsql_used_mb,
    --round(plsql_max_allocated/1024/1024) plsql_max_mb,
    --,other_allocated
    --, other_used
    round(other_allocated/1024/1024) other_alloc_mb,
    round(other_used/1024/1024) other_used_mb
    --round(other_max_allocated/1024/1024) other_max_mb
  from v$session s, v$process p,  pm, dba_scheduler_running_jobs rj
  where s.paddr=p.addr
    and p.pid=pm.pid and p.serial#=pm.serial#
    and s.sid=rj.session_id(+)
    --and s.type = 'USER'
    --and s.sid=4490
  order by pga_alloc_mem desc
) where rownum <=20;


