set termout off
set linesize 300
set verify off
set heading off feedback off

whenever sqlerror exit 
whenever oserror exit

def DT_FMT_REP="Mon-DD"
def DT_FMT_ISO="YYYY-MM-DD HH24:MI"
def DT_FMT_ASH="MM/DD/YY HH24:MI"

col bdate new_val bdate noprint
col edate new_val edate noprint
col today new_val today noprint
col dbname new_val dbname noprint
col awr_script new_val awr_script noprint
col ash_script new_val ash_script noprint

select to_char(sysdate,'YYYYMMDD') today,name dbname
,'/tmp/.gen_awr_'||to_char(systimestamp,'YYYYMMDDHH24MISS')||'_'||sys_context('userenv','sessionid')||'.sql' as awr_script
,'/tmp/.gen_ash_'||to_char(systimestamp,'YYYYMMDDHH24MISS')||'_'||sys_context('userenv','sessionid')||'.sql' as ash_script
from v$database;


select
  to_char(greatest(sysdate-1,min(end_interval_time)),'&&DT_FMT_ISO') as bdate,
  to_char(least(sysdate,max(end_interval_time)),'&&DT_FMT_ISO') as edate
from dba_hist_snapshot where end_interval_time > sysdate-1;


set termout on

prompt ==================================================================
ACCEPT bdate  DEFAULT '&bdate'  PROMPT 'Enter start date as &&DT_FMT_ISO [&bdate]: '
ACCEPT edate  DEFAULT '&edate'  PROMPT 'Enter end date as &&DT_FMT_ISO [&edate]: '
ACCEPT bGenAWR DEFAULT 'Y'      PROMPT 'Generate AWR reports? [Y]: '
ACCEPT bGenASH DEFAULT 'Y'      PROMPT 'Generate ASH reports? [Y]: '
ACCEPT ashSID DEFAULT ''        PROMPT 'ASH filter - session_id []: '
ACCEPT ashMODULE DEFAULT ''     PROMPT 'ASH filter - module []: '
ACCEPT ashSQL_ID DEFAULT ''     PROMPT 'ASH filter - sql_id []: '
ACCEPT ashWAIT_CLASS DEFAULT '' PROMPT 'ASH filter - wait_class []: '
ACCEPT ash_ival  DEFAULT '30'   PROMPT 'Enter interval for ASH reports (in minutes) [30]: '
ACCEPT out_dir  DEFAULT '../awr/&&today._&&dbname'   PROMPT 'Enter output directory for reports [../awr/&&today._&&dbname ]: '
prompt ==================================================================

def bdate2="to_date('&&bdate','&&DT_FMT_ISO')"
def edate2="to_date('&&edate','&&DT_FMT_ISO')"

set termout off
host mkdir -p &&out_dir

spool &&awr_script
select
'define report_type="html"'||chr(10)||
'define num_days=30'||chr(10)||
'define inst_num=1'||chr(10)||
'define dbname='||upper(d.name)||chr(10)||
'define dbid='||trim(to_char(d.dbid))||chr(10)||
'define begin_snap='||bsnap||chr(10)||
'define end_snap='||esnap||chr(10)||
'define report_name="&&out_dir./awrrpt_'||upper(d.name)||'_'||to_char(btime,'YYYY-MM-DD_HH24MI-')||to_char(etime,'HH24MI')||'.html"'||chr(10)||
'set termout on'||chr(10)||
'prompt Generating AWR report for '||to_char(btime,'YYYY-MM-DD_HH24MI-')||to_char(etime,'HH24MI')||chr(10)||
'set termout off'||chr(10)||
'@?/rdbms/admin/awrrpti'||chr(10)||chr(10)||chr(10)
--bsnap,esnap,btime,etime,to_char(btime,'YYYY-MM-DD_HH24MI-')||to_char(etime,'HH24MI') time_range
from
(
  select snap_id bsnap
    ,lead(snap_id) over(partition by startup_time order by end_interval_time) esnap
    ,end_interval_time btime
    ,lead(end_interval_time) over(partition by startup_time order by end_interval_time) etime
  from
  (
    select snap_id,startup_time,begin_interval_time,end_interval_time
    from dba_hist_snapshot s
    where s.snap_id >= (select max(s1.snap_id) from dba_hist_snapshot s1 where s1.begin_interval_time <= &bdate2 and s.dbid=s1.dbid)
      and s.snap_id <= (select min(s2.snap_id) from dba_hist_snapshot s2 where s2.end_interval_time >= &edate2 and s.dbid=s2.dbid)
      and s.dbid = (select dbid from v$database)
    order by s.begin_interval_time
  )
) s, v$database d
where esnap  is not null
  and 'Y' = upper(trim('&&bGenAWR'));

spool off
@@&&awr_script
host rm &&awr_script

set termout off
set line 300
spool &&ash_script
prompt alter session set optimizer_index_caching=0;
prompt alter session set optimizer_index_cost_adj=100;
prompt alter session set db_file_multiblock_read_count=128;

with a as (
  select nvl(lag(dt) over(order by dt),&bdate2) bdt,&&ash_ival duration
    ,to_char(dt,'MM/DD/YY HH24:MI') btime
    ,to_char(dt,'YYYY-MM-DD_HH24MI') rep_name
  from(
      select &bdate2 + numtodsinterval((level-1)*&&ash_ival,'MINUTE') dt
      from dual
      --connect by level <=100
      connect by &bdate2 + numtodsinterval((level-1)*&&ash_ival,'MINUTE') <= &edate2
    )
)
select
'col db_name new_val dbname'||chr(10)||
'col dbid new_val dbid'||chr(10)||
'select upper(name) db_name, dbid from v$database;'||chr(10)||
'define default_report_type         = "html";'||chr(10)||
'define default_report_duration     = 15;'||chr(10)||
'define default_report_name_prefix  = "ashrpt";'||chr(10)||
'define default_report_name_suffix  = "MMDD_HH24MI";'||chr(10)||
'def report_type_def="html"'||chr(10)||
'def report_type="html"'||chr(10)||
'def dbid='||d.dbid||chr(10)||
'def inst_num=1'||chr(10)||
'def begin_time="'||btime||'"'||chr(10)||
'def duration=&ash_ival'||chr(10)||
'def slot_width=""'||chr(10)||
'def target_session_id="&ashSID"'||chr(10)||
'def target_sql_id="&ashSQL_ID"'||chr(10)||
'def target_wait_class="&ashWAIT_CLASS"'||chr(10)||
'def target_service_hash=""'||chr(10)||
'def target_module_name="&ashMODULE"'||chr(10)||
'def target_action_name=""'||chr(10)||
'def target_client_id=""'||chr(10)||
'def target_plsql_entry=""'||chr(10)||
'def target_container=""'||chr(10)||
'def report_name="&&out_dir./ashrpt_'||upper(d.name)||'_'||rep_name||'.html"'||chr(10)||
'@?/rdbms/admin/ashrpti'||chr(10)||chr(10)||chr(10)
from a,v$database d
where 'Y' = upper(trim('&&bGenASH'))
order by 1;
spool off

@@&&ash_script
host rm &&ash_script

prompt ==================================================================
prompt Generated reports in &&out_dir
prompt ==================================================================
host ls -ltr &&out_dir/*

