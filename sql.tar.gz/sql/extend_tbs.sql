set verify off
set feedback off
set line 200

def TBS_NAME="&1"
def MAX_SIZE_GB="&2"


select 'Before resize - TBS: '||tablespace_name||', SIZE_GB: '||round(sum(bytes)/1024/1024/1024)||', MAX_SIZE_GB: '||round(sum(maxbytes)/1024/1024/1024) tbs_size  
from dba_data_files 
where tablespace_name=upper(trim('&TBS_NAME')) 
group by tablespace_name; 

declare
  v_max_size number;
  v_tgt_max_size number;
  v_tbs_name varchar2(100);
begin
  v_tbs_name := upper(trim('&TBS_NAME'));
  v_tgt_max_size := upper(trim('&MAX_SIZE_GB'));
  select round(sum(maxbytes)/1024/1024/1024) into v_max_size from dba_data_files where tablespace_name=v_tbs_name;
  while v_max_size < v_tgt_max_size
  loop
    Dbms_Output.Put_Line('Max size:'||v_max_size);
    execute immediate 'alter tablespace '||v_tbs_name||' add datafile size 5M autoextend on next 5M maxsize unlimited';
    select round(sum(maxbytes)/1024/1024/1024) into v_max_size from dba_data_files where tablespace_name=v_tbs_name;   
  end loop;
end;
/

select 'After resize - TBS: '||tablespace_name||', SIZE_GB: '||round(sum(bytes)/1024/1024/1024)||', MAX_SIZE_GB: '||round(sum(maxbytes)/1024/1024/1024) tbs_size  
from dba_data_files 
where tablespace_name=upper(trim('&TBS_NAME'))
group by tablespace_name; 

