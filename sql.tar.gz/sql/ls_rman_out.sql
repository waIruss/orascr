set line 200 pagesize 2000 verify off
col start_time form A16
col output form A130

accept n_last_hours prompt 'Last hours (default: 24): ' default '24'


SELECT to_char(rs.start_time,'YYYY-MM-DD HH24:MI') start_time,
   rs.operation,
   --rs.status,
   ro.output
FROM v$rman_output ro, v$rman_status rs
WHERE ro.rman_status_recid=rs.recid
  AND ro.rman_status_stamp=rs.stamp
  and rs.start_time > sysdate-(&n_last_hours/24);

undef n_last_hours  
