set verify off
set serveroutput on size unlimited

def LOGSEQ=&1

declare
   szName varchar2(300);
begin
  select name
    into szName
  from v$archived_log
  where dest_id=1
    and name is not null
    and sequence#=&LOGSEQ
    and rownum <= 1;

  dbms_logmnr.add_logfile(szName, options => dbms_logmnr.new);
  dbms_logmnr.start_logmnr(
    options => dbms_logmnr.dict_from_online_catalog
    -- + dbms_logmnr.committed_data_only
    -- + dbms_logmnr.skip_corruption
  );
exception
  when no_data_found then
    raise_application_error(-20001,'Archivelog seq: &LOGSEQ does not exists!');
end;
/


col segment_name  format A60
col operation format A15 trunc
col sess_id form A12
set line 240
set pagesize 100

select * from (
select
  seg_owner||'.'||seg_name as segment_name
  --, session#||','||serial# as sess_id
  , operation
  , count(*) as oper_count
from v$logmnr_contents
group by seg_owner, seg_name, operation
--having count(*) >= 100
order by oper_count desc
)
where rownum <= 50;

execute dbms_logmnr.end_logmnr;

undef LOGSEQ

