
def sql_id=&1
def child_num=&2

set linesize 220 pagesize 800 verif off
select * from table(dbms_xplan.display_cursor('&&sql_id', &&child_num,'TYPICAL PEEKED_BINDS'));

undef sql_id child_num 1 2
