set line 200
col db_name form A10
col inst_id form 99
col instance_name form A10
col startup_time form A16
col uptime form A16
col host_name form A25
col db_role form A20 trunc
col open_mode form A10
col logins form A17
set feedback off verif off

col avq_q new_val avq_q noprint
select nvl2(max(table_name),'(select '' [SL''||session_level||'']'' from k.base_main)',''' [SL n/a]''') avq_q from dba_tables where table_name='BASE_MAIN' and owner='K';

set feedback 6

SELECT
  name db_name,
  inst_id,
  instance_name,
  to_char(startup_time,'YYYY-MM-DD HH24:MI') startup_time,
  CAST(NumToDSInterval(SYSDATE-startup_time,'DAY') AS INTERVAL DAY(3) TO SECOND(0)) uptime,
  host_name,
  database_role as db_role,
  open_mode,
  logins||&&avq_q as logins,
  --decode(logins,'RESTRICTED','SL0','ALLOWED','SL5',logins)||']' logins,
  version_full as version,
  to_char(resetlogs_time,'YYYY-MM-DD HH24:MI') resetlogs_time
FROM gv$instance, v$database;

prompt ==========================================================================
prompt Recent restarts
prompt ==========================================================================
select
  to_char(startup_time,'YYYY-MM-DD HH24:MI') startup_time
  ,cast(lead(startup_time) over ( order by startup_time) - startup_time as interval day(2) to second(0)) uptime
from (
   select distinct startup_time
   from dba_hist_snapshot where dbid = (select dbid from v$database)
   order by 1 desc
)
order by startup_time desc;

