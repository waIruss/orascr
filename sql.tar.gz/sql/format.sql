whenever sqlerror exit failure
whenever oserror exit failure
--store set .sqlplus_env replace
set verify off
set echo off feedback off
set trimspool on
set long 500000
def sql_id=&1
set pagesize 0 linesize 250
col sql_fulltext form A200 wor
host mkdir -p /oracle/$ORACLE_SID/dba/tmp
def spoolfile=/oracle/$ORACLE_SID/dba/tmp/tmp_&&sql_id..raw
def outfile=/oracle/$ORACLE_SID/dba/tmp/tmp_&&sql_id..fmt


spool &&spoolfile
set termout off
SELECT sql_fulltext
from (
select sql_fulltext
FROM v$sql
WHERE sql_id='&&sql_id'
  AND ROWNUM <=1
union all
select sql_text
from dba_hist_sqltext
where sql_id='&&sql_id'
  and rownum<=1
)
where rownum <=1;
spool off
set termout on

host echo -e "format file &spoolfile &outfile \nexit;" |sql -s /nolog
set define "^"
host [[ -f "^outfile" ]] && cat ^outfile || echo "error processing ^sql_id"
set define "&"
prompt Formatted SQL saved to: &outfile
undef 1 sql_id spoolfile outfile

--@.sqlplus_env
set pagesize 100
set linesize 250
set feedback 6

