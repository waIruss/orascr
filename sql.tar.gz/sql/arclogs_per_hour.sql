set line 200 pagesize 200 verify off
col destination form A40
col status form A8
col target form A8
col schedule form A8
col day_hour form A16
col arc_cnt# form 999G999
col arc_range form A20
col arc_size_mb form 999G999G999
compute sum of arc_cnt# on report
compute sum of arc_size_mb on report
break on report

select dest_id,
   destination,
   status,
   target,
   schedule
from v$archive_dest
where destination is not null
order by dest_id;

accept DEST_ID  number prompt 'Destination ID [1]:' default 1
accept N_DAYS number prompt 'Interval in days [1]:' default 1

SELECT
  To_Char(trunc(completion_time,'HH'),'YYYY-MM-DD HH24') AS day_hour,
  count(*) AS arc_cnt#,
  Min(sequence#)||'-'||Max(sequence#) AS arc_range,
  Round(sum(blocks*block_size)/1024/1024) AS arc_size_mb
FROM v$archived_log
WHERE dest_id=&DEST_ID
  AND completion_time > Trunc(SYSDATE)-&N_DAYS
GROUP BY To_Char(trunc(completion_time,'HH'),'YYYY-MM-DD HH24')
ORDER BY 1;

undef DEST_ID N_DAYS
clear breaks
clear compute