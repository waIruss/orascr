col first_time form A20
col last_time form A20
col ctx form A130
col log_type form A10
set line 200
select intl_id log_type, count(*) error_count,to_char(min(timestp),'YYYY-MM-DD HH24:MI:SS') first_time,to_char(max(timestp),'YYYY-MM-DD HH24:MI:SS') last_time
   ,regexp_replace(regexp_replace(ctx,'OBJ_ID[0-9]* ','OBJ_IDxxxxxxx '),'SEC_USER[0-9]* ','SEC_USERxxxxxxx ') ctx
from k.anon_log l, k.code_anon_log_type lt
where ctx like 'ERR%'
and l.log_type_id=lt.id
group by intl_id,regexp_replace(regexp_replace(ctx,'OBJ_ID[0-9]* ','OBJ_IDxxxxxxx '),'SEC_USER[0-9]* ','SEC_USERxxxxxxx ');
