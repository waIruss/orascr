set pagesize 600
select to_char(begin_time,'yyyymmdd hh24') time ,
round(max(UNDOBLKS+ EXPIREDBLKS+UNEXPIREDBLKS+ACTIVEBLKS)*8192/(1024*1024*1024),2) USED_GB, TUNED_UNDORETENTION
from dba_hist_undostat
where begin_time > sysdate - 2
group by to_char(begin_time,'yyyymmdd hh24'), TUNED_UNDORETENTION
order by to_char(begin_time,'yyyymmdd hh24') desc;
