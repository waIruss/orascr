#!/bin/bash
TNS_ADMIN=/var/opt/oracle; export TNS_ADMIN
PATH=$PATH:/bin:/usr/local/bin; export PATH

ORAENV_ASK=NO
. oraenv
. /var/opt/oracle/aaaenv.sh

source ${ORACLE_MOUNT_POINT1}/RelMan/bin/func_lib.sh
export NLS_DATE_FORMAT='DD-MON-YY HH24:MI:SS'
DATE=$1

full_anon_base="${ORACLE_MOUNT_POINT1}/dba"
log_file=${full_anon_base}/logs/shrink_${DATE}.log
sql_out=${full_anon_base}/logs/sql_out.txt

echo "####   Restart DB in restricted-session mode" >> ${log_file}

$ORACLE_DB_ADMIN/aaa/bin/aaadbctrl.ksh -s $ORACLE_SID -c stop >> $log_file
echo "startup restrict;" | $ORACLE_HOME/bin/sqlplus / as sysdba >> ${log_file}

echo "####    Started DB in restricted-session mode" >> ${log_file}

echo "create undo tablespace UNDO_NEW datafile size 1g autoextend on next 512M;" | $ORACLE_HOME/bin/sqlplus / as sysdba >> ${log_file}
echo "####    created tablespace UNDO_NEW" >> ${log_file}

echo "alter system set undo_tablespace=UNDO_NEW;" | $ORACLE_HOME/bin/sqlplus / as sysdba >> ${log_file}
echo "alter system set undo_management=MANUAL scope=spfile;" | $ORACLE_HOME/bin/sqlplus / as sysdba >> ${log_file}
echo "alter system set job_queue_processes=0 scope=spfile;" | $ORACLE_HOME/bin/sqlplus / as sysdba >> ${log_file}
echo "shutdown transactional;" | $ORACLE_HOME/bin/sqlplus / as sysdba >> ${log_file}
echo "startup restrict;" | $ORACLE_HOME/bin/sqlplus / as sysdba >> ${log_file}

echo "####    run recreate of tablespace" >> ${log_file}
sqlplus -S "/ as sysdba"  >> "${log_file}" 2>&1 <<_EOI
        whenever OSERROR  exit failure
        whenever SQLERROR exit failure
        set serveroutput on
        set feedback off
    BEGIN
      for rows in (select tablespace_name, segment_name, status from dba_rollback_segs where tablespace_name='UNDO' and  status <> 'OFFLINE')
      loop
        execute immediate 'alter rollback segment '|| rows.segment_name ||' offline';
      end loop;
    END;
        /

    drop tablespace undo including contents and datafiles;
    create smallfile undo tablespace UNDO datafile size 1g autoextend on next 1G;

    alter system set undo_management=AUTO scope=spfile;
    alter system set undo_tablespace=UNDO scope=spfile;

    shutdown transactional;
    startup restrict;
    set serveroutput on


    drop tablespace UNDO_NEW including contents and datafiles;

    begin
      dbms_output.put_line('Shrinking all TEMPORARY Tablespaces...');
      for c_tsp in (select tablespace_name  name
                    from   dba_tablespaces
                    where  contents = 'TEMPORARY'
      ) loop
        execute immediate 'alter tablespace '|| c_tsp.name || ' shrink space';
      end loop;
      dbms_output.put_line('done.');
    end;
    /

    begin
      execute immediate 'alter system set job_queue_processes=4000 scope=spfile';
    end;
    /

_EOI

$ORACLE_DB_ADMIN/aaa/bin/aaadbctrl.ksh -s $ORACLE_SID -c stop >> $log_file
$ORACLE_DB_ADMIN/aaa/bin/aaadbctrl.ksh -s $ORACLE_SID -c start -o open -o nogarbcol >> $log_file

ora_err=`egrep "ORA-|SP2-" ${log_file}`
if [ -z "$ora_err" ]; then
    echo "####    Shrink successfully completed." >> "${log_file}"
	cat ${log_file}
else
    echo "####     ERROR: Problem shrinking undo/temp" >> "${log_file}"
    cat ${log_file}
fi
