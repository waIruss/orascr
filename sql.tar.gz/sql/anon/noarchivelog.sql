shutdown immediate;
startup mount;
alter database noarchivelog;
alter database open;
