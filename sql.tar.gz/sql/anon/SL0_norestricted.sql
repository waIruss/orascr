exec  base#.session_level(0);
exec  base#.session_level(1);
exec  base#.session_level(0, i_chk_restr => false);
