
set linesize 200 pagesize 200 verif off
def sql_id=&1

select * from table(dbms_xplan.display_awr('&sql_id'));

undef sql_id 1

