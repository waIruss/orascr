set line 200 pagesize  200
col start_time form A18
col timestamp_ form A18
col type form A16
col item form A20
col units form A16
col comments form A30
col sofar form 999G999G999
col total form 999G999G999

select 
  To_Char(start_time,'YYYY-MM-DD HH24:MI') start_time,
  type,
  item,
  units,
  sofar,
  total,
  To_Char("TIMESTAMP",'YYYY-MM-DD HH24:MI') timestamp_,
  comments 
from v$recovery_progress;



col process form A10
col pid form 99999999
col thread# head "Thr#" form 999
col sequence# form 99999999
col status form A14

select 
   process, 
   pid, 
   status, 
   thread#, 
   sequence#, 
   block#, 
   blocks
from v$managed_standby;
