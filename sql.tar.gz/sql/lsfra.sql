PROMPT ==========================================================================
PROMPT FAST RECOVERY AREA USAGE
PROMPT ==========================================================================

show parameter db_recovery_file_dest

column name format A28
column limit_gb format 99,999.0 
column used_gb format 99,999.0 
column reclaim_gb format 9,999.0
column pct_used format 999.0 heading "%USED"
column number_of_files format 99999 heading "FILES#"
column pct_reclaim format 999.0 heading "%RECLAIM"
compute sum of used_gb on report
compute sum of reclaim_gb on report
compute sum of number_of_files on report
break on report

select 
   name, 
   space_limit/1024/1024/1024 as limit_gb,
   space_used/1024/1024/1024 as used_gb,
   space_reclaimable/1024/1024/1024 as reclaim_gb,
   (space_used-space_reclaimable)/space_limit*100 as pct_used,
   number_of_files
from v$recovery_file_dest;

select 
   file_type, 
   percent_space_used pct_used, 
   percent_space_used/100*(space_limit/1024/1024/1024) as used_gb,
   percent_space_reclaimable as pct_reclaim, 
   percent_space_reclaimable/100*(space_limit/1024/1024/1024) as reclaim_gb,
   u.number_of_files
from v$recovery_area_usage u, v$recovery_file_dest;

clear break
clear compute       