/*
 * Script for DB IO reports
 * Author: Tomasz Kania
*/

whenever sqlerror exit failure
set linesize 2000 pagesize 0 long 32000 longchunksize 32000
set termout off
set trimspool on echo off feedback off 
set verify off
set define '&'
set serveroutput on size unlimited
set sqlblanklines on

--defines 
col global_name new_val db_n noprint
col instance_name new_val inst_name noprint
col instance_number new_val inst_num noprint
select global_name from global_name;
select instance_name,trim(instance_number) as instance_number from v$instance;

--avoid comma as decimal separator in outputs
alter session set nls_numeric_characters='.,';


col bsnap new_val bsnap noprint
col esnap new_val esnap noprint

var bsnap number
var esnap number
var nTopEvents number
var nTopSqls number


col bdate new_val bdate noprint
col edate new_val edate noprint
def DT_FMT_REP="Mon-DD"
def DT_FMT_ISO="YYYY-MM-DD"
var bdate varchar2(20)
var edate varchar2(20)


whenever sqlerror exit 3
set termout on

declare
  v_mgmt_lic varchar2(100);
begin
  select upper(value) into v_mgmt_lic from v$parameter where lower(name) = 'control_management_pack_access';
  if v_mgmt_lic like 'DIAGNOSTIC%' then
    dbms_output.put_line('* Diagnostic Pack is enabled');
  else
    raise_application_error(-20999,'Diagnostic Pack is disabled - AWR is not available.'||chr(10)||'Consider using statspack');
  end if;
end;
/


select 
  to_char(greatest(trunc(sysdate)-7,min(end_interval_time)),'&&DT_FMT_ISO') as bdate, 
  to_char(least(trunc(sysdate),max(end_interval_time)),'&&DT_FMT_ISO') as edate 
from dba_hist_snapshot;



declare 
  v_nSnaps number;
  v_OldestSnap date;
  v_NewestSnap date;
  v_date1 date;
  v_date2 date;
begin
  select count(*),min(end_interval_time), max(end_interval_time) into v_nSnaps,v_OldestSnap,v_NewestSnap from dba_hist_snapshot;  
  if v_nSnaps < 8 then
    raise_application_error(-20001,'Insufficient data in AWR repository. '||to_char(v_nSnaps)||' snapshosts available, at least 8 snapsthots are required');
  else
    select 
      greatest(trunc(sysdate)-7,min(end_interval_time)),
      least(trunc(sysdate),max(end_interval_time))
      into v_date1,v_date2  
    from dba_hist_snapshot;
    :bdate := to_char(v_date1,'&&DT_FMT_ISO');
    :edate := to_char(v_date2,'&&DT_FMT_ISO');
   
    --dbms_output.put_line('==================================================================');
    --dbms_output.put_line('Snapshots available: '||to_char(v_nSnaps));
    --dbms_output.put_line('Oldest snapshot: '||to_char(v_OldestSnap,'&&DT_FMT_ISO HH24:MI'));
    --dbms_output.put_line('Latest snapshot: '||to_char(v_NewestSnap,'&&DT_FMT_ISO HH24:MI'));
    --dbms_output.put_line('==================================================================');
  end if;
end;
/


--prompt ==================================================================
--ACCEPT bdate  DEFAULT '&bdate'  PROMPT 'Enter start date as &&DT_FMT_ISO [&bdate]: '
--ACCEPT edate  DEFAULT '&edate'  PROMPT 'Enter end date as &&DT_FMT_ISO [&edate]: '
--ACCEPT nTopSqls DEFAULT '5'     PROMPT 'Enter number of top SQLs per snapshot [5]: '
--ACCEPT nTopEvents DEFAULT '5'   PROMPT 'Enter number of top Wait events per snapshot [5]: '
--prompt ==================================================================

--begin 
--  :nTopSqls := &&nTopSqls ;
--  :nTopEvents := &&nTopEvents ;
--end;
--/  


declare
  v_bsnap number;
  v_esnap number;
  v_nSnaps number;
begin
  select min(snap_id) into v_bsnap 
  from
  (
    select snap_id,lag(snap_id) over(order by end_interval_time) prev_snap,lead(snap_id) over(order by end_interval_time) next_snap,end_interval_time from dba_hist_snapshot
  ) 
  where 
    end_interval_time >= to_date('&&bdate','&&DT_FMT_ISO')
    --and prev_snap is not null 
    and next_snap is not null;

  select max(snap_id) into v_esnap 
  from
  (
    select snap_id,lag(snap_id) over(order by end_interval_time) prev_snap,lead(snap_id) over(order by end_interval_time) next_snap,end_interval_time from dba_hist_snapshot
  ) 
  where 
    end_interval_time < to_date('&&edate','&&DT_FMT_ISO')+1
    and snap_id > v_bsnap;

  select count(*) into v_nSnaps
  from dba_hist_snapshot
  where snap_id between v_bsnap and v_esnap;
  
  if v_nSnaps < 7 then
    Dbms_Output.Put_Line('bsnap:'||v_bsnap);
    Dbms_Output.Put_Line('esnap:'||v_esnap);
    raise_application_error(-20002,'Insufficient AWR data in selected range. '||to_char(v_nSnaps)||' snapshosts available, at least 7 usable snapsthots are required');
  else
    :bsnap := v_bsnap;
    :esnap := v_esnap; 
    dbms_output.put_line('Analyzing '||to_char(v_nSnaps)||' snapshots');
  end if;
end;
/

whenever sqlerror continue

prompt Generating report, it may take few minutes.... Please wait...
prompt
set termout off

var stime number
var etime number

begin
  :stime := dbms_utility.get_time();
end;
/

def REPTITLE="IO response time report for &&db_n"

def MAINREPORTFILE=new_db_io_charts_&&db_n._&&inst_num._&&bdate._&&edate..html
spool &&MAINREPORTFILE

prompt <html>
prompt <!-- DB IO reports/graphs -->
prompt <!-- Author: Tomasz Kania -->
prompt <head>
prompt   <title>&&REPTITLE.</title>

---------------------------------------------------
-- GoogleChart JS
---------------------------------------------------
prompt   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
prompt     <script type="text/javascript">
prompt       google.charts.load('current', {'packages':['table', 'corechart', 'controls']});;
prompt       google.charts.setOnLoadCallback(drawWClassChartSingle);;
prompt       google.charts.setOnLoadCallback(drawWaitEvHistChart);;
prompt       google.charts.setOnLoadCallback(drawWaitClHistChart);;
prompt 
prompt 


spool off
set termout on
prompt Gathering wait events statistics...
set termout off
spool &&MAINREPORTFILE append

---------------------------------------------------
-- Wait Class chart
---------------------------------------------------
prompt     function drawWClassChart() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('datetime', 'Snapshot');;
prompt       data.addColumn('number', 'DB CPU');;
prompt       data.addColumn('number', 'background CPU');;
prompt       data.addColumn('number', 'Administrative');;
prompt       data.addColumn('number', 'Application');;
prompt       data.addColumn('number', 'Cluster');;
prompt       data.addColumn('number', 'Commit');;
prompt       data.addColumn('number', 'Concurrency');;
prompt       data.addColumn('number', 'Configuration');;
prompt       data.addColumn('number', 'Network');;
prompt       data.addColumn('number', 'Other');;
prompt       data.addColumn('number', 'Queueing');;
prompt       data.addColumn('number', 'Scheduler');;
prompt       data.addColumn('number', 'System I/O');;
prompt       data.addColumn('number', 'User I/O');;
prompt 
prompt       data.addRows([
with snap as
(
  select /*+materialize*/ /*workaround for Bug 28749853*/ snap_id,dbid,instance_number
    ,cast(end_interval_time as date) as snap_time
    ,row_number() over (order by snap_id desc) rn
    ,to_char(cast(end_interval_time as date),'YYYY')||','||to_char(to_number(to_char(cast(end_interval_time as date),'MM'))-1)||','||to_char(cast(end_interval_time as date),'DD,HH24,MI') chart_dt
    ,round(((cast(end_interval_time as date)-nvl(lag(cast(end_interval_time as date)) over (partition by startup_time order by snap_id),cast(end_interval_time as date))))*24*60*60) ela_sec
    ,startup_time
    ,case when nvl(lag(startup_time) over(order by startup_time),startup_time) <> startup_time then 1 else 0 end restart
  from dba_hist_snapshot
  where snap_id between :bsnap and :esnap
    and dbid = (select dbid from v$database)
    and instance_number = (select instance_number from v$instance)
),
stat_cpu as
(
SELECT snap_id,dbid,instance_number
  ,upper(stat_name) stat_name
  ,round((value-lag(value) over (partition by startup_time,stat_name order by snap_id))/1000000/60,2) cpu_min
FROM dba_hist_sys_time_model
join snap using(snap_id,dbid,instance_number)
where upper(stat_name) in('BACKGROUND CPU TIME','DB CPU')
),
stat as
(
  select snap_id,dbid,instance_number,wait_class,round((time_waited_micro-lag(time_waited_micro) over(partition by wait_class order by snap_id))/1e6/60,2) as time_waited_min
  from
  (
    select
      snap_id,dbid,instance_number,wait_class,sum(time_waited_micro) as time_waited_micro
    from dba_hist_system_event  
      join snap using(snap_id,dbid,instance_number)
    where wait_class <> 'Idle'
    group by snap_id,dbid,instance_number,wait_class
  ) 
), 
chart_data_waits as
(
select 
  *
from stat 
pivot
  (
    sum(time_waited_min)
    for wait_class in
      (
        'Queueing' as queueing,
        'User I/O' as user_io,
        'Network' as Network,
        'Application' as Application,
        'Concurrency' as Concurrency,
        'Administrative' as Administrative,
        'Configuration' as Configuration,
        'Scheduler' as Scheduler,
        'Cluster' as clust,
        'Other' as Other,        
        'System I/O' as system_io,
        'Commit' as Commit_
      )
  ) 
where user_io is not null
)
,chart_data_cpu as
(
select *
from stat_cpu
pivot
  (
    max(cpu_min)
    for (stat_name) in
    (
      'DB CPU' as DB_CPU,
      'BACKGROUND CPU TIME' as background_CPU
    )
  )
where DB_CPU is not null
)
select 
  '[new Date('||chart_dt||'),'||
  c.DB_CPU||','||
  c.background_CPU||','||
  w.Administrative||','||
  w.Application||','||
  nvl(w.Clust,0)||','||
  w.Commit_||','||
  w.Concurrency||','||
  w.Configuration||','||
  w.Network||','||
  w.Other||','||
  w.Queueing||','||
  w.Scheduler||','||
  w.System_io||','||
  w.user_io||
  ']'||case when rn=1 then '' else ',' end
from chart_data_waits w join chart_data_cpu c using(snap_id,dbid,instance_number) join snap using(snap_id,dbid,instance_number)
where snap.restart=0
order by snap_id;

prompt       ]);;
prompt 
prompt       var options = {
prompt            isStacked: true,
prompt            title: 'Time by wait class (per snapshot)',
prompt            backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt            explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt            titleTextStyle: {fontSize: 16, bold: true},
prompt            focusTarget: 'category',
prompt            legend: {position: 'right', textStyle: {fontSize: 12}},
prompt            tooltip: {textStyle: {fontSize: 11}},
prompt            hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt            vAxis: {title: 'Time in minutes', textStyle: {fontSize: 10}}
prompt       };;
prompt 
prompt       var chart = new google.visualization.AreaChart(document.getElementById('div_wait_class_chart'));;
prompt       chart.draw(data, options);;
prompt       var table = new google.visualization.Table(document.getElementById('div_wait_class_tab'));;
prompt       table.draw(data, {width: '100%', height: '100%',cssClassNames:{headerCell:'gcharttab'}});;
prompt	}
prompt

---------------------------------------------------
-- Wait Class chart end
---------------------------------------------------

---------------------------------------------------
-- Wait Class [single] chart
---------------------------------------------------
prompt     function drawWClassChartSingle() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('datetime', 'Snapshot');;
prompt       data.addColumn('string', 'Wait class');;
prompt       data.addColumn('number', 'Wait time (minutes)');;
prompt       data.addColumn('number', 'Wait time');;
prompt       data.addColumn({type:'string',label:'Wait time (formatted)',role:'tooltip'});;
prompt 
prompt       data.addRows([
with snap as
(
  select /*+materialize*/ /*workaround for Bug 28749853*/ snap_id,dbid,instance_number
    ,cast(end_interval_time as date) as snap_time
    ,row_number() over (order by snap_id desc) rn
    ,to_char(cast(end_interval_time as date),'YYYY')||','||to_char(to_number(to_char(cast(end_interval_time as date),'MM'))-1)||','||to_char(cast(end_interval_time as date),'DD,HH24,MI') chart_dt
    ,round(((cast(end_interval_time as date)-nvl(lag(cast(end_interval_time as date)) over (partition by startup_time order by snap_id),cast(end_interval_time as date))))*24*60*60) ela_sec
    ,startup_time
    ,case when nvl(lag(startup_time) over(order by startup_time),startup_time) <> startup_time then 1 else 0 end restart
  from dba_hist_snapshot
  where snap_id between :bsnap and :esnap
    and dbid = (select dbid from v$database)
    and instance_number = (select instance_number from v$instance)
),
stat_cpu as
(
SELECT snap_id,dbid,instance_number
  ,upper(stat_name) stat_name
  ,round((value-lag(value) over (partition by startup_time,stat_name order by snap_id))/1000000/60,2) cpu_min
FROM dba_hist_sys_time_model
join snap using(snap_id,dbid,instance_number)
where upper(stat_name) in('BACKGROUND CPU TIME','DB CPU')
),
stat as
(
  select snap_id,dbid,instance_number,wait_class,round((time_waited_micro-lag(time_waited_micro) over(partition by wait_class order by snap_id))/1e6/60,2) as time_waited_min
  from
  (
    select
      snap_id,dbid,instance_number,wait_class,sum(time_waited_micro) as time_waited_micro
    from dba_hist_system_event  
      join snap using(snap_id,dbid,instance_number)
    where wait_class <> 'Idle'
    group by snap_id,dbid,instance_number,wait_class
  ) 
), 
chart_data as
(
select 
  snap_id
  ,dbid
  ,instance_number 
  ,wait_class
  ,time_waited_min
  ,row_number() over (order by snap_id,wait_class) grn
from (
  select
    snap_id
    ,dbid
    ,instance_number 
    ,wait_class
    ,time_waited_min
  from stat 
  where time_waited_min >=0
  union all
  select
    snap_id
    ,dbid
    ,instance_number 
    ,stat_name
    ,cpu_min
  from stat_cpu
  where cpu_min >=0
  )   
)
select 
  decode(grn,1,'',',')||
  '[new Date('||chart_dt||'),'||
  ''''||w.wait_class||''','||
  w.time_waited_min||','||
  w.time_waited_min||','||
  ''''||w.wait_class||': '||cast(numtodsinterval(w.time_waited_min,'MINUTE')  as interval day(2) to second(0))||''']'
from chart_data w join snap using(snap_id,dbid,instance_number)
where snap.restart=0
order by snap_id,wait_class;


prompt       ]);;
prompt
prompt		var dashboard = new google.visualization.Dashboard(document.getElementById('div_wait_class_single_chart'));;
prompt
prompt        var filter = new google.visualization.ControlWrapper({
prompt          controlType: 'CategoryFilter',
prompt          containerId: 'div_wait_class_single_filter',
prompt          options: {
prompt            filterColumnLabel: 'Wait class',
prompt			  ui: {
prompt		        allowMultiple: false,
prompt				allowNone: false
prompt			  }
prompt          },
prompt			state: {selectedValues: ['User I/O']}
prompt        });;
prompt
prompt       var chart = new google.visualization.ChartWrapper({
prompt          chartType: 'LineChart',
prompt          containerId: 'div_wait_class_single_chart',
prompt          options: {
prompt            	title: 'Time by wait class (per snapshot)',
prompt            	backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt            	explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt            	titleTextStyle: {fontSize: 16, bold: true},
prompt            	focusTarget: 'category',
prompt            	legend: {position: 'right', textStyle: {fontSize: 12}},
prompt            	tooltip: {textStyle: {fontSize: 11}},
prompt            	hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt            	vAxis: {title: 'Value', textStyle: {fontSize: 10}, format: 'short'}
prompt				},
prompt		  	view: {columns: [0,3,4]}  
prompt        });;	
prompt
prompt
prompt        dashboard.bind([filter], [chart]);;
prompt        dashboard.draw(data);;	
prompt
prompt	}
prompt

---------------------------------------------------
-- Wait Class [single] chart end
---------------------------------------------------


spool off
set termout on
prompt Gathering wait time histograms...
set termout off
spool &&MAINREPORTFILE append

---------------------------------------------------
-- Event hist chart 
---------------------------------------------------
prompt     function drawWaitEvHistChart() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('datetime', 'Snapshot');;
prompt       data.addColumn('string', 'Event name');;
--prompt       data.addColumn('number', '< 0.5ms');;
prompt       data.addColumn('number', '< 1ms');;
prompt       data.addColumn('number', '< 2ms');;
prompt       data.addColumn('number', '< 4ms');;
prompt       data.addColumn('number', '< 8ms');;
prompt       data.addColumn('number', '< 16ms');;
prompt       data.addColumn('number', '< 32ms');;
prompt       data.addColumn('number', '< 64ms');;
prompt       data.addColumn('number', '< 128ms');;
prompt       data.addColumn('number', '< 256ms');;
prompt       data.addColumn('number', '< 0.5s');;
prompt       data.addColumn('number', '< 1s');;
prompt       data.addColumn('number', '< 2s');;
prompt       data.addColumn('number', '< 4s');;
prompt       data.addColumn('number', '< 8s');;
prompt       data.addColumn('number', '< 16s');;
prompt       data.addColumn('number', '> 16s');;
prompt 
prompt       data.addRows([
with snap as
(
  select /*+materialize*/ /*workaround for Bug 28749853*/ snap_id,dbid,instance_number
    ,cast(end_interval_time as date) as snap_time
    --,row_number() over (order by snap_id desc) rn
    ,to_char(cast(end_interval_time as date),'YYYY')||','||to_char(to_number(to_char(cast(end_interval_time as date),'MM'))-1)||','||to_char(cast(end_interval_time as date),'DD,HH24,MI') chart_dt
    ,round(((cast(end_interval_time as date)-nvl(lag(cast(end_interval_time as date)) over (partition by startup_time order by snap_id),cast(end_interval_time as date))))*24*60*60) ela_sec
    ,startup_time
    ,case when nvl(lag(startup_time) over(order by startup_time),startup_time) <> startup_time then 1 else 0 end restart
  from dba_hist_snapshot
  where snap_id between :bsnap and :esnap
    and dbid = (select dbid from v$database)
    and instance_number = (select instance_number from v$instance)
),
ev_hist as
(
select snap_id,dbid,instance_number,rn,event_name,wtmil,wait_count
,Round(Ratio_To_Report(wait_count) over(PARTITION BY snap_id,instance_number,event_id)*100,2) pct
from(
select snap_id,dbid,instance_number
  ,row_number() over (order by snap_id desc,event_name desc) rn
  ,event_id
  ,event_name
  ,wait_time_milli wtmil
  --,wait_count
  ,wait_count-lag(wait_count) over(partition by snap.startup_time,event_id,wait_time_milli order by snap_id) wait_count
  --,Round(Ratio_To_Report(wait_count) over(PARTITION BY snap_id,instance_number,event_id)*100,2) pct
from dba_hist_event_histogram
  join snap using(snap_id,dbid,instance_number)
where
  event_name in
  (
    'log file sync'
    ,'db file sequential read'
    ,'log file parallel write'
    ,'db file scattered read'
    ,'direct path read'
    ,'direct path read temp'
    ,'direct path write temp'
    ,'db file parallel read'
    ,'flashback log file write'
    ,'control file sequential read'
  )
)
),
chart_data as
(
select snap_id,dbid,instance_number
  ,row_number() over (order by snap_id desc,event_name desc) rn
  ,event_name
  ,sum(case when wtmil <= 1 then pct else 0 end) as "< 1ms"
  --,sum(decode(wtmil,1,pct,0)) as "< 1ms"
  ,sum(decode(wtmil,2,pct,0)) as "< 2ms"
  ,sum(decode(wtmil,4,pct,0)) as "< 4ms"
  ,sum(decode(wtmil,8,pct,0)) as "< 8ms"
  ,sum(decode(wtmil,16,pct,0)) as "< 16ms"
  ,sum(decode(wtmil,32,pct,0)) as "< 32ms"
  ,sum(decode(wtmil,64,pct,0)) as "< 64ms"
  ,sum(decode(wtmil,128,pct,0)) as "< 128ms"
  ,sum(decode(wtmil,256,pct,0)) as "< 256ms"
  ,sum(decode(wtmil,512,pct,0)) as "< 0.5s"
  ,sum(decode(wtmil,1024,pct,0)) as "< 1s"
  ,sum(decode(wtmil,2048,pct,0)) as "< 2s"
  ,sum(decode(wtmil,4096,pct,0)) as "< 4s"
  ,sum(decode(wtmil,8192,pct,0)) as "< 8s"
  ,sum(decode(wtmil,16384,pct,0)) as "< 16s"
  ,sum(case when wtmil > 16384 then pct else 0 end) as "> 16s"  
from ev_hist 
group by snap_id,dbid,instance_number,event_name
) 
select
  '[new Date('||chart_dt||'),'||
  ''''||event_name||''','||
  --"< 0.5ms"||','||
  "< 1ms"||','||
  "< 2ms"||','||
  "< 4ms"||','||
  "< 8ms"||','||
  "< 16ms"||','||
  "< 32ms"||','||
  "< 64ms"||','||
  "< 128ms"||','||
  "< 256ms"||','||
  "< 0.5s"||','||
  "< 1s"||','||
  "< 2s"||','||
  "< 4s"||','||
  "< 8s"||','||
  "< 16s"||','||
  "> 16s"||
  ']'||case when rn=1 then '' else ',' end
from chart_data join snap using(snap_id,dbid,instance_number)
where snap.restart=0
order by snap_id,event_name;

prompt    ]);;
prompt
prompt		var dashboard = new google.visualization.Dashboard(document.getElementById('div_event_hist'));;
prompt
prompt        var wclassCategory = new google.visualization.ControlWrapper({
prompt          controlType: 'CategoryFilter',
prompt          containerId: 'div_event_hist_filter',
prompt          options: {
prompt            filterColumnLabel: 'Event name',
prompt			ui: {
prompt				allowMultiple: false,
prompt				allowNone: false
prompt			}
prompt          },
prompt			state: {selectedValues: ['log file parallel write']}
prompt        });;
prompt
prompt       var chart = new google.visualization.ChartWrapper({
prompt          chartType: 'AreaChart',
prompt          containerId: 'div_event_hist_chart',
prompt          options: {
prompt				isStacked: 'percent',
prompt				title: 'Wait event histogram %',
prompt				backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt				explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt				titleTextStyle: {fontSize: 16, bold: true},
prompt				focusTarget: 'category',
prompt				legend: {position: 'right', textStyle: {fontSize: 12}},
prompt				tooltip: {textStyle: {fontSize: 11}},
prompt				hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt				vAxis: {title: 'Percent of waits (histogram)', textStyle: {fontSize: 10} , format: 'percent'}
prompt				},
prompt		  view: {columns: [0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]}  
prompt        });;	
prompt
prompt
prompt        dashboard.bind([wclassCategory], [chart]);;
prompt        dashboard.draw(data);;		
prompt 
prompt 	}

---------------------------------------------------
-- Event hist chart end
---------------------------------------------------


---------------------------------------------------
-- Wait class hist chart 
---------------------------------------------------
prompt     function drawWaitClHistChart() {
prompt       var data = new google.visualization.DataTable();;
prompt       data.addColumn('datetime', 'Snapshot');;
prompt       data.addColumn('string', 'Wait class');;
--prompt       data.addColumn('number', '< 0.5ms');;
prompt       data.addColumn('number', '< 1ms');;
prompt       data.addColumn('number', '< 2ms');;
prompt       data.addColumn('number', '< 4ms');;
prompt       data.addColumn('number', '< 8ms');;
prompt       data.addColumn('number', '< 16ms');;
prompt       data.addColumn('number', '< 32ms');;
prompt       data.addColumn('number', '< 64ms');;
prompt       data.addColumn('number', '< 128ms');;
prompt       data.addColumn('number', '< 256ms');;
prompt       data.addColumn('number', '< 0.5s');;
prompt       data.addColumn('number', '< 1s');;
prompt       data.addColumn('number', '< 2s');;
prompt       data.addColumn('number', '< 4s');;
prompt       data.addColumn('number', '< 8s');;
prompt       data.addColumn('number', '< 16s');;
prompt       data.addColumn('number', '> 16s');;
prompt 
prompt       data.addRows([
with snap as
(
  select /*+materialize*/ /*workaround for Bug 28749853*/ snap_id,dbid,instance_number
    ,cast(end_interval_time as date) as snap_time
    ,row_number() over (order by snap_id desc) rn
    ,to_char(cast(end_interval_time as date),'YYYY')||','||to_char(to_number(to_char(cast(end_interval_time as date),'MM'))-1)||','||to_char(cast(end_interval_time as date),'DD,HH24,MI') chart_dt
    ,round(((cast(end_interval_time as date)-nvl(lag(cast(end_interval_time as date)) over (partition by startup_time order by snap_id),cast(end_interval_time as date))))*24*60*60) ela_sec
    ,startup_time
    ,case when nvl(lag(startup_time) over(order by startup_time),startup_time) <> startup_time then 1 else 0 end restart
  from dba_hist_snapshot
  where snap_id between :bsnap and :esnap
    and dbid = (select dbid from v$database)
    and instance_number = (select instance_number from v$instance)
),
ev_hist as
(
select snap_id,dbid,instance_number,wait_class,wtmil
,Round(Ratio_To_Report(wait_count) over(PARTITION BY snap_id,instance_number,wait_class)*100,2) pct
from
(
SELECT snap_id,dbid,instance_number
  ,wait_class
  ,wait_time_milli wtmil
  --,wait_count
  ,wait_count-lag(wait_count) over(partition by snap.startup_time,wait_class,wait_time_milli order by snap_id) wait_count
  --,Round(Ratio_To_Report(wait_count) over(PARTITION BY snap_id,instance_number,wait_class)*100,2) pct
FROM (SELECT snap_id,dbid,instance_number
        ,wait_class
        --,wait_class_id
        ,wait_time_milli
        ,sum(wait_count) wait_count
      FROM dba_hist_event_histogram
      where wait_class <> 'Idle'
      group by snap_id,dbid,instance_number
        ,wait_class
        ,wait_time_milli
      )
join snap using(snap_id,dbid,instance_number)
)
),
chart_data as
(
select snap_id,dbid,instance_number
  ,wait_class
  ,row_number() over (order by snap_id desc,wait_class desc) rn
  ,sum(case when wtmil <= 1 then pct else 0 end) as "< 1ms"
  --,sum(decode(wtmil,1,pct,0)) as "< 1ms"
  ,sum(decode(wtmil,2,pct,0)) as "< 2ms"
  ,sum(decode(wtmil,4,pct,0)) as "< 4ms"
  ,sum(decode(wtmil,8,pct,0)) as "< 8ms"
  ,sum(decode(wtmil,16,pct,0)) as "< 16ms"
  ,sum(decode(wtmil,32,pct,0)) as "< 32ms"
  ,sum(decode(wtmil,64,pct,0)) as "< 64ms"
  ,sum(decode(wtmil,128,pct,0)) as "< 128ms"
  ,sum(decode(wtmil,256,pct,0)) as "< 256ms"
  ,sum(decode(wtmil,512,pct,0)) as "< 0.5s"
  ,sum(decode(wtmil,1024,pct,0)) as "< 1s"
  ,sum(decode(wtmil,2048,pct,0)) as "< 2s"
  ,sum(decode(wtmil,4096,pct,0)) as "< 4s"
  ,sum(decode(wtmil,8192,pct,0)) as "< 8s"
  ,sum(decode(wtmil,16384,pct,0)) as "< 16s"
  ,sum(case when wtmil > 16384 then pct else 0 end) as "> 16s"
from ev_hist
group by snap_id,dbid,instance_number,wait_class
)
select  
  '[new Date('||chart_dt||'),'||
  ''''||wait_class||''','||
  --"< 0.5ms"||','||
  "< 1ms"||','||
  "< 2ms"||','||
  "< 4ms"||','||
  "< 8ms"||','||
  "< 16ms"||','||
  "< 32ms"||','||
  "< 64ms"||','||
  "< 128ms"||','||
  "< 256ms"||','||
  "< 0.5s"||','||
  "< 1s"||','||
  "< 2s"||','||
  "< 4s"||','||
  "< 8s"||','||
  "< 16s"||','||
  "> 16s"||
  ']'||case when chart_data.rn=1 then '' else ',' end
from chart_data join snap using(snap_id,dbid,instance_number)
where snap.restart=0
order by snap_id,wait_class;

prompt       ]);;


prompt		var dashboard = new google.visualization.Dashboard(document.getElementById('div_wclass_hist_filter'));;
prompt
prompt        var wclassCategory = new google.visualization.ControlWrapper({
prompt          controlType: 'CategoryFilter',
prompt          containerId: 'div_wclass_hist_filter',
prompt          options: {
prompt            filterColumnLabel: 'Wait class',
prompt			  ui: {
prompt				allowMultiple: false,
prompt				allowNone: false
prompt			  }
prompt          },
prompt			state: {selectedValues: ['User I/O']}
prompt        });;
prompt
prompt       var chart = new google.visualization.ChartWrapper({
prompt          chartType: 'AreaChart',
prompt          containerId: 'div_wclass_hist_chart',
prompt          options: {
prompt				isStacked: 'percent',
prompt				title: 'Wait class histogram %',
prompt				backgroundColor: {fill: '#ffffff', stroke: '#0077b3', strokeWidth: 1},
prompt				explorer: {actions: ['dragToZoom', 'rightClickToReset'], axis:'horizontal', maxZoomIn: 0.2},
prompt				titleTextStyle: {fontSize: 16, bold: true},
prompt				focusTarget: 'category',
prompt				legend: {position: 'right', textStyle: {fontSize: 12}},
prompt				tooltip: {textStyle: {fontSize: 11}},
prompt				hAxis: {slantedText:true, slantedTextAngle:45, textStyle: {fontSize: 10}},
prompt				vAxis: {title: 'Percent of waits (histogram)', textStyle: {fontSize: 10} , format: 'percent'}
prompt				},
prompt		  view: {columns: [0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]}  
prompt        });;	
prompt
prompt
prompt        dashboard.bind([wclassCategory], [chart]);;
prompt        dashboard.draw(data);;	
prompt 
prompt 	}
---------------------------------------------------
-- Wait class hist chart END
---------------------------------------------------

spool off
spool &&MAINREPORTFILE append

prompt   </script>
---------------------------------------------------
-- CSS
---------------------------------------------------
prompt <style type="text/css">
prompt   body {font-family: Arial,Helvetica,Geneva,sans-serif; font-size:8pt; text-color: black; background-color: white;}
prompt   table.sql {font-size:8pt; color:#333366; width:70%; border-width: 2px; border-color: #000000; border-collapse: collapse; margin-left:10px;} 
prompt   th {border-width: 1px; background-color:#d9d9d9; padding: 3px; border-style: solid; border-color: #000000;} 
prompt   tr:nth-child(even) {background: #f2f2f2}
prompt   tr:nth-child(odd) {background: #FFFFFF}
prompt   tr:hover {color:black; background:#e6f2ff;}
prompt   td {border-width: 1px; padding: 2px; border-style: solid; border-color: #000000; color:#000000;} 
prompt   th.gcharttab {font-size:8pt;font-weight:bold; background: linear-gradient(to top, #9494b8 0%, #c2c2d6 100%);}
prompt   td.gcharttab {font-size:8pt;}
prompt   h1 {font-size:16pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px; text-align:center;}
prompt   h2 {font-size:12pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px;}
prompt   h3 {font-size:10pt; font-weight:bold; text-decoration:underline; color:#333366; padding:10px 2px 1px 5px;}
prompt   pre {font:8pt monospace;Monaco,"Courier New",Courier;}
prompt   font.footnote {font-size:8pt; font-style:italic; color:#555;}
prompt   li.footnote {font-size:8pt; font-style:italic; color:#555;}
prompt   a.toc:link, a.toc:visited {font-size:10pt; font-weight:bold; text-decoration:none; color:#333366;}
prompt   a.toc:hover {font-size:10pt; font-weight:bold; text-decoration:underline; color:#333366; background-color:#eeeef6}
prompt   a.fnnav:link, a.fnnav:visited {font-size:8pt; font-weight:bold; text-decoration:none; color:#333366;font-style:italic;}
prompt   a.fnnav:hover {font-size:8pt; font-weight:bold; text-decoration:underline; color:#333366; background-color:#eeeef6;font-style:italic;}
prompt   div.tab1200 {width:1200px; resize: vertical; overflow:auto;}
prompt   div.tab100pct {width:100%; resize: vertical; overflow:auto;}
prompt   .google-visualization-table-table *  { font-size:8pt; }
prompt </style>
prompt </head>
---------------------------------------------------
-- BODY
---------------------------------------------------
prompt <body>
prompt <h1> IO response time report for database: &&db_n., instance: &&inst_num., interval: &&bdate - &&edate </h1>
prompt <h2> Database info </h2>
set markup html on head "" TABLE "class='sql' style='width:900px;'"
set pagesize 100
select d.name,d.dbid,to_char(d.created,'&&DT_FMT_ISO') created,i.instance_number as inst_id,i.host_name,d.platform_name,i.version,i.status,to_char(i.startup_time,'&&DT_FMT_ISO') startup_time
from v$database d,v$instance i;

set markup html on head "" TABLE "class='sql' style='width:300px;'"
select 'CPU sockets:' as host_property, cpu_socket_count_current as value from v$license union
select 'CPU cores:' as property, cpu_core_count_current as value from v$license union
select 'CPU threads:' as property, cpu_count_current as value from v$license union
select 'Physical mem (GB):',round(value/1024/1024/1024) From v$osstat where osstat_id=1008
;


set markup html on head "" TABLE "class='sql' style='width:600px;'"
select 'Begin snap:' as " ",snap_id,to_char(end_interval_time,'YYYY-MM-DD HH24:MI') snap_time,to_char((end_interval_time-startup_time) day(3) to second(0),'DDD HH24:MI:SS') uptime,value as sessions
from dba_hist_snapshot join dba_hist_sysstat ss using(snap_id,dbid,instance_number)
where snap_id=:bsnap and ss.stat_name='logons current'
union all
select 'Begin snap:' as " ",snap_id,to_char(end_interval_time,'YYYY-MM-DD HH24:MI') snap_time,to_char((end_interval_time-startup_time) day(3) to second(0),'DDD HH24:MI:SS') uptime,value as sessions
from dba_hist_snapshot join dba_hist_sysstat ss using(snap_id,dbid,instance_number)
where snap_id=:esnap and ss.stat_name='logons current';

set pagesize 0
set markup html off

prompt <h2 id="h_toc"> Reports list </h2>
prompt <ul>
prompt  <li><a class="toc" href="#h_wait_class_time_single">Time waited (by wait class - single)</a></li> 
prompt  <li><a class="toc" href="#h_wait_class_hist">Wait class histograms</a></li> 
prompt  <li><a class="toc" href="#h_io_wait_ev_hist">IO wait events histograms</a></li> 
prompt </ul>


prompt <h2 id="h_wait_class_time_single"> Time by wait class (single) </h2>
prompt <div id="div_wait_class_single">
prompt 	<div id="div_wait_class_single_filter" style='width:1200px;padding:10px;'></div>
prompt 	<div id="div_wait_class_single_chart" style='width:1200px; height: 500px;'></div>
prompt </div>
prompt <a class="fnnav" href="#h_toc">back to top</a>


prompt <h2 id="h_wait_class_hist"> Wait class histograms (percent of total waits) </h2>
prompt <div id="div_wclass_hist">
prompt 	<div id="div_wclass_hist_filter" style='width:1200px;padding:10px;'></div>
prompt 	<div id="div_wclass_hist_chart" style='width:1200px; height: 500px;'></div>
prompt </div>
prompt <a class="fnnav" href="#h_toc">back to top</a>

prompt <h2 id="h_io_wait_ev_hist"> Wait events (I/O related) histograms (percent of total waits) </h2>
prompt <div id="div_event_hist">
prompt 	<div id="div_event_hist_filter" style='width:1200px;padding:10px;'></div>
prompt 	<div id="div_event_hist_chart" style='width:1200px; height: 500px;'></div>
prompt </div>
prompt <a class="fnnav" href="#h_toc">back to top</a>



prompt <a class="fnnav" href="#h_toc">back to top</a>
prompt 
prompt <hr>
prompt </body>
prompt </html>
prompt 

spool off

begin
  :etime := dbms_utility.get_time();
end;
/

col host_grep_cmd new_val host_grep_cmd noprint
select 
  case 
    when upper('&&_EDITOR') = 'NOTEPAD' then
      'findstr "^ORA- ^PLS- ^SP2-"'
    else
      'grep -E "^ORA-|^PLS-|^SP2-"'
  end host_grep_cmd
from dual;

set termout on
prompt ==================================================================
prompt Generated report: &&MAINREPORTFILE
prompt ==================================================================

col "Elapsed time" form A15
select cast(numtodsinterval((:etime-:stime)/100,'SECOND') as interval day(0) to second(0)) as "Elapsed time" from dual;

prompt ==================================================================
prompt  Checking for errors in generated report...
prompt  If anything is reported below, charts will not display properly...
prompt ==================================================================
host &&host_grep_cmd &&MAINREPORTFILE

exit;
