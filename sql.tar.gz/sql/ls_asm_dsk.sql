col dg_name FORM A8
col dsk_name FORM A12
col path FORM A18
col mnt_stat FORM A10
col header_stat FORM A10
col mode_stat FORM A12
col state FORM A8
col total_gb FORM 999G990D0
col os_gb FORM 999G990D0
col free_gb FORM 999G990D0
col library form A12 trunc
col failgroup form A12

set line 200 pagesize 200

break on dg_name skip 1
compute sum of total_gb on dg_name
compute sum of free_gb on dg_name

SELECT 
  dg.name dg_name,
  d.name dsk_name,
  d.path,
  d.mount_status mnt_stat,
  d.header_status header_stat,
  d.mode_status mode_stat,
  d.failgroup,
  d.library,
  d.state,
  round(d.os_mb/1024,1) os_gb,
  round(d.total_mb/1024,1) total_gb,
  round(d.free_mb/1024,1) free_gb,
  d.repair_timer,
  d.read_errs as r_errs#,
  d.write_errs as w_errs#
FROM v$asm_diskgroup dg, v$asm_disk d
WHERE d.group_number=dg.group_number(+)
ORDER BY 1,2,3;


clear breaks
clear computes 
