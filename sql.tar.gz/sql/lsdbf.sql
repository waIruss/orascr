def TABLESPACE_NAME=&1
set line 200 pagesize 200 verif off
col param_name form A25
col param_value form A25
col tablespace_name form A12 heading TABLESPACE
col retention form A12
col file_name form A50
col file_id form 999 heading "File#"
col size_gb form 999G990D0 heading "Size GB"
col free_gb form 999G990D0 heading "Free GB"
col max_gb form 999G999D0 heading "Max GB"
col pct_used_max form 90D09 heading  "% Used Max" 
col MB form 999G999D0 heading "MB"
col autoext form A4 heading "Auto|ext"
col incr_mb form 9G999D0 heading "Incr MB"
col undoseg_status form A16
compute sum of size_gb on report
compute sum of free_gb on report
compute sum of max_gb on report
compute sum of pct_used_max on report

break on tablespace_name skip 1 on report



SELECT tablespace_name,file_id,dbf.file_name,
  Round(dbf.bytes/1024/1024/1024,2) size_gb, 
  Round(Nvl(fbytes,0)/1024/1024/1024,2) free_gb,
  dbf.autoextensible autoext,
  Round(dbf.increment_by*t.block_size/1024/1024) incr_mb,
  Round(Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)/1024/1024/1024,2) max_gb,
  Round((Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)-Nvl(fbytes,0)-Decode(dbf.maxbytes,0,0,dbf.maxbytes-dbf.bytes))
  /Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)*100,2) pct_used_max
FROM dba_data_files dbf 
  JOIN dba_tablespaces t USING(tablespace_name)
  left OUTER JOIN (
    SELECT file_id,Sum(bytes) fbytes FROM dba_free_space WHERE tablespace_name=upper('&&TABLESPACE_NAME')  GROUP BY file_id
  ) free_spc USING(file_id)
WHERE tablespace_name = upper('&&TABLESPACE_NAME')
UNION ALL
SELECT tablespace_name,file_id,dbf.file_name,
  Round(dbf.bytes/1024/1024/1024,2) size_gb, 
  Round((Nvl(dbf.bytes,0)-free_spc.bytes_used)/1024/1024/1024,2) free_gb,
  dbf.autoextensible autoext,
  Round(dbf.increment_by*t.block_size/1024/1024) incr_mb,
  Round(Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)/1024/1024/1024,2) max_gb,
  Round((Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)-(Nvl(dbf.bytes,0)-free_spc.bytes_used)-Decode(dbf.maxbytes,0,0,dbf.maxbytes-dbf.bytes))
  /Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)*100,2) pct_used_max
FROM dba_temp_files dbf 
  JOIN dba_tablespaces t USING(tablespace_name)
  left OUTER JOIN (
    SELECT file_id, bytes_used FROM v$temp_extent_pool WHERE tablespace_name=upper('&&TABLESPACE_NAME') 
  ) free_spc USING(file_id)
WHERE tablespace_name = upper('&&TABLESPACE_NAME')
order by file_id;

undef TABLESPACE_NAME
undef 1

clear compute
clear break
