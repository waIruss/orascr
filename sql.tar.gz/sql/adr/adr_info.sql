---------------------------------------
-- v$diag_info
---------------------------------------
set line 230 pagesize 100
col shortp_policy form A20
col longp_policy form A20
prompt *******************************************************
prompt ** shortp_policy: trace files, packages, core dumps
prompt ** longp_policy: incident files, alert log
prompt *******************************************************

select shortp_policy ||'h ['||shortp_policy/24||' days]' shortp_policy
   ,longp_policy ||'h ['||longp_policy/24||' days]' longp_policy
   ,to_char(last_autoprg_time,'YYYY-MM-DD HH24:MI:SS') last_autopurg_time
   ,to_char(last_manuprg_time,'YYYY-MM-DD HH24:MI:SS') last_manuprg_time
from V$DIAG_ADR_CONTROL;

col name form A30
col value form A120
select name,value from v$diag_info;

