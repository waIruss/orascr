set line 230 pagesize 500
set verify off

prompt ################################################################################
accept SESSION_ID prompt 'Enter session_id (default: 0=all): ' default '0'
accept BG_PROC_NAME prompt 'Enter background program name [lgwr, dbw, etc.] (default: %): ' default '%'
accept OSPID prompt 'Enter ospid (default: %): ' default '%'
accept DAYS prompt 'Enter number of days back to search (default: 3): ' default '3'
accept NROWS prompt 'Enter max rows to display (default: 1000): ' default '1000'
prompt ################################################################################


col trace_filename form A30
col timestamp form A20
col session_id form 9999999
col serial# form 999999
col payload form A150

with f as (
select trace_filename,row_number() over(order by time_ desc) rn from
   (
      select trace_filename,min(timestamp) time_
      from v$diag_trace_file_contents
      where (session_id=&SESSION_ID or trim('&SESSION_ID') = '0')
      and (trace_filename like '%&BG_PROC_NAME.%' or trim('&BG_PROC_NAME') = '%')
      and (trace_filename like '%&OSPID..trc' or trim('&OSPID') = '%')
      and timestamp > sysdate - &DAYS
      group by trace_filename
   )
)
select * from (
select fc.trace_filename,session_id,serial#
   ,to_char(timestamp,'YYYY-MM-DD HH24:MI:SS') timestamp
   --,to_char(max(timestamp),'YYYY-MM-DD HH24:MI:SS') max_time
   ,payload
   --,regexp_replace(payload,'[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{6}.*{1}[0-9]{2}:[0-9]{2}','')
from v$diag_trace_file_contents fc, f
where fc.trace_filename=f.trace_filename
and timestamp >= sysdate - &DAYS
order by f.rn,fc.line_number
) where rownum <= &NROWS;

