set verify off
set heading on
def startdate="&1"
def enddate="&2"

SELECT *
FROM (
  SELECT /*+ PARALLEL(4) */
         SAMPLE_TIME
        ,CAST(SAMPLE_TIME AS DATE) SAMPLE_TIME_
        ,TO_CHAR(SAMPLE_TIME,'YYYY/MM/DD HH24:MI:SS') SAMPLE_TIME_AS_TEXT
        ,CASE WHEN EVENT IS NULL   THEN 'CPU' 
              WHEN EVENT IN ('latch: cache buffers chains'
                            ,'enq: UL - contention'
                            ,'buffer busy waits'
                            )      THEN EVENT
              WHEN EVENT LIKE '%latch%' THEN 'latch'
              WHEN EVENT LIKE '%mutex%' THEN 'mutex'
              WHEN WAIT_CLASS IN ('Administrative'
                                 ,'Application'
                                 ,'Cluster'
                                 ,'Commit'
                                 ,'Concurrency'
                                 ,'Configuration'
                                 ,'Idle'
                                 ,'Network'
                                 ,'Queueing'
                                 ,'Scheduler'
                                 ,'System I/O'
                                 ,'User I/O'
                                 ,'Other'
                                 ) THEN WAIT_CLASS
                                   ELSE 'Unacc'
          END WAIT_CLASS
  FROM   DBA_HIST_ACTIVE_SESS_HISTORY
  WHERE  SAMPLE_TIME between TO_DATE('&startdate','YYYY-MM-DD HH24:MI') and TO_DATE('&&enddate','YYYY-MM-DD HH24:MI')
)
PIVOT (COUNT(*)
FOR    WAIT_CLASS IN ('CPU' as "CPU"
                     ,'latch: cache buffers chains' as "latch: cache buffers chains"
                     ,'latch' as "latch"
                     ,'mutex' as "mutex"
                     ,'buffer busy waits' as "buffer busy waits"
                     ,'Concurrency' as "Concurrency"
                     ,'User I/O' as "User I/O"
                     ,'System I/O' as "System I/O"
                     ,'enq: UL - contention' as "enq: UL - contention"
                     ,'Application' as "Application"
                     ,'Commit' as "Commit"
                     ,'Configuration' as "Configuration"
                     ,'Administrative' as "Administrative"
                     ,'Cluster' as "Cluster"
                     ,'Network' as "Network"
                     ,'Queueing' as "Queueing"
                     ,'Scheduler' as "Scheduler"
                     ,'Other' as "Other"
                     ,'Idle' as "Idle"
                     ,'Unacc' as "Unacc"
                     )
)
ORDER BY SAMPLE_TIME;


