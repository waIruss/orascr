-------------------------------------------------------------------------------
-- DESCRIPTION: Helper script for simple ad-hoc queries formatting
--	Accepts table or view name as an argument, 
--	optionally followed by WHERE and/or ORDER BY clause
--	Limits output to 50 rows, to prevent screen flooding
-- 
-- Usage: 
--	@prnt <table_name>
--	@prnt gv$instance
-- 	@prnt "dba_users where username like 'T2%'"
-------------------------------------------------------------------------------

set verify off
set linesize 180 pagesize 200
set serveroutput on

define query = "&1"

DECLARE
    v_cid          NUMBER;
    t_desctab      dbms_sql.desc_tab;
    v_colcnt       NUMBER;
    v_sqlstmt      VARCHAR2(2000);
    v_colval       VARCHAR2(4000);
    v_colclobv     CLOB;
    v_rowcnt       INTEGER;
    v_fetchlimit   CONSTANT PLS_INTEGER := 50;
    v_lobfetchlimit   CONSTANT PLS_INTEGER := 500;
    v_fetchcnt     INTEGER;

BEGIN
    if (upper(ltrim(q'^&&QUERY^')) like 'SELECT %' or upper(ltrim(q'^&&QUERY^')) like 'WITH %') then
      v_sqlstmt := q'^&&QUERY^';
    else
      v_sqlstmt := q'^select * from &&QUERY^';
    end if;
    v_cid := dbms_sql.open_cursor;

    dbms_sql.parse(
        v_cid,
        v_sqlstmt,
        dbms_sql.native
    );

    dbms_sql.describe_columns(
        v_cid,
        v_colcnt,
        t_desctab
    );

    EXECUTE IMMEDIATE 'alter session set nls_date_format=''YYYY-MM-DD HH24:MI:SS''';

    FOR i IN 1..v_colcnt LOOP
      IF t_desctab(i).col_type = 112 THEN
        dbms_sql.define_column(
            v_cid,
            i,
            v_colclobv
        );
      ELSE 
        dbms_sql.define_column(
            v_cid,
            i,
            v_colval,
            4000
        );
      END IF;

    END LOOP;

    v_rowcnt := dbms_sql.execute(v_cid);

    WHILE ( dbms_sql.fetch_rows(v_cid) > 0 AND dbms_sql.last_row_count <= v_fetchlimit)     
      LOOP
        v_fetchcnt := dbms_sql.last_row_count;
        dbms_output.put_line(rpad('-------------------------------- Row '||  TO_CHAR(v_fetchcnt)||  ' ', 80, '-'));

        FOR i IN 1..v_colcnt LOOP
          IF t_desctab(i).col_type = 112 THEN
            dbms_sql.column_value(
                v_cid,
                i,
                v_colclobv
            );
            --dbms_output.put_line(rpad(t_desctab(i).col_name,30)||': '|| Dbms_Lob.substr(v_colclobv,120,1)||', CLOB size: '||Round(Dbms_Lob.getlength(v_colclobv)/1024)||'KB');
            dbms_output.put(rpad(t_desctab(i).col_name,30)||': ');
            IF v_colclobv IS NOT NULL THEN 
              --dbms_output.put_line(Dbms_Lob.substr(v_colclobv,120,1)||', CLOB size: '||Round(Dbms_Lob.getlength(v_colclobv)/1024)||'KB');
              dbms_output.put_line('CLOB size: '||Round(Dbms_Lob.getlength(v_colclobv)/1024)||'KB'||chr(10)||Dbms_Lob.substr(v_colclobv,v_lobfetchlimit,1));
            ELSE
              dbms_output.put_line(' ');
            END IF;
          ELSE
            dbms_sql.column_value(
                v_cid,
                i,
                v_colval
            );
            dbms_output.put_line(rpad(t_desctab(i).col_name,30)||': '|| SubStr(v_colval,1,120));
          END IF;            
        END LOOP;
    --end of while loop
    END LOOP;

    dbms_output.put_line(chr(10)|| '-- ' || TO_CHAR(v_fetchcnt)|| ' row(s) selected --');

    dbms_sql.close_cursor(v_cid);
EXCEPTION
    WHEN OTHERS THEN
        IF dbms_sql.is_open(v_cid) THEN
            dbms_sql.close_cursor(v_cid);
        END IF;
        dbms_output.put_line( dbms_utility.format_error_backtrace);
        RAISE;
END;
/


undef query
undef 1

