spool profile_change_revert.lst
set echo on

-- modifying default profile
alter profile default
limit
idle_time unlimited
password_life_time 180
password_reuse_max unlimited
password_reuse_time unlimited
password_verify_function NULL;

-- moving C and I_MONI users
alter user I_MONI profile default;
alter user C profile default;

-- modifying service_profile
alter profile service_profile
limit
password_reuse_time unlimited;

-- modifying user_profile
alter profile user_profile
limit
password_reuse_time unlimited;

-- dropping c_service_profile
drop profile C_SERVICE_PROFILE;

