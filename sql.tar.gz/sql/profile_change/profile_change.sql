spool profile_change.lst
set echo on

-- moving I_MONI to service_profile
alter user I_MONI profile service_profile;

-- creating new profile for C user – C_SERVICE_PROFILE
create profile C_SERVICE_PROFILE
limit
FAILED_LOGIN_ATTEMPTS 6
idle_time unlimited
password_life_time 90
password_reuse_max unlimited
PASSWORD_REUSE_TIME unlimited
password_verify_function null;

-- moving C to C_SERVICE_PROFILE profile
alter user c profile C_SERVICE_PROFILE;

-- adjusting DEFAULT profile
alter profile default
limit
idle_time 30
password_life_time 90
password_reuse_max 6
password_reuse_time 365
password_verify_function PASSWD_VERIFY_FUNCTION_USER;

-- adjusting service and user profiles
alter profile service_profile
limit
password_reuse_time 365;

alter profile user_profile
limit
password_reuse_time 365;

