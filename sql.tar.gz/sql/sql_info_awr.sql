set verify off feedback off
set serveroutput on
set linesize 240 pagesize 800 long 100000 
col sql_text form A200 wor
col schema form A10
col ela_time form A12
col io_time form A12
col cpu_time form A12
col cc_time form A12
col ap_time form A12
col rows_exec form 999G999G999G999
col execs form 999G999G999G999
col rows_total form 999G999G999G999


def sql_id=&1

accept DT_FMT prompt 'Enter snap date/time format for grouping (default: MM/DD): ' default 'MM/DD'
accept n_last_days prompt 'Enter last days in AWR  (default: 30): ' default '30'

select sql_text from dba_hist_sqltext where sql_id='&sql_id' and rownum <=1;

prompt
prompt ==========================================================================
prompt Execution statistics from AWR
prompt ==========================================================================

with s as 
(
  SELECT
  To_Char(snap.end_interval_time,'&DT_FMT') snap_time, 
  s.sql_id,
  --to_char(s.force_matching_signature) force_matching_signature,
  s.parsing_schema_name schema,
  s.plan_hash_value plan_hash,
  sum(s.executions_delta) execs,
  sum(s.buffer_gets_delta) gets,
  sum(round(s.cpu_time_delta/1000000,5)) AS cpu_sec,
  sum(round(s.ELAPSED_TIME_DELTA/1000000,5)) AS ela_sec,
  sum(round(s.ccwait_delta/1000000,5)) AS conc_sec,
  sum(round(s.apwait_delta/1000000,5)) AS app_sec,
  sum(round(s.iowait_delta/1000000,5)) AS io_sec,
  sum(round(s.physical_read_requests_delta)) phr_req,
  sum(round(s.physical_read_bytes_delta)) phr_bytes,
  sum(round(s.disk_reads_delta)) disk_reads,
  sum(round(s.disk_reads_delta*8)) disk_bytes,
  sum(s.rows_processed_delta) AS rows_total
  FROM dba_hist_sqlstat s join dba_hist_snapshot snap USING(snap_id,dbid,instance_number) join dba_hist_database_instance d using (dbid,instance_number,startup_time)
  WHERE 
    sql_id in('&sql_id')
    and d.db_name = (select name from v$database)
    and trunc(snap.end_interval_time) >= trunc(sysdate - &n_last_days )
    and s.buffer_gets_delta > 0 and s.elapsed_time_delta > 0
  group by To_Char(snap.end_interval_time,'&DT_FMT'), 
  s.sql_id,
  s.parsing_schema_name,
  s.plan_hash_value
  order by 1 
)
select 
  snap_time
  ,schema
  ,sql_id
  ,plan_hash
  ,execs
  ,lpad(case 
    when gets < 1024 then to_char(gets) 
    when gets < 1024*1024 then round(gets/1024)||'K'
    when gets < 1024*1024*1024 then round(gets/1024/1024)||'M'
    when gets < 1024*1024*1024*1024 then round(gets/1024/1024/1024)||'G'
    else round(gets/1024/1024/1024/1024)||'T'
   end,'8',' ') buf_gets
  ,lpad(case 
    when s.gets/decode(s.execs,0,1,s.execs) < 1024 then to_char(round(s.gets/decode(s.execs,0,1,s.execs))) 
    when s.gets/decode(s.execs,0,1,s.execs) < 1024*1024 then round(s.gets/decode(s.execs,0,1,s.execs)/1024)||'K'
    when s.gets/decode(s.execs,0,1,s.execs) < 1024*1024*1024 then round(s.gets/decode(s.execs,0,1,s.execs)/1024/1024)||'M'
    when s.gets/decode(s.execs,0,1,s.execs) < 1024*1024*1024*1024 then round(s.gets/decode(s.execs,0,1,s.execs)/1024/1024/1024)||'G'
    else round(s.gets/decode(s.execs,0,1,s.execs)/1024/1024/1024/1024)||'T'
   end,'8',' ') gets_exe
  ,cast(numtodsinterval(ela_sec,'SECOND') as interval day(2) to second(0)) ela_time
  ,round(s.ela_sec/decode(s.execs,0,1,s.execs),4) AS ela_exec
  --,cpu_sec
  ,cast(numtodsinterval(cpu_sec,'SECOND') as interval day(2) to second(0)) cpu_time
  ,round(s.cpu_sec/decode(s.execs,0,1,s.execs),4) AS cpu_exec
  ,cast(numtodsinterval(io_sec,'SECOND') as interval day(2) to second(0)) io_time
  --,io_sec
  --,conc_sec
  ,cast(numtodsinterval(conc_sec,'SECOND') as interval day(1) to second(0)) cc_time
  --,app_sec  
  ,cast(numtodsinterval(app_sec,'SECOND') as interval day(1) to second(0)) ap_time
  --,phr_req
  /*
  ,lpad(case 
    when phr_req < 1024 then to_char(phr_req) 
    when phr_req < 1024*1024 then round(phr_req/1024)||'K'
    when phr_req < 1024*1024*1024 then round(phr_req/1024/1024)||'M'
    when phr_req < 1024*1024*1024*1024 then round(phr_req/1024/1024/1024,1)||'G'
    else round(phr_req/1024/1024/1024/1024,1)||'T'
   end,'8',' ') phr_req
  ,lpad(case 
    when phr_bytes < 1024 then to_char(phr_bytes) 
    when phr_bytes < 1024*1024 then round(phr_bytes/1024)||'K'
    when phr_bytes < 1024*1024*1024 then round(phr_bytes/1024/1024)||'M'
    when phr_bytes < 1024*1024*1024*1024 then round(phr_bytes/1024/1024/1024,1)||'G'
    else round(phr_bytes/1024/1024/1024/1024,1)||'T'
   end,'8',' ') phy_reads
  */
  ,lpad(case
    when disk_reads < 1024 then to_char(disk_reads)
    when disk_reads < 1024*1024 then round(disk_reads/1024)||'K'
    when disk_reads < 1024*1024*1024 then round(disk_reads/1024/1024)||'M'
    when disk_reads < 1024*1024*1024*1024 then round(disk_reads/1024/1024/1024,1)||'G'
    else round(disk_reads/1024/1024/1024/1024,1)||'T'
   end,'8',' ') disk_reads
  ,lpad(case
    when disk_bytes < 1024 then to_char(disk_bytes)||'K'
    when disk_bytes < 1024*1024 then round(disk_bytes/1024)||'M'
    when disk_bytes < 1024*1024*1024 then round(disk_bytes/1024/1024)||'G'
    when disk_bytes < 1024*1024*1024*1024 then round(disk_bytes/1024/1024/1024,1)||'T'
    else round(disk_bytes/1024/1024/1024/1024,1)||'E'
   end,'8',' ') disk_bytes
  ,rows_total
  ,round(s.rows_total/decode(s.execs,0,1,s.execs),1) AS rows_exec
  ,round(s.gets/decode(s.rows_total,0,1,s.rows_total),1) gets_row
from s;

prompt


undef sql_id
undef 1

col sql_text clear

set feedback 6
