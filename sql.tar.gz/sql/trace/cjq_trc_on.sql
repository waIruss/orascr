set echo on
alter system set events '27402 trace name context forever, level 255';
set echo off




