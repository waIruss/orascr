set line 230
set pagesize 100
set verify off


prompt ====================================================================
accept sql_id prompt 'Enter sql_id : '
accept child_num prompt 'Enter child_number : '
prompt ====================================================================



set serveroutput on size unlimited
alter session set max_dump_file_size=unlimited;
begin
   dbms_sqldiag.dump_trace(
      p_sql_id=>trim('&sql_id'),
      p_child_number=>&child_num,
      p_component=>'Optimizer',
      p_file_id=>'opttrace_&sql_id._&child_num'
   );

   dbms_output.put_line('Optimizer trace generated in background_dump_dest, look for file *opttrace_&sql_id._&child_num.*');
end;
/

