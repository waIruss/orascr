set line 230
set verify off


def SESSION_ID=&1

col ORAPID new_val ORAPID noprint


select p.pid ORAPID from v$session s,v$process p where s.paddr=p.addr and s.sid=&SESSION_ID;
set echo on
oradebug setorapid &ORAPID
oradebug unlimit
oradebug event 10046 trace name context forever,level 12
set echo off
prompt =============================================
prompt Trace enabled for sid &SESSION_ID
prompt =============================================
oradebug tracefile_name




