set linesize 200
col tablespace form A25 
col "USERNAME" form A15 
col "MB Used" form 999G999 
col "Maxsize MB" form 9G999G999 

SELECT
   su.tablespace,
   su.username,
   sum(su.blocks*dt.block_size)/1024/1024 "MB Used",
   dtf.maxbytes/1024/1024 "Maxsize MB"
FROM v$sort_usage su, dba_tablespaces dt,(select tablespace_name,sum(maxbytes) maxbytes from dba_temp_files dtf group by tablespace_name) dtf
WHERE dt.tablespace_name=dtf.tablespace_name
   AND dt.tablespace_name=su.tablespace
   AND dt.CONTENTS='TEMPORARY'
GROUP BY su.tablespace,su.username,dtf.maxbytes;

