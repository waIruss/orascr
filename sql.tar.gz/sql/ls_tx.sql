set linesize 220 pagesize 200
col last_activity form a16
col state form a8
col used_undo form a8
col sid_ser form a12
col wait_ev form a30
col module form A25
col username form a10
col mins form 9g999
col program form a25
col wait_time form 999g999
col tx_ela form A16

SELECT v.sid||','||v.serial# sid_ser
  , v.username
  , v.module
  , case when v.program like 'oracle%(J%' then (select job_name from dba_scheduler_running_jobs rj where rj.session_id=v.sid) else v.program end program
  , to_char(t.start_date,'YYYY-MM-DD HH24:MI:SS') tx_start
  , CASE
      WHEN v.status = 'INACTIVE' THEN To_Char(SYSDATE-(v.last_call_et*1/24/60/60),'YYYY-MM-DD hh24:mi')
      WHEN v.status = 'ACTIVE' THEN 'ACTIVE'
   END LAST_ACTIVITY
  , case when v.state='WAITING' then v.wait_class||': '||v.event
    when v.status='ACTIVE' then 'CPU' end wait_ev
  , v.seconds_in_wait AS sec_in_wait
  --, v.state,
  , Round(t.used_ublk*8/1024,2) undo_mb
  , cast(numtodsinterval((sysdate-t.start_date)*24*60,'MINUTE') as interval day(1) to second(0)) tx_ela
FROM v$session v, v$transaction t
--,v$session_wait vw
WHERE v.saddr = t.ses_addr
--AND v.sid = vw.sid
ORDER BY t.start_date desc;

