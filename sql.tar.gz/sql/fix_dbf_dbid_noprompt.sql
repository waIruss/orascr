set pagesize 100
set verify off
set line 250
set feedback off
whenever sqlerror exit

prompt =======================================
prompt  Current DBID
prompt =======================================
select dbid database_dbid from v$database;


col bad_cnt new_val bad_cnt noprint
select count(*) bad_cnt from x$kcvfh where fhdbi <> (select dbid from v$database);

begin
  if to_number('&bad_cnt') = 0 then
    raise_application_error(-20001,'All datafiles have correct DBID, nothing to do! Aborting!');
  end if;
end;
/

set feedback on
prompt =======================================
prompt  Datafiles with different DBID
prompt =======================================

col tablespace_name form A20
col file_name form A80
select fhtnm tablespace_name, hxfnm file_name, fhdbi dbid from x$kcvfh where fhdbi <> (select dbid from v$database);

set pagesize 0
set feedback off

prompt
spool switch_tbs_rw.sql
select distinct 'alter tablespace '||fhtnm||' read write;' from x$kcvfh where fhdbi <> (select dbid from v$database);
spool off
prompt
prompt Generated: switch_tbs_rw.sql
prompt

spool switch_tbs_ro.sql
select distinct 'alter tablespace '||fhtnm||' read only;' from x$kcvfh where fhdbi <> (select dbid from v$database);
spool off
prompt
prompt Generated: switch_tbs_ro.sql
set feedback on

spool switch_tbs.log

set echo on

@switch_tbs_rw.sql

@switch_tbs_ro.sql

spool off

set echo off

exit;

