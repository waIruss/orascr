set line 200 verify off
col source_db form A12
col name form A24
col value form A20
col computed_ form A24
col time_computed form A24
col seconds_ago form 99G999

select 
   source_db_unique_name source_db,
   name, 
   value,
   datum_time as computed_,
   (sysdate-to_date(datum_time,'MM/DD/YYYY HH24:MI:SS'))*24*60*60 as seconds_ago
from v$dataguard_stats;
