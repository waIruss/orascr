
def sql_id=&1
def child_num=&2

break on id skip 0 on operation skip 0 on object_name skip 0 on access_predicates skip 0 on filter_predicates skip 0
col id form 999
col pct form 999D00
col pct_event form A30 trunc
set line 250 pagesize 500 verify off
col operation form A50
col object_name form A30
col access_predicates form A50 wor
col filter_predicates form A50 wor
col event form A20 trunc
set colsep "|"

with ash as (
select
  sql_id,
  sql_child_number,
  sql_plan_hash_value,
  nvl(sql_plan_line_id,1) sql_plan_line_id,
  sql_plan_operation,
  sql_plan_options,
  decode(session_state,'WAITING',event,session_state) event,
  count(*) cnt
from v$active_session_history
where sql_id=lower(trim('&sql_id'))
  and sql_child_number=&child_num
group by
sql_id,
  sql_child_number,
  sql_plan_hash_value,
  nvl(sql_plan_line_id,1),
  sql_plan_operation,
  sql_plan_options,
  decode(session_state,'WAITING',event,session_state)
),a2 as (
select
  --round(ratio_to_report(cnt) over()*100,2) pct
  id
  --, parent_id, depth, position, search_columns
  ,lpad(' ',depth,' ')||operation ||' '|| options as operation
  , object_name
  , access_predicates
  , filter_predicates
  , round(ratio_to_report(cnt) over()*100,2) pct
  , event
  --,cnt
from v$sql_plan sp left outer join ash
 on (sp.sql_id=ash.sql_id  and sp.child_number=ash.sql_child_number and sp.id=ash.sql_plan_line_id)
where sp.sql_id=lower(trim('&sql_id'))
  and sp.child_number=&child_num
order by id
)
select id, operation, object_name, access_predicates, filter_predicates
   ,listagg(pct||' - '||event,chr(10)) within group (order by pct desc) pct_event
from a2
group by id, operation, object_name, access_predicates, filter_predicates
order by id;

set colsep " "
clear breaks

undef sql_id child_num 1 2
