
set verify off  feedback off termout off

set line 200 pagesize 1000
col message_text FORM A140
col time form A18

-- optional params
col par1 new_val 1 noprint

select 'dummy' par1 from dual where 1 <> 1;
col nHours new_val nHours noprint
select case when '&1' is not null then '&1' else '1' end nHours from dual;

set feedback 6 termout on

PROMPT ==========================================================================
PROMPT Last &nHours hour(s) of alert.log
PROMPT ==========================================================================
select 
  to_char(originating_timestamp,'MM/DD/YY HH24:MI:SS') time
  ,message_text
from v$diag_alert_ext
where originating_timestamp > systimestamp - interval '&nHours' hour
  and component_id like 'rdbms%';
  


undef nHours 1