

set line 200 pagesize 100
col audit_trail form A25
col parameter_name form A30
col parameter_value form A20
break on audit_trail skip 1

prompt ==========================================================
prompt AUDIT MANAGEMENT SETTINGS
prompt ==========================================================

select 
   audit_trail
   ,parameter_name
   ,parameter_value 
from dba_audit_mgmt_config_params
order by audit_trail,parameter_name;

clear breaks

col job_name form A30
col job_status form A10
col job_frequency form A40
col use_last_archive_timestamp form A15 heading "Use last arch|timestamp"


prompt ==========================================================
prompt AUDIT CLEANUP JOBS
prompt ==========================================================
select 
   audit_trail
   ,job_name
   ,job_status
   ,job_frequency
   ,use_last_archive_timestamp
from dba_audit_mgmt_cleanup_jobs
order by audit_trail;

col job_name form A30
col job_action form A70 wor
col repeat_interval form A30
col state form A10
col next_run_date form A16
select job_name,job_action,state,repeat_interval,to_char(next_run_date,'YYYY-MM-DD HH24:MI') next_run_date 
from user_scheduler_jobs where job_name='DXC_AUDIT_TRAIL_CLEANUP';




prompt
prompt ==========================================================
prompt SIZE OF: SYS.AUD$ and SYS.FGA_LOG$
prompt ==========================================================
col owner form A10
col segment_name form A30
col tablespace_name form A40
col size_mb form 999G999G999
select 
   owner
   ,segment_name
   ,round(bytes/1024/1024) size_mb
   ,tablespace_name||' - '||decode(tablespace_name,'SYSTEM','Will be moved to SYSAUX!!!','SYSAUX','No need to move') tablespace_name
from dba_segments
where owner = 'SYS'
and segment_name in ('AUD$','FGA_LOG$');

prompt
prompt ==========================================================
prompt Script will initialize Audit Cleanup infrastructure
prompt Do you want to proceed?
prompt ==========================================================
pause  Press ENTER to continue or ^C to canel...


prompt 

var stime number
var etime number

begin
  :stime := dbms_utility.get_time();
end;
/

set serveroutput on 
whenever sqlerror exit

-- manual extension for SYSAUX tbs to prevent error:
-- ORA-46267: Insufficient space in 'SYSAUX' tablespace, cannot complete operation
-- ORA-06512: at "AUDSYS.DBMS_AUDIT_MGMT", line 2652
-- most likely due to Avq requierd param: _enable_space_preallocation=0

declare
  v_aud_size number;
  v_tbs_size number;
  v_tbs_free number;
  v_tbs_max  number;
  v_dbf_cnt  number;
  v_file_id  number;
  v_free_buf number := 1024;
  v_sql varchar2(4000);
begin
for t in (select table_name from dba_tables where owner ='SYS' and table_name in('AUD$','FGA_LOG$') and tablespace_name='SYSTEM') 
  loop
    select 
      (select sum(round(ds.bytes/1024/1024)) mb from dba_segments ds, dba_tables dt where dt.owner = 'SYS' and dt.table_name=t.table_name and dt.table_name=ds.segment_name and dt.owner=ds.owner)
      +(select sum(round(ds.bytes/1024/1024)) mb from dba_segments ds, dba_indexes di where di.owner = 'SYS' and di.table_name=t.table_name and di.index_name=ds.segment_name and di.owner=ds.owner) 
      +(select sum(round(ds.bytes/1024/1024)) mb from dba_segments ds, dba_lobs dl where dl.owner = 'SYS' and dl.table_name=t.table_name and dl.segment_name=ds.segment_name and dl.owner=ds.owner)
      into v_aud_size
    from dual;

    select
      count(file_id) 
      ,max(file_id)
      ,sum(round(dbf.bytes/1024/1024)) size_mb 
      ,sum(round(nvl(fbytes,0)/1024/1024)) free_mb
      ,sum(round(decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)/1024/1024)) max_mb
      into v_dbf_cnt,v_file_id,v_tbs_size,v_tbs_free,v_tbs_max  
    from dba_data_files dbf 
      join dba_tablespaces t using(tablespace_name)
      left outer join (
        select file_id,sum(bytes) fbytes from dba_free_space where tablespace_name=upper('SYSAUX')  group by file_id
      ) free_spc using(file_id)
    where tablespace_name = upper('SYSAUX');

    Dbms_Output.Put_Line('Need '||to_char( v_aud_size+v_free_buf)||'MB of free space in SYSAUX');
    if v_aud_size+v_free_buf > v_tbs_free then
      if v_tbs_size+v_aud_size+v_free_buf > v_tbs_max then
        raise_application_error(-20001,'Insufficient space in SYSAUX tablespace - please add another datafile');
      elsif v_dbf_cnt > 1 then
        raise_application_error(-20001,'Multiple datafiles detected - please extend manually');
      else
        v_sql := 'alter database datafile '||v_file_id||' resize '||to_char(v_tbs_size+v_aud_size+v_free_buf)||'M';
        Dbms_Output.Put_Line(v_sql);
        execute immediate v_sql;
      end if;
    else
      Dbms_Output.Put_Line('SYSAUX tablespace has enough free space');
    end if;
  end loop;
end;
/




BEGIN
   FOR j IN (select audit_trail, job_name from dba_audit_mgmt_cleanup_jobs order by audit_trail) 
      LOOP
         DBMS_AUDIT_MGMT.DROP_PURGE_JOB(j.job_name);
         dbms_output.put_line('Dropped automatic purge job: '||j.job_name);   
      END LOOP;   
END;
/


set serveroutput on size unlimited
set feedback off
begin 
   dbms_output.put_line('--------------------------------------------------------------------------------------------');   
end;
/


BEGIN
   IF NOT
      DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_AUD_STD) --SYS.AUD$
      --DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_DB_STD)  --SYS.AUD$ + SYS.FGA_LOG$
      --DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_FGA_STD) --SYS.FGA_LOG$
      --DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED) --UNIFIED   
   THEN
      DBMS_AUDIT_MGMT.INIT_CLEANUP(
         audit_trail_type          => DBMS_AUDIT_MGMT.AUDIT_TRAIL_AUD_STD,
         default_cleanup_interval  => 24 
      );
      dbms_output.put_line('AUDIT_TRAIL_AUD_STD - initialized - OK');
   ELSE
      dbms_output.put_line('AUDIT_TRAIL_AUD_STD - already initialized - skipping');
  END IF;
END;
/

BEGIN
   IF NOT
      DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_FGA_STD) --SYS.AUD$
      --DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_DB_STD)  --SYS.AUD$ + SYS.FGA_LOG$
      --DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_FGA_STD) --SYS.FGA_LOG$
      --DBMS_AUDIT_MGMT.IS_CLEANUP_INITIALIZED(DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED) --UNIFIED   
   THEN
      DBMS_AUDIT_MGMT.INIT_CLEANUP(
         audit_trail_type          => DBMS_AUDIT_MGMT.AUDIT_TRAIL_FGA_STD,
         default_cleanup_interval  => 24 
      );
      dbms_output.put_line('AUDIT_TRAIL_FGA_STD - initialized - OK');
   ELSE
      dbms_output.put_line('AUDIT_TRAIL_FGA_STD - already initialized - skipping');
  END IF;
END;
/



prompt

declare
v_sql varchar2(2000) :=
'begin
  dbms_audit_mgmt.set_last_archive_timestamp(
    audit_trail_type   => DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED,
    last_archive_time  => sysdate-30,
    container          => DBMS_AUDIT_MGMT.CONTAINER_CURRENT
  );
  dbms_audit_mgmt.set_last_archive_timestamp(
    audit_trail_type   => DBMS_AUDIT_MGMT.AUDIT_TRAIL_AUD_STD,
    last_archive_time  => sysdate-30,
    container          => DBMS_AUDIT_MGMT.CONTAINER_CURRENT
  );
  dbms_audit_mgmt.set_last_archive_timestamp(
    audit_trail_type   => DBMS_AUDIT_MGMT.AUDIT_TRAIL_FGA_STD,
    last_archive_time  => sysdate-30,
    container          => DBMS_AUDIT_MGMT.CONTAINER_CURRENT
  );
  dbms_audit_mgmt.clean_audit_trail(
    audit_trail_type   => DBMS_AUDIT_MGMT.AUDIT_TRAIL_UNIFIED,
    use_last_arch_timestamp => true,
    container          => DBMS_AUDIT_MGMT.CONTAINER_CURRENT
  );
  dbms_audit_mgmt.clean_audit_trail(
    audit_trail_type   => DBMS_AUDIT_MGMT.AUDIT_TRAIL_AUD_STD,
    use_last_arch_timestamp => true,
    container          => DBMS_AUDIT_MGMT.CONTAINER_CURRENT
  );
  dbms_audit_mgmt.clean_audit_trail(
    audit_trail_type   => DBMS_AUDIT_MGMT.AUDIT_TRAIL_FGA_STD,
    use_last_arch_timestamp => true,
    container          => DBMS_AUDIT_MGMT.CONTAINER_CURRENT
  );
end;';
   v_job_exists pls_integer;
begin   
   select count(*) 
      into v_job_exists
   from user_scheduler_jobs 
   where job_name='AUD_TRAIL_MOVE_LAST_ARCH_STAMP';
   
   if v_job_exists > 0 then 
      dbms_scheduler.drop_job('AUD_TRAIL_MOVE_LAST_ARCH_STAMP');
   end if;

   select count(*) 
      into v_job_exists
   from user_scheduler_jobs 
   where job_name='DXC_AUDIT_TRAIL_CLEANUP';
   
   if v_job_exists = 0 then 
      dbms_scheduler.create_job(
         job_name => 'DXC_AUDIT_TRAIL_CLEANUP',
         job_type => 'PLSQL_BLOCK',
         job_action => v_sql,
         repeat_interval => 'FREQ=DAILY;BYHOUR=5;BYMINUTE=0',
         start_date => sysdate,
         enabled => true);
      dbms_output.put_line('Job DXC_AUDIT_TRAIL_CLEANUP created');
      dbms_output.put_line('Will run daily at 5:00am - audit records older than 30 days will be removed');
   else
      dbms_scheduler.drop_job('DXC_AUDIT_TRAIL_CLEANUP');
      dbms_output.put_line('Job DXC_AUDIT_TRAIL_CLEANUP dropped');
      dbms_scheduler.create_job(
         job_name => 'DXC_AUDIT_TRAIL_CLEANUP',
         job_type => 'PLSQL_BLOCK',
         job_action => v_sql,
         repeat_interval => 'FREQ=DAILY;BYHOUR=5;BYMINUTE=0',
         start_date => sysdate,
         enabled => true);     
      dbms_output.put_line('Job DXC_AUDIT_TRAIL_CLEANUP created');
      dbms_output.put_line('Will run daily at 5:00am - audit records older than 30 days will be removed');
   end if;
end;
/

begin
  :etime := dbms_utility.get_time();
end;
/


col "Elapsed time" form A15
select cast(numtodsinterval((:etime-:stime)/100,'SECOND') as interval day(0) to second(0)) as "Elapsed time" from dual;


prompt


