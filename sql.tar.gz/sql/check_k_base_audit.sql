set echo off feedback off termout off pagesize 10000 linesize 250 trimspool on verify off
whenever sqlerror exit 2
whenever oserror exit 3

-- optional params
col par2 new_val 2 noprint

select 'dummy' par2 from dual where 1 <> 1;
col nHours new_val N_LAST_HOUR noprint
col nMins new_val N_LAST_MIN noprint
select case when '&2' is not null then '&2' else '1' end nMins from dual;

set long 8000
set markup html on
spool &&1

select
  to_char(event_timestamp,'YYYY-MM-DD HH24:MI:SS') event_timestamp
  ,os_username
  ,userhost
  ,terminal
  ,dbusername as dbuser
  ,dbproxy_username as proxy_user
  ,client_program_name client_program
  ,object_schema
  ,object_name
  ,action_name
  ,return_code
  ,application_contexts
  ,sql_text
  ,sql_binds
  ,(select job_name from dba_scheduler_job_run_details jrd where aud.event_timestamp between jrd.actual_start_date and jrd.log_date and aud.os_process = jrd.slave_pid) job_name
  ,(select 'SID,SERIAL#:'||s.sid||','||s.serial#||', logon_time: '||to_char(s.logon_time,'YYYY-MM-DD HH24:MI')||', OSPID:'||p.spid||', PORT:'||s.port from v$session s,v$process p where p.addr=s.paddr and p.spid=aud.os_process) additional_info
from unified_audit_trail aud
where object_name='BASE'
  and object_schema='K'
  and action_name = 'UPDATE'
  and event_timestamp > sysdate - interval '&&N_LAST_MIN' minute
  and to_number(to_char(event_timestamp,'HH24MI')) not between 1800 and 2200
  and upper(sql_text) like '%TODAY%'
order by event_timestamp
;

spool off
exit;

