
col action form A15 
col namespace form A10 
col version form A25
col bundle_series form A8
col comments form A60 
set line 200 pagesize 200

select 
   to_char(ACTION_TIME,'DD-MM-YYYY HH24:MI') action_time_ ,
   action,
   namespace,
   version,
   bundle_series,
   comments  
from dba_registry_history 
order by action_time nulls first; 
