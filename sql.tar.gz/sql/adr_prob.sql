
col firstinc_time form a16
col lastinc_time form a16
col problem_key form a60
set line 200 pagesize 100

PROMPT ==========================================================================
PROMPT Diagnostic problems registerd in ADR
PROMPT ==========================================================================
select 
  problem_key
  ,to_char(firstinc_time,'YYYY-MM-DD HH24:MI') firstinc_time
  ,to_char(lastinc_time,'YYYY-MM-DD HH24:MI') lastinc_time
  ,(select count(*) from v$diag_incident di where di.problem_id  = v$diag_problem.problem_id) count   
from v$diag_problem
order by lastinc_time desc;


