set line 200 pagesize 200
col parameter form a30 
col oper_type form a12 
col oper_mode form a10 
col init form 9g999g999 
col target form 9g999g999 
col status form a10 
col start_time fomr a15 
col ela_sec form 999g999 

SELECT 
   parameter,
   oper_type,
   oper_mode, 
   Round(initial_size/1024/1024) init, 
   Round(target_size/1024/1024) target, 
   status,
   To_Char(start_time,'Dy DD/MM HH24:MI') start_time, 
   round((end_time-start_time)*24*60*60) ela_sec 
FROM v$sga_resize_ops 
ORDER BY start_time,parameter;



