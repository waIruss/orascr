set line 200 pagesize 200 verify off

def grantee=&1

col privilege form A30
col admin_option form A10 heading "With |admin opt"

PROMPT ==========================================================================
PROMPT System privileges for &grantee
PROMPT ==========================================================================
select privilege,admin_option 
from dba_sys_privs 
where grantee=upper('&grantee')
order by privilege;

col granted_role form A30
PROMPT ==========================================================================
PROMPT Granted roles for &grantee
PROMPT ==========================================================================
select granted_role,admin_option 
from dba_role_privs 
where grantee=upper('&grantee')
order by granted_role;

col obj_type form A12
col obj_name form A40
col privilege form A10
col grantor form A12
col grantable form A10 heading "With |grant option"
PROMPT ==========================================================================
PROMPT Object privileges for &grantee
PROMPT ==========================================================================
select 
   privilege,
   type obj_type,
   owner||'.'||table_name obj_name,
   grantor,
   grantable 
from dba_tab_privs
where grantee=upper('&grantee')
order by owner,table_name;

PROMPT ==========================================================================
PROMPT SYS roles for &grantee
PROMPT ==========================================================================

col is_granted form A10
with p as (
select username,sysdba,sysoper,sysasm,sysbackup,sysdg,syskm from v$pwfile_users
)
,p2 as (
select * from p
unpivot
(is_granted
  for granted_role in (sysdba,sysoper,sysasm,sysbackup,sysdg,syskm)
))
select granted_role,is_granted from p2 where username=upper('&grantee') and is_granted='TRUE';

col proxy form A30
col client form A30
PROMPT ==========================================================================
PROMPT PROXY connections for &grantee
PROMPT ==========================================================================

select proxy,client from proxy_users where proxy=upper('&grantee');

undef grantee 1
