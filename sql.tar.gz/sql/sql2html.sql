set verify off
set trimspool on
def queryfile="&1"
def outfile="&2"
set markup HTML ON HEAD " -
<style type='text/css'> -
        table {font-family: Helvetica,verdana,arial,sans-serif; text-align:auto; width:95%; align:left; border-collapse: collapse; border-width: 1px; border-color: #4C4C4C;border-collapse: collapse; margin-left:10px; font-size:12px;} -
        th {border-width: 2px; border-color:#4C4C4C; color:#FFFFFF; background-color:#365B8E; padding: 4px; border-style: solid;} -
        td {border-width: 1px; border-style:solid; border-color:#4C4C4C;} -
        tr:nth-child(even) {background-color: #eaeaea} -
        tr:hover {transition: background-color 150ms ease-out;background-color: #d5d5d5 } -
</style> -
<title>SQL*Plus Report</title>" -
TABLE "ALIGN='TOP'" -
BODY "" -
SPOOL ON ENTMAP OFF PREFORMAT OFF

spool &outfile
@&queryfile
spool off


