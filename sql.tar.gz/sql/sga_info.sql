set line 200 pagesize 200
compute  sum of curr_size_mb on report 
break on report 
column component form A30 
col curr_size_mb form 9G999G990
col min_size_mb form 9G999G990
col user_spec_size_mb form 9G999G990

SELECT 
   component,current_size/1024/1024 curr_size_mb,
   min_size/1024/1024 AS min_size_mb, 
   user_specified_size/1024/1024 AS user_spec_size_mb  
FROM v$sga_dynamic_components 
WHERE current_size <> 0; 

clear breaks 
clear computes
