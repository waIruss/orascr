SET PAGES 0
SET HEADING OFF
SET FEEDBACK OFF
SET SERVEROUTPUT ON
SET LINESIZE 200
SET TRIMSPOOL ON
SET ECHO OFF
SET TERMOUT OFF

COLUMN spool_name NEW_VALUE spool_name NOPRINT
COLUMN db_name NEW_VALUE db_name NOPRINT
COLUMN host_name NEW_VALUE host_name NOPRINT
COLUMN curdate NEW_VALUE curdate NOPRINT

SELECT instance_name || '_' || host_name || '_' || SYSDATE     spool_name
  FROM v$instance;

SELECT SYSTIMESTAMP curdate FROM DUAL;

SELECT name db_name FROM v$database;

SELECT host_name FROM v$instance;

SPOOL &spool_name

PROMPT ************************************************
PROMPT Extract for Oracle DB compliance check
PROMPT ************************************************

PROMPT DB name: &db_name
PROMPT Hostname: &host_name
PROMPT Date: &curdate
PROMPT ************************************************


DECLARE
    num_total_rows   NUMBER := 0;

    CURSOR c_SAP0595 IS
        SELECT a.username
          FROM dba_users_with_defpwd a, dba_users b
         WHERE a.username = b.username AND b.account_status = 'OPEN';

    CURSOR c_SAP0568 IS
        SELECT 'DBA role: ' || grantee     username
          FROM dba_role_privs
         WHERE granted_role = 'DBA'
        UNION
        SELECT 'SYSDBA from PWFILE: ' || username
          FROM v$pwfile_users
         WHERE sysdba = 'TRUE' AND account_status = 'OPEN';


    CURSOR c_SAP0587 IS
        SELECT username
          FROM dba_users
         WHERE profile = 'DEFAULT' AND account_status = 'OPEN';

    CURSOR c_SAP0587a IS
        SELECT profile, resource_name, LIMIT
          FROM dba_profiles
         WHERE     resource_name IN ('FAILED_LOGIN_ATTEMPTS')
               AND TO_NUMBER (
                       CASE LIMIT
                           WHEN 'UNLIMITED' THEN 1000
                           WHEN 'DEFAULT' THEN 1000
                           ELSE TO_NUMBER (LIMIT)
                       END) >
                   6;

    CURSOR c_SAP0587b IS
        SELECT profile, resource_name, LIMIT
          FROM dba_profiles
         WHERE     resource_name IN ('IDLE_TIME')
               AND TO_NUMBER (
                       CASE LIMIT
                           WHEN 'UNLIMITED' THEN 1000
                           WHEN 'DEFAULT' THEN 1000
                           ELSE TO_NUMBER (LIMIT)
                       END) >
                   30;

    CURSOR c_SAP0587c IS
        SELECT profile, resource_name, LIMIT
          FROM dba_profiles
         WHERE     resource_name IN ('PASSWORD_LIFE_TIME')
               AND TO_NUMBER (
                       CASE LIMIT
                           WHEN 'UNLIMITED' THEN 1000
                           WHEN 'DEFAULT' THEN 1000
                           ELSE TO_NUMBER (LIMIT)
                       END) >
                   90;

    CURSOR c_SAP0587d IS
        SELECT profile, resource_name, LIMIT
          FROM dba_profiles
         WHERE     resource_name IN ('PASSWORD_REUSE_MAX')
               AND TO_NUMBER (
                       CASE LIMIT
                           WHEN 'UNLIMITED' THEN 1000
                           WHEN 'DEFAULT' THEN 1000
                           ELSE TO_NUMBER (LIMIT)
                       END) >
                   6;


    CURSOR c_SAP0587e IS
        SELECT profile, resource_name, LIMIT
          FROM dba_profiles
         WHERE     resource_name IN ('PASSWORD_REUSE_TIME')
               AND TO_NUMBER (
                       CASE LIMIT
                           WHEN 'UNLIMITED' THEN 1000
                           WHEN 'DEFAULT' THEN 1000
                           ELSE TO_NUMBER (LIMIT)
                       END) <>
                   365;

    CURSOR c_SAP0587f IS
        SELECT profile, resource_name, LIMIT
          FROM dba_profiles
         WHERE     resource_name IN ('PASSWORD_VERIFY_FUNCTION')
               AND LIMIT IN ('DEFAULT', 'NULL');
BEGIN
    DBMS_OUTPUT.put_line (CHR (10));
    DBMS_OUTPUT.put_line ('Running pre-checks:');
    DBMS_OUTPUT.put_line ('================================');
    DBMS_OUTPUT.put_line ('Req: SAP0595');
    DBMS_OUTPUT.put_line ('================================');

    DBMS_OUTPUT.put_line (
        'Checking for open accounts with default password...' || CHR (10));

    FOR r_rec IN c_SAP0595
    LOOP
        DBMS_OUTPUT.put_line (r_rec.username);
        num_total_rows := c_SAP0595%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line (
            CHR (10) || 'Compliant - no open accounts with default password.');
    ELSE
        DBMS_OUTPUT.put_line (
               CHR (10)
            || 'No compliant - please change password or lock/expire accounts!');
    END IF;

    ---
    num_total_rows := 0;

    DBMS_OUTPUT.put_line (CHR (10) || '================================');
    DBMS_OUTPUT.put_line ('Req: SAP0568');
    DBMS_OUTPUT.put_line ('================================');

    DBMS_OUTPUT.put_line (
        'Checking for user accounts with DBA/SYSDBA role...' || CHR (10));

    FOR r_rec IN c_SAP0568
    LOOP
        DBMS_OUTPUT.put_line (r_rec.username);
        num_total_rows := c_SAP0568%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line ('No user accounts with DBA role.');
    ELSE
        DBMS_OUTPUT.put_line (
               CHR (10)
            || 'Please verify if these are only Administrator accounts! - usually SYS, SYSTEM, RMAN or named DBAs. There should be no application accounts with DBA role.');
    END IF;

    ---
    num_total_rows := 0;

    DBMS_OUTPUT.put_line (CHR (10) || '================================');
    DBMS_OUTPUT.put_line ('Req: SAP0587,  SAP0591,  SAP0586');
    DBMS_OUTPUT.put_line ('================================');

    DBMS_OUTPUT.put_line (
           'Checking for OPEN accounts with DEFAULT profile assigned...'
        || CHR (10));

    FOR r_rec IN c_SAP0587
    LOOP
        DBMS_OUTPUT.put_line (r_rec.username);
        num_total_rows := c_SAP0587%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line (
            'Compliant: no OPEN accounts with default profile');
    ELSE
        DBMS_OUTPUT.put_line (
               CHR (10)
            || 'Please verify! There should be no OPEN accounts with this profile.');
    END IF;

    ---
    DBMS_OUTPUT.put_line (CHR (10) || 'Checking profiles...' || CHR (10));

    DBMS_OUTPUT.put_line (
           CHR (10)
        || 'Profiles actively used on a database (with at least one OPEN account):');

    FOR rec
        IN (SELECT DISTINCT profile
              FROM dba_profiles a
             WHERE EXISTS
                       (SELECT DISTINCT profile
                          FROM dba_users b
                         WHERE     a.profile = b.profile
                               AND b.account_status = 'OPEN'))
    LOOP
        DBMS_OUTPUT.put_line (rec.profile);
    END LOOP;


    ---
    num_total_rows := 0;
    DBMS_OUTPUT.put_line (
           CHR (10)
        || 'FAILED_LOGIN_ATTEMPTS should be =< 6. Possible violations:'
        || CHR (10));

    FOR r_rec IN c_SAP0587a
    LOOP
        DBMS_OUTPUT.put_line (
               RPAD (r_rec.profile, 20)
            || CHR (9)
            || RPAD (r_rec.resource_name, 20)
            || CHR (9)
            || RPAD (r_rec.LIMIT, 20));
        num_total_rows := c_SAP0587a%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line ('No profiles with violations found.');
    END IF;

    ---
    num_total_rows := 0;
    DBMS_OUTPUT.put_line (
           CHR (10)
        || 'IDLE_TIME should be =< 30 with exclusion of service profiles. Possible violations:'
        || CHR (10));

    FOR r_rec IN c_SAP0587b
    LOOP
        DBMS_OUTPUT.put_line (
               RPAD (r_rec.profile, 20)
            || CHR (9)
            || RPAD (r_rec.resource_name, 20)
            || CHR (9)
            || RPAD (r_rec.LIMIT, 20));
        num_total_rows := c_SAP0587b%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line ('No profiles with violations found.');
    END IF;

    ---
    num_total_rows := 0;
    DBMS_OUTPUT.put_line (
           CHR (10)
        || 'PASSWORD_LIFE_TIME should be =< 90 with exclusion of service profiles. Possible violations:'
        || CHR (10));

    FOR r_rec IN c_SAP0587c
    LOOP
        DBMS_OUTPUT.put_line (
               RPAD (r_rec.profile, 20)
            || CHR (9)
            || RPAD (r_rec.resource_name, 20)
            || CHR (9)
            || RPAD (r_rec.LIMIT, 20));
        num_total_rows := c_SAP0587c%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line ('No profiles with violations found.');
    END IF;

    ---
    num_total_rows := 0;
    DBMS_OUTPUT.put_line (
           CHR (10)
        || 'PASSWORD_REUSE_MAX should be =< 6. Possible violations:'
        || CHR (10));

    FOR r_rec IN c_SAP0587d
    LOOP
        DBMS_OUTPUT.put_line (
               RPAD (r_rec.profile, 20)
            || CHR (9)
            || RPAD (r_rec.resource_name, 20)
            || CHR (9)
            || RPAD (r_rec.LIMIT, 20));
        num_total_rows := c_SAP0587d%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line ('No profiles with violations found.');
    END IF;

    ---
    num_total_rows := 0;
    DBMS_OUTPUT.put_line (
           CHR (10)
        || 'PASSWORD_REUSE_TIME should be set to 365 days (soft requirement - works in conjuction with PASSWORD_REUSE_MAX). Possible violations:'
        || CHR (10));

    FOR r_rec IN c_SAP0587e
    LOOP
        DBMS_OUTPUT.put_line (
               RPAD (r_rec.profile, 20)
            || CHR (9)
            || RPAD (r_rec.resource_name, 20)
            || CHR (9)
            || RPAD (r_rec.LIMIT, 20));
        num_total_rows := c_SAP0587e%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line ('No profiles with violations found.');
    END IF;

    ---
    num_total_rows := 0;
    DBMS_OUTPUT.put_line (
           CHR (10)
        || 'PASSWORD_VERIFY_FUNCTION should be not null/default. Possible violations:'
        || CHR (10));

    FOR r_rec IN c_SAP0587f
    LOOP
        DBMS_OUTPUT.put_line (
               RPAD (r_rec.profile, 20)
            || CHR (9)
            || RPAD (r_rec.resource_name, 20)
            || CHR (9)
            || RPAD (r_rec.LIMIT, 20));
        num_total_rows := c_SAP0587f%ROWCOUNT;
    END LOOP;

    IF num_total_rows < 1
    THEN
        DBMS_OUTPUT.put_line ('No profiles with violations found.');
    END IF;
END;
/

PROMPT
PROMPT ************************************************
PROMPT Pure extracts
PROMPT ************************************************

SET PAGESIZE 1000
SET HEAD ON
SET WRAP OFF
COL username FORMAT a40
COL account_status FORMAT a20
COL profile FORMAT a30
COL created FORMAT a20
COL last_login FORMAT a20
COL resource_name FORMAT a30
COL limit FORMAT a20
COL grantee FORMAT a40
COL granted_role FORMAT a30
COL admin_option FORMAT a10
COL privilege FORMAT a40

TTITLE LEFT 'Extract from DBA_USERS' SKIP 1                                  -
                                            LEFT = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = SKIP 2
--BREAK ON profile

  SELECT profile,
         username,
         account_status,
         created,
         last_login
    FROM dba_users
ORDER BY 1, 3;


TTITLE LEFT 'Extract from DBA_PROFILES' SKIP 1                               -
                                               LEFT = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = SKIP 2

  SELECT profile, resource_name, LIMIT
    FROM dba_profiles
ORDER BY 1, 2;

TTITLE LEFT 'Extract from DBA_ROLE_PRIVS' SKIP 1                             -
                                                 LEFT = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = SKIP 2

  SELECT grantee, granted_role, admin_option
    FROM dba_role_privs
ORDER BY 2, 1;

TTITLE LEFT 'Extract from DBA_SYS_PRIVS' SKIP 1                              -
                                                LEFT = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = SKIP 2

  SELECT grantee, privilege, admin_option
    FROM dba_sys_privs
ORDER BY 1, 2;

DECLARE
    v_tmp   CLOB;
BEGIN
    DBMS_OUTPUT.put_line (CHR (10) || '===========================');
    DBMS_OUTPUT.put_line ('Extract of password verify functions:');

    FOR rec
        IN (SELECT DISTINCT LIMIT
              FROM dba_profiles
             WHERE     resource_name = 'PASSWORD_VERIFY_FUNCTION'
                   AND LIMIT NOT IN ('DEFAULT', 'NULL'))
    LOOP
        v_tmp := DBMS_METADATA.get_ddl ('FUNCTION', rec.LIMIT, 'SYS');
        DBMS_OUTPUT.put_line (v_tmp);
    END LOOP;
END;
/

EXIT;
