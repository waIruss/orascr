set verify off
set line 240
set pagesize 100
col snap_time form A14
col enqueued_msgs form 999G990 heading "Enqueued|messages"
col dequeued_msgs form 999G990 heading "Dequeued|messages"
col ENQ_MSG_PER_SEC form 99G990D0 heading "Enq. msg.|per sec."
col DEQ_MSG_PER_SEC form 99G990D0 heading "Deq. msg.|per sec."
col enq_time form A12 heading "Enqueue|time"
col deq_time form A12 heading "Dequeue|time"
col enq_cpu_time form A12 heading "Enqueue|CPU time"
col deq_cpu_time form A12 heading "Dequeue|CPU time"
col ENQ_ELA_PER_MSG form 9G990D00 heading "Enq. time|per msg. (ms)"
col DEQ_ELA_PER_MSG form 9G990D00 heading "Deq. time|per msg. (ms)"
col ENQ_CPU_PER_MSG form 9G990D00 heading "Enq. CPU time|per msg. (ms)"
col DEQ_CPU_PER_MSG form 9G990D00 heading "Deq. CPU time|per msg. (ms)"


def qowner=&1
def qname=&2
def n_last_days=&3

with q1 as (
select s.end_interval_time
, queue_schema, queue_name, queue_id, first_activity_time
,(cast(end_interval_time as date)-cast(lag(end_interval_time) over(order by s.end_interval_time) as date))*24*60*60 snap_ela_sec
--, enqueued_msgs, dequeued_msgs
, case when enqueued_msgs-lag(enqueued_msgs) over(order by q.snap_id) >= 0 or lag(enqueued_msgs) over(order by q.snap_id) is null then
    enqueued_msgs-lag(enqueued_msgs) over(order by q.snap_id)
  else
    enqueued_msgs
  end enqueued_msgs
  ,lag(enqueued_msgs) over(order by q.snap_id)
, case when dequeued_msgs-lag(dequeued_msgs) over(order by q.snap_id) >= 0 or lag(dequeued_msgs) over(order by q.snap_id) is null then
    dequeued_msgs-lag(dequeued_msgs) over(order by q.snap_id)
  else
    dequeued_msgs
  end dequeued_msgs
--, browsed_msgs
, case when elapsed_enqueue_time-lag(elapsed_enqueue_time) over(order by q.snap_id) >= 0 or lag(elapsed_enqueue_time) over(order by q.snap_id) is null then
    elapsed_enqueue_time-lag(elapsed_enqueue_time) over(order by q.snap_id)
  else
    elapsed_enqueue_time
  end elapsed_enqueue_time
, case when elapsed_dequeue_time-lag(elapsed_dequeue_time) over(order by q.snap_id) >= 0 or lag(elapsed_dequeue_time) over(order by q.snap_id) is null  then
    elapsed_dequeue_time-lag(elapsed_dequeue_time) over(order by q.snap_id)
  else
    elapsed_dequeue_time
  end elapsed_dequeue_time
, case when enqueue_cpu_time-lag(enqueue_cpu_time) over(order by q.snap_id) >= 0 or lag(enqueue_cpu_time) over(order by q.snap_id) is null then
    enqueue_cpu_time-lag(enqueue_cpu_time) over(order by q.snap_id)
  else
    enqueue_cpu_time
  end enqueue_cpu_time
, case when dequeue_cpu_time-lag(dequeue_cpu_time) over(order by q.snap_id) >= 0 or lag(dequeue_cpu_time) over(order by q.snap_id) is null  then
    dequeue_cpu_time-lag(dequeue_cpu_time) over(order by q.snap_id)
  else
    dequeue_cpu_time
  end dequeue_cpu_time
from DBA_HIST_PERSISTENT_QUEUES q join dba_hist_snapshot s on (q.snap_id=s.snap_id and q.dbid=s.dbid and q.instance_number=s.instance_number)
where queue_name =upper(trim('&qname')) and queue_schema=upper(trim('&qowner'))
and end_interval_time > sysdate - &n_last_days
and s.dbid = (select dbid from v$database)
order by end_interval_time
)
,q2 as (
select to_char(end_interval_time,'MM/DD Dy HH24') snap_time
  --,sum(snap_ela_sec)
  --, queue_schema, queue_name
  --, queue_id, first_activity_time
  , sum(enqueued_msgs) enqueued_msgs
  , sum(dequeued_msgs) dequeued_msgs
  , round(sum(enqueued_msgs)/sum(snap_ela_sec),1) enq_msg_per_sec
  , round(sum(dequeued_msgs)/sum(snap_ela_sec),1) deq_msg_per_sec
  --, elapsed_enqueue_time, elapsed_dequeue_time
  , cast(numtodsinterval(sum(elapsed_enqueue_time)/100,'SECOND') as interval day(1) to second(0)) enq_time
  , cast(numtodsinterval(sum(elapsed_dequeue_time)/100,'SECOND') as interval day(1) to second(0)) deq_time
  , cast(numtodsinterval(sum(enqueue_cpu_time)/100,'SECOND') as interval day(1) to second(0)) enq_cpu_time
  , cast(numtodsinterval(sum(dequeue_cpu_time)/100,'SECOND') as interval day(1) to second(0)) deq_cpu_time
  --, case when sum(enqueued_msgs) <> 0 then to_char(round(sum(elapsed_enqueue_time)/sum(enqueued_msgs),5),'0.00000') else '0' end enq_ela_per_msg
  --, case when sum(dequeued_msgs) <> 0 then to_char(round(sum(elapsed_dequeue_time)/100/sum(dequeued_msgs),5),'0.00000') else '0' end deq_ela_per_msg
  --, case when sum(enqueued_msgs) <> 0 then to_char(round(sum(enqueue_cpu_time)/100/sum(enqueued_msgs),5),'0.00000') else '0' end enq_cpu_per_msg
  --, case when sum(dequeued_msgs) <> 0 then to_char(round(sum(dequeue_cpu_time)/100/sum(dequeued_msgs),5),'0.00000') else '0' end deq_cpu_per_msg
  , case when sum(enqueued_msgs) <> 0 then round(sum(elapsed_enqueue_time)*10/sum(enqueued_msgs),2) else 0 end enq_ela_per_msg
  , case when sum(dequeued_msgs) <> 0 then round(sum(elapsed_dequeue_time)*10/sum(dequeued_msgs),2) else 0 end deq_ela_per_msg
  , case when sum(enqueued_msgs) <> 0 then round(sum(enqueue_cpu_time)*10/sum(enqueued_msgs),2) else 0 end enq_cpu_per_msg
  , case when sum(dequeued_msgs) <> 0 then round(sum(dequeue_cpu_time)*10/sum(dequeued_msgs),2) else 0 end deq_cpu_per_msg
from q1
group by to_char(end_interval_time,'MM/DD Dy HH24')
--, queue_schema, queue_name
)
select *
from q2
order by 1;

