
set line 250 pagesize 200 verify off

accept task_id prompt 'Enter task_id, 0=all_tasks (default: 0): ' default '0'
accept task_templ prompt 'Enter task_template (default: %): ' default '%'
accept task_name prompt 'Enter task_name (default: %): ' default '%'
accept task_def_name prompt 'Enter task_def_name (default: %): ' default '%'
accept acp_user prompt 'Enter ACP user_name (default: %): ' default '%'
accept last_days prompt 'Enter # of last days to display  (default: 7): ' default '7'
accept session_id prompt 'Enter session_id (SID) (default: %): ' default '%'
--accept active_only prompt 'Display only running tasks? (default: N): ' default 'N'
accept min_runtime prompt 'Skip tasks shorter than N minutes (default: 0): ' default '0'
accept task_status prompt 'Task status? [Enabled|Started|Processed|Not Processed|Killed] (default: ALL): ' default 'ALL'
accept get_pga_ash prompt 'Get PGA mem from ASH? - can be slow (default: N): ' default 'N'


col tmpl_intl_id form A50
col run_id form A12
col userstamp form A12
col username form A18
col start_time form A16
col end_time form A16
col exec_time form A14
col task_name form A50
col status form A10
col session_id form 9999999
col pga_gb form 990D00
col prl# form 999
col prlmax form 999 heading "Prl|Max"
col delay form A12
break on report
compute sum of prl# on report

with j as (
select /*+ materialize */
  ttv.intl_id tmpl_intl_id
  ,to_char(oj.id) run_id
  --,oj.parent_task_id
  --,nvl2(oj.parent_task_id,'   '||oj.id,oj.id) task_id
  ,oj.userstamp username
  ,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI') start_time
  ,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI')) end_time
  --,oj.parallel_exec_id
  , oj.parallel_exec_nr_prc prl#
  , oj.prl_exec_max_nr_prc prlmax
  --, oj.parallel_exec_seq_nr prl_seq
  --,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  ,case when oj.out_status_id=3 then
    cast(sysdate-oj.timestamp_start  as interval day(1) to second(0))
   else
    cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0))
  end exec_time
  --,oj.timestamp-numtodsinterval(oj.exec_time/100,'SECOND')
  ,k.task_def#.task#name(oi.obj_id) task_name
  --,ttv.task_name
  --,s.user_id
  --,s.id
  ,s.name status
  --,oj.sid session_id
  ,oj.err_log_id
  ,case when oj.out_status_id = 3 then
    (select round(sum(pga_alloc_mem/1024/1024/1024),2) pga_alloc_gb
      from k.out_job j, v$session s, v$process p
      where (id=oj.id or parent_task_id=oj.id)
        and j.sid=s.sid and s.paddr=p.addr
        and j.out_status_id = 3
    )
    else
      null
   end pga_gb
  ,cast(nvl(oj.timestamp_start,systimestamp)-oj.timestamp_ins as interval day(1) to second(0)) delay
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
  (oj.id in(&task_id) or '0'='&task_id')
  and (upper(ttv.user_id) like upper(trim('&task_templ')) or trim('&task_templ') ='%')
  and (upper(k.task_def#.task#name(oi.obj_id)) like upper(trim('&task_name')) or trim('&task_name') ='%')
  and (upper(oi.name) like upper(trim('&task_def_name')) or trim('&task_def_name') ='%')
  --and oj.sid like '&session_id'
  and (oj.sid like '&session_id' or (oj.sid is null and '&session_id'='%'))
  and oj.out_status_id=s.id
  and oj.userstamp like trim('&acp_user')
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
  and oj.timestamp_ins > trunc(sysdate) - &last_days
  and (oj.parent_task_id is null or '&session_id' <> '%')
  and (upper(s.name) = trim(upper('&task_status')) or trim(upper('&task_status')) = 'ALL')
  and nvl(oj.exec_time,0)/100/60 >= &min_runtime
order by oj.id
)
, m as (
select /*+ materialize */ run_id,max(pga_gb),max(max_pga)*max(cnt) est_max from (
  select run_id,sample_time,round(sum(pga_allocated/1024/1024/1024),2) pga_gb, round(max(pga_allocated/1024/1024/1024),2) max_pga,count(*) cnt
  --from  v$active_session_history ash,
  from dba_hist_active_sess_history ash,
    (select run_id,sid,oj.timestamp_start, decode(oj.out_status_id,3,sysdate,oj.timestamp) end_time
    from k.out_job oj,j where id=to_number(j.run_id) or parent_task_id=to_number(j.run_id)
    ) j
  where j.sid=ash.session_id and ash.sample_time between j.timestamp_start and j.end_time
  and upper(trim('&get_pga_ash'))='Y'
  group by run_id, sample_time
  )
group by run_id
)
select /*+ parallel(2) */ tmpl_intl_id, j.run_id, username,delay, start_time, end_time, nvl(prl#,1) prl#, prlmax, exec_time, task_name, status, nvl(pga_gb,est_max) pga_gb
from j,m
where j.run_id=m.run_id(+)
order by j.run_id
/

