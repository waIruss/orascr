set line 240 pagesize 100
set verify off
col release form A20
col extl_name form A40

accept SRC_NAME prompt 'Enter source_name: '

set line 240 pagesize 100
col release form A20
col app_name form A8
col src_type form A20
col src_name form A40
select 
   --ia.install_id
   to_char(ia.timestp_ins,'YYYY-MM-DD HH24:MI:SS') timestp_ins
   --,ip.repository_pkg_id
   --,ic.intl_id client
   ,ip.release
   --,ip.extl_name
   --,ip.descn
   --,cipk.name pkg_kind
   ,iap.name app_name
   --,ipk.*   --dupl
   --,ips.*   
   , ips.src_type
   , ips.src_name
   , ips.repository_chg_id
   , ips.install_file_id
   --,to_clob(if.bin_val)
from x.install_action ia
   ,x.install_pkg ip
   ,x.install_clt ic
   ,x.code_install_pkg_kind cipk
   ,x.install_app iap
   ,x.install_pkg_key ipk
   ,x.install_pkg_src ips
   ,x.install_file if
where 1=1
--and ia.timestp_ins > sysdate - 30
and ips.src_name=trim(upper('&SRC_NAME'))
and ia.install_id=ip.install_id
and ic.id=ip.install_clt_id
and ip.install_pkg_kind_id = cipk.id
and ip.install_app_id=iap.id
and ip.install_pkg_key_id=ipk.id
and ip.id=ips.install_pkg_id
and ips.install_file_id=if.id(+)
order by ia.timestp_ins desc,src_type,src_name;
