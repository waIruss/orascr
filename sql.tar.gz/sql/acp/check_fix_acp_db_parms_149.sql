set line 250
set pagesize 500
set feedback off
set verify off
set termout off

col shared_pool_res_size new_val shared_pool_res_size noprint
select round(value*0.1) shared_pool_res_size from v$parameter where name = 'shared_pool_size';
col max_threads new_val max_threads noprint
select ltrim(cpu_count_current) max_threads from v$license;

set termout on


set serverout on format wrapped size unlimited
declare
  cursor c_par_remove is
    select name 
    from v$spparameter 
    where name not in(
      '_bct_public_dba_buffer_size',
      '_column_tracking_level',
      '_cursor_obsolete_threshold',
      '_disable_actualization_for_grant',
      '_enable_space_preallocation',
      '_enable_shared_pool_durations',
      '_fix_control',
      '_max_spacebg_slaves',
      '_optimizer_dsdir_usage_control',
      '_optimizer_gather_stats_on_load',
      '_optimizer_use_feedback',
      '_partition_large_extents',
      '_report_capture_cycle_time',
      '_shared_io_pool_size',
      '_sql_plan_directive_mgmt_control'
      )
      and name like '\_%' escape '\';

  cursor c_par is
    select ref.p_name,ref.p_value req_value,p.value curr_value
    ,p.type
    ,case
      when p.type = 2 then
        case
          when ref.p_name = '_fix_control' then
            'alter system set "_fix_control"='''||replace(ref.p_value,', ',''',''')||''' scope=spfile;'
          when ref.p_name = 'event' then
            'alter system set "event"='''||regexp_replace(ref.p_value,'(, )(\d+ trace name)','''\1''\2')||''' scope=spfile;'
          else
            'alter system set "'||ref.p_name||'"='''||ref.p_value||''' scope=spfile;'
        end
      when p.type in(3,6) then
        case
          when to_number(p.value) > to_number(ref.p_value) and ref.oper in('>','>=') then
            '--alter system set "'||ref.p_name||'"='||ref.p_value||' scope=spfile;'
          when to_number(p.value) < to_number(ref.p_value) and ref.oper in('<','<=') then
            '--alter system set "'||ref.p_name||'"='||ref.p_value||' scope=spfile;'
          else
            'alter system set "'||ref.p_name||'"='||ref.p_value||' scope=spfile;'
        end
      else
        'alter system set "'||ref.p_name||'"='||ref.p_value||' scope=spfile;'
    end adjust_cmd
    from (
      select '_column_tracking_level' as p_name,'0' as p_value, '=' as oper from dual union all
      select '_cursor_obsolete_threshold' as p_name,'1024' as p_value, '=' as oper from dual union all
      select '_disable_actualization_for_grant' as p_name,'TRUE' as p_value, '=' as oper from dual union all
      select '_enable_space_preallocation' as p_name,'0' as p_value, '=' as oper from dual union all
      select '_enable_shared_pool_durations' as p_name,'FALSE' as p_value, '=' as oper from dual union all
      select '_fix_control' as p_name,'23473108:off, 20424684:off, 22582700:off' as p_value, '=' as oper from dual union all
      select '_max_spacebg_slaves' as p_name,'32' as p_value, '=' as oper from dual union all
      select '_optimizer_dsdir_usage_control' as p_name,'0' as p_value, '=' as oper from dual union all
      select '_optimizer_gather_stats_on_load' as p_name,'FALSE' as p_value, '=' as oper from dual union all
      select '_optimizer_use_feedback' as p_name,'FALSE' as p_value, '=' as oper from dual union all
      select '_partition_large_extents' as p_name,'false' as p_value, '=' as oper from dual union all
      select '_report_capture_cycle_time' as p_name,'0' as p_value, '=' as oper from dual union all
      --select '_session_cached_instantiations' as p_name,'901' as p_value, '=' as oper from dual union all
      select '_sql_plan_directive_mgmt_control' as p_name,'0' as p_value, '=' as oper from dual union all
      select 'aq_tm_processes' as p_name,'1' as p_value, '=' as oper from dual union all
      select 'audit_trail' as p_name,'DB' as p_value, '=' as oper from dual union all
      select 'cluster_database' as p_name,'FALSE' as p_value, '=' as oper from dual union all
      select 'compatible' as p_name,'19.0.0' as p_value, '=' as oper from dual union all
      select 'cursor_sharing' as p_name,'exact' as p_value, '=' as oper from dual union all
      select 'db_block_checking' as p_name,'off' as p_value, '=' as oper from dual union all
      select 'db_block_checksum' as p_name,'TYPICAL' as p_value, '=' as oper from dual union all
      select 'db_block_size' as p_name,'8192' as p_value, '=' as oper from dual union all
      select 'db_cache_advice' as p_name,'ON' as p_value, '=' as oper from dual union all
      --select 'db_create_file_dest' as p_name,'+DATA' as p_value, '=' as oper from dual union all
      select 'db_file_multiblock_read_count' as p_name,'32' as p_value, '=' as oper from dual union all
      select 'db_files' as p_name,'2048' as p_value, '>=' as oper from dual union all
      --select 'db_recovery_file_dest' as p_name,'+FRA' as p_value, '=' as oper from dual union all
      select 'db_securefile' as p_name,'permitted' as p_value, '=' as oper from dual union all
      select 'db_writer_processes' as p_name,'8' as p_value, '<=' as oper from dual union all
      select 'ddl_lock_timeout' as p_name,'5' as p_value, '=' as oper from dual union all
      select 'disk_asynch_io' as p_name,'TRUE' as p_value, '=' as oper from dual union all
      select 'event' as p_name,'10262 trace name context forever, level 256, 10852 trace name context forever, level 16384, 28401 trace name context forever, level 1, 20635353 trace name context forever, level 11' as p_value, '=' as oper from dual union all
      select 'fast_start_mttr_target' as p_name,'900' as p_value, '=' as oper from dual union all
      select 'filesystemio_options' as p_name,'setall' as p_value, '=' as oper from dual union all
      select 'instance_number' as p_name,'0' as p_value, '=' as oper from dual union all
      select 'java_jit_enabled' as p_name,'TRUE' as p_value, '=' as oper from dual union all
      select 'job_queue_processes' as p_name,'4000' as p_value, '=' as oper from dual union all
      select 'log_checkpoints_to_alert' as p_name,'TRUE' as p_value, '=' as oper from dual union all
      select 'max_dump_file_size' as p_name,'5M' as p_value, '=' as oper from dual union all
      select 'nls_date_format' as p_name,'DD-MON-YYYY' as p_value, '=' as oper from dual union all
      select 'nls_language' as p_name,'AMERICAN' as p_value, '=' as oper from dual union all
      select 'nls_length_semantics' as p_name,'CHAR' as p_value, '=' as oper from dual union all
      select 'nls_nchar_conv_excp' as p_name,'false' as p_value, '=' as oper from dual union all
      select 'nls_territory' as p_name,'AMERICA' as p_value, '=' as oper from dual union all
      select 'open_cursors' as p_name,'900' as p_value, '=' as oper from dual union all
      select 'optimizer_adaptive_plans' as p_name,'FALSE' as p_value, '=' as oper from dual union all
      select 'optimizer_dynamic_sampling' as p_name,'1' as p_value, '=' as oper from dual union all
      select 'optimizer_index_caching' as p_name,'95' as p_value, '=' as oper from dual union all
      select 'optimizer_index_cost_adj' as p_name,'50' as p_value, '=' as oper from dual union all
      select 'optimizer_mode' as p_name,'ALL_ROWS' as p_value, '=' as oper from dual union all
      select 'parallel_max_servers' as p_name,'&max_threads' as p_value, '=' as oper from dual union all
      select 'parallel_min_servers' as p_name,'0' as p_value, '=' as oper from dual union all
      select 'plsql_warnings' as p_name,'DISABLE:ALL' as p_value, '=' as oper from dual union all
      select 'processes' as p_name,'5000' as p_value, '=' as oper from dual union all
      select 'query_rewrite_enabled' as p_name,'true' as p_value, '=' as oper from dual union all
      select 'recyclebin' as p_name,'off' as p_value, '=' as oper from dual union all
      select 'resource_limit' as p_name,'FALSE' as p_value, '=' as oper from dual union all
      select 'session_cached_cursors' as p_name,'900' as p_value, '=' as oper from dual union all
      select 'shared_pool_reserved_size' as p_name,'&shared_pool_res_size' as p_value, '>=' as oper from dual union all
      select 'shared_server_sessions' as p_name,'0' as p_value, '=' as oper from dual union all
      select 'shared_servers' as p_name,'0' as p_value, '=' as oper from dual union all
      select 'sql92_security' as p_name,'TRUE' as p_value, '=' as oper from dual union all
      select 'star_transformation_enabled' as p_name,'false' as p_value, '=' as oper from dual union all
      select 'statistics_level' as p_name,'typical' as p_value, '=' as oper from dual union all
      select 'temp_undo_enabled' as p_name,'TRUE' as p_value, '=' as oper from dual union all
      select 'timed_statistics' as p_name,'TRUE' as p_value, '=' as oper from dual union all
      select 'undo_management' as p_name,'AUTO' as p_value, '=' as oper from dual union all
      select 'undo_retention' as p_name,'7200' as p_value, '>=' as oper from dual union all
      select 'workarea_size_policy' as p_name,'auto' as p_value, '=' as oper from dual
    ) ref
      left outer join (select name,listagg(value,',') as value,type from v$parameter group by name,type) p on(upper(ref.p_name)=upper(p.name))
      --left outer join v$spparameter sp on (upper(ref.p_name)=upper(sp.name))
    where upper(ref.p_value) <> upper(nvl(p.value,'XXXXXX'))
    order by ref.p_name;
  v_gen_fix boolean := true;
  v_is_empty boolean := true;
  v_db_name varchar2(30);
begin
  select upper(name) into v_db_name from v$database;
  for par in c_par
    loop
      v_is_empty := false;
    end loop;

  if not v_is_empty then
    Dbms_Output.Put_Line(rpad('-',40,'-')||' '||lpad('-',50,'-')||' '||lpad('-',50,'-'));
    Dbms_Output.Put_Line(rpad('Parameter',40,' ')||' '||lpad('Required value',50,' ')||' '||lpad('Current value',50,' '));
    Dbms_Output.Put_Line(rpad('-',40,'-')||' '||lpad('-',50,'-')||' '||lpad('-',50,'-'));
  end if;
  for par in c_par
    loop
      Dbms_Output.Put_Line(rpad(par.p_name,40,' ')||' '||lpad(par.req_value,50,' ')||' '||lpad(par.curr_value,50,' '));
    end loop;

  if not v_is_empty then
    Dbms_Output.Put_Line(chr(10));
    Dbms_Output.Put_Line(rpad('-',142,'-'));
    Dbms_Output.Put_Line('--backup pfile ');
    Dbms_Output.Put_Line('create pfile=''init'||v_db_name||'.'||to_char(sysdate,'YYYYMMDD.HH24MISS')||'.bkp.ora'' from spfile;');
    Dbms_Output.Put_Line(rpad('-',142,'-'));
    Dbms_Output.Put_Line(chr(10));
    Dbms_Output.Put_Line(rpad('-',142,'-'));
    Dbms_Output.Put_Line(rpad('- Commands to fix ',142,' '));
    Dbms_Output.Put_Line(rpad('-',142,'-'));
  end if;

  for par in c_par
    loop
      Dbms_Output.Put_Line(par.adjust_cmd);
    end loop;

  for r_par in c_par_remove
    loop
      Dbms_Output.Put_Line('alter system reset "'||r_par.name||'";');
    end loop;

  if not v_is_empty then
    Dbms_Output.Put_Line('--fix pfile ');
    Dbms_Output.Put_Line('create pfile from spfile;');
    Dbms_Output.Put_Line(chr(10));
    Dbms_Output.Put_Line(rpad('-',142,'-'));
    Dbms_Output.Put_Line('--Review generated settings and apply them');
    Dbms_Output.Put_Line(rpad('-',142,'-'));
  end if;

end;
/


select 'revoke '||privilege||' from '||grantee||';' as "Revoke extra grants on ACP" from dba_sys_privs where privilege='EXEMPT ACCESS POLICY' and grantee not in ('SYSTEM','C','GSMUSER_ROLE','GSMADMIN_INTERNAL');

set feedback on
