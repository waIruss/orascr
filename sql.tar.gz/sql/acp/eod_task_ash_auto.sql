set trimspool on
set feedback off linesize 10000
set termout off
set echo off
set pagesize 0
set verify off

def days_back=&1
def outfile=&2

set markup csv on
spool &outfile

with j as (
select
  ttv.intl_id task_template
  ,oi.name_intl task_def_name
  ,oj.id run_id
  ,oj.parent_task_id
  ,nvl(oj.parent_task_id,oj.id) main_run_id
  ,oj.userstamp username
  ,oj.timestamp_ins submit_time
  ,oj.timestamp_start start_time
  ,oj.timestamp end_time
  ,to_char(oj.timestamp_ins,'YYYY-MM-DD HH24:MI:SS') submit_time_
  ,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI:SS') start_time_
  ,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI:SS')  end_time_
  ,round((cast(oj.timestamp_start as date) - cast(oj.timestamp_ins as date))*24*60*60,2) delay_sec
  --,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI') start_time
  --,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI')) end_time
  --,oj.parallel_exec_id
  , oj.parallel_exec_nr_prc prl_proc
  --, oj.parallel_exec_seq_nr prl_seq
  ,case when oj.out_status_id=3 then
    cast(sysdate-oj.timestamp_start  as interval day(1) to second(0))
   else
    cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0))
  end exec_time
  ,oj.exec_time/100 exec_time_sec
  ,max(oj.exec_time) over(partition by nvl(oj.parent_task_id,oj.id))/100 max_exec_time_sec 
  --,oj.timestamp-numtodsinterval(oj.exec_time/100,'SECOND')
  ,k.task_def#.task#name(oi.obj_id) task_name
  --,ttv.task_name
  ,s.name status
  ,oj.sid session_id
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
 oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
  and oj.timestamp_ins between trunc(sysdate-1-&days_back) + interval '12' hour and trunc(sysdate-&days_back) + interval '12' hour 
)
, a1 as (
select /*+ leading(a) */
  --sample_time
  j.main_run_id
  ,task_template
  ,max(task_def_name) task_def_name
  ,max(task_name) task_name
  ,max(prl_proc) prl_proc
  ,min(submit_time_) submit_time
  ,min(start_time_) start_time
  ,max(end_time_) end_time
  ,max(delay_sec) delay_sec
  ,max(max_exec_time_sec) exec_time_sec
  --,b1.bgp_instn
  --,a.session_id,a.session_serial#
  --,sql_id,sql_plan_hash_value,sql_opname
  --,nvl(wait_class,session_state)
  ,case
    when event is null   then 'CPU'
    when event in ('latch: cache buffers chains'
                  ,'enq: UL - contention'
                  ,'buffer busy waits'
                  )      then event
    when event like '%latch%' then 'latch'
    when event like '%mutex%' then 'mutex'
    when wait_class in ('Administrative'
                        ,'Application'
                        ,'Cluster'
                        ,'Commit'
                        ,'Concurrency'
                        ,'Configuration'
                        ,'Idle'
                        ,'Network'
                        ,'Queueing'
                        ,'Scheduler'
                        ,'System I/O'
                        ,'User I/O'
                        ,'Other'
                        ) then wait_class
    else 'Unacc'
  end wait_class
  ,sql_id
  ,count(*) aas
  ,max(exec_time_sec)/10*nvl(max(prl_proc),1) total_samples
from dba_hist_active_sess_history a
  join dba_hist_snapshot s on ( a.dbid=s.dbid and a.snap_id=s.snap_id and s.begin_interval_time between trunc(sysdate-1-&days_back) + interval '11' hour and trunc(sysdate-&days_back) + interval '14' hour )
  --,j
  --left outer
  join j on (a.sample_time between j.start_time and j.end_time and a.session_id=j.session_id)
--where (dbid,snap_id) in (select dbid,snap_id from dba_hist_snapshot where begin_interval_time >= trunc(sysdate))
--  and a.sample_time between j.start_time and j.end_time and a.session_id=j.session_id
group by
  --sample_time
  j.main_run_id
  ,task_template
  --,task_def_name
  --,b1.bgp_instn
  --,a.session_id,a.session_serial#
  --,sql_id,sql_plan_hash_value,sql_opname
  --,nvl(wait_class,session_state)
  ,case
    when event is null   then 'CPU'
    when event in ('latch: cache buffers chains'
                  ,'enq: UL - contention'
                  ,'buffer busy waits'
                  )      then event
    when event like '%latch%' then 'latch'
    when event like '%mutex%' then 'mutex'
    when wait_class in ('Administrative'
                        ,'Application'
                        ,'Cluster'
                        ,'Commit'
                        ,'Concurrency'
                        ,'Configuration'
                        ,'Idle'
                        ,'Network'
                        ,'Queueing'
                        ,'Scheduler'
                        ,'System I/O'
                        ,'User I/O'
                        ,'Other'
                        ) then wait_class
    else 'Unacc'
  end
  ,sql_id
)
select main_run_id AVQ_task_id, task_template, task_def_name, task_name, prl_proc, submit_time, start_time, end_time, delay_sec, exec_time_sec, wait_class,sql_id, aas
  ,round(ratio_to_report(aas) over (partition by main_run_id),6)*100 pct
from a1 
order by main_run_id;


spool off
set markup csv off
exit;
