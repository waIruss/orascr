set trimspool on
set feedback off linesize 10000
set termout off
set echo off
set pagesize 0
set verify off

def days_back=&1
def outfile=&2

set markup csv on
spool &outfile

with b1 as (
select * from (
  select obj_id as bgp, instn_id as bgp_instn, session_sid session_id, session_serial#
    --, started as start_time
    ,nvl(started,lag(stopped) over(partition by obj_id,instn_id order by stopped)) + interval '1' second  start_time
    ,nvl(nvl(stopped,lead(started) over(partition by obj_id,instn_id order by started)),sysdate)  - interval '1' second  end_time
  from
  (
    select * from
    (
      select timestp,obj_id,instn_id,session_sid,session_serial#,action
        from k.bgp_log where action like '%ed' and trunc(timestp) > sysdate - 7
        --and obj_id=991
    ) b
    pivot (
      max(timestp) for action in('Started' as started, 'Stopped' as stopped)
    )
    order by obj_id,started  nulls last
  )
  )
  where start_time is not null and end_time is not null
  and (trunc(sysdate-1-&days_back) + interval '12' hour  between start_time and end_time or start_time >= trunc(sysdate-1-&days_back) + interval '12' hour)
  --and trunc(sysdate-1-&days_back) + interval '12' hour and trunc(sysdate-&days_back) + interval '12' hour 
)
,dt as (
  select trunc(sysdate-1-&days_back) + interval '12' hour + (level-1)/24/60*5 ival
  from dual
  connect by trunc(sysdate-1-&days_back) + interval '12' hour + (level-1)/24/60*5 <= trunc(sysdate-&days_back) + interval '12' hour
)
, b2 as (
  select ival,bgp,count(*) started_inst
  from b1,dt
  where ival between start_time and end_time
  group by ival,bgp
)
,jobs as (
  select session_id,actual_start_date,log_date,substr(job_name,13,3) bgp
  from dba_scheduler_job_run_details
  where log_date > trunc(sysdate-1/10)
    and job_name like 'AVQ$AAA_BGP_%'
  union all
  select rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate,substr(job_name,13,3) bgp
  from dba_scheduler_running_jobs drj
    , v$scheduler_running_jobs rj
    , v$session s
  where drj.session_id=rj.session_id
    and rj.session_id=s.sid and rj.session_serial_num=s.serial#
    and drj.job_name like 'AVQ$AAA_BGP_%'
  union all
  select s.sid||','||s.serial# session_id,s.logon_time start_date, sysdate , substr(client_info,8,3) bgp
  from v$session s
  where client_info like 'BGP_OS.%'
)
, a1 as (
select /*+ leading(a) */ sample_time
  ,nvl(to_char(b1.bgp),jobs.bgp) bgp
  --,b1.bgp_instn
  --,a.session_id,a.session_serial#
  --,sql_id,sql_plan_hash_value,sql_opname
  --,nvl(wait_class,session_state)
  ,case
    when event is null   then 'CPU'
    when event in ('latch: cache buffers chains'
                  ,'enq: UL - contention'
                  ,'buffer busy waits'
                  )      then event
    when event like '%latch%' then 'latch'
    when event like '%mutex%' then 'mutex'
    when wait_class in ('Administrative'
                        ,'Application'
                        ,'Cluster'
                        ,'Commit'
                        ,'Concurrency'
                        ,'Configuration'
                        ,'Idle'
                        ,'Network'
                        ,'Queueing'
                        ,'Scheduler'
                        ,'System I/O'
                        ,'User I/O'
                        ,'Other'
                        ) then wait_class
    else 'Unacc'
  end wait_class
  --,count(*) over(partition by sample_time,bgp order by sample_time ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) aas
  ,count(*) aas
from dba_hist_active_sess_history a
  left outer join b1 on (a.sample_time between b1.start_time and b1.end_time and a.session_id=b1.session_id and a.session_serial#=b1.session_serial#)
  left outer join jobs on (jobs.session_id=a.session_id||a.session_serial# and a.sample_time between jobs.actual_start_date and jobs.log_date)
where (dbid,snap_id) in (select dbid,snap_id from dba_hist_snapshot where begin_interval_time between trunc(sysdate-1-&days_back) + interval '11' hour and trunc(sysdate-&days_back) + interval '14' hour)
  and a.sample_time between b1.start_time and b1.end_time and a.session_id=b1.session_id and a.session_serial#=b1.session_serial#
  and nvl(to_char(b1.bgp),jobs.bgp) is not null
group by sample_time
  ,nvl(to_char(b1.bgp),jobs.bgp)
  ,case
    when event is null   then 'CPU'
    when event in ('latch: cache buffers chains'
                  ,'enq: UL - contention'
                  ,'buffer busy waits'
                  )      then event
    when event like '%latch%' then 'latch'
    when event like '%mutex%' then 'mutex'
    when wait_class in ('Administrative'
                        ,'Application'
                        ,'Cluster'
                        ,'Commit'
                        ,'Concurrency'
                        ,'Configuration'
                        ,'Idle'
                        ,'Network'
                        ,'Queueing'
                        ,'Scheduler'
                        ,'System I/O'
                        ,'User I/O'
                        ,'Other'
                        ) then wait_class
    else 'Unacc'
  end
), a2 as (
select to_char(trunc(sample_time, 'hh24') + numtodsinterval( ceil ( extract ( minute from sample_time ) / 5 ) * 5 , 'minute'),'YYYY-MM-DD HH24:MI') sample_ival
  ,bgp,wait_class
  ,round(avg(aas),2) avg_busy_inst
  ,min(aas) min_busy_inst
  ,max(aas) max_busy_inst
from a1
group by to_char(trunc(sample_time, 'hh24') + numtodsinterval( ceil ( extract ( minute from sample_time ) / 5 ) * 5 , 'minute'),'YYYY-MM-DD HH24:MI')
  ,bgp,wait_class
)
select sample_ival, a2.bgp, wait_class
  , min_busy_inst
  , avg_busy_inst
  , max_busy_inst
  , started_inst
from a2, b2
where to_date(a2.sample_ival,'YYYY-MM-DD HH24:MI')=b2.ival and a2.bgp=b2.bgp
order by 1,2;



spool off
set markup csv off
exit;
