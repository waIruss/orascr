set line 240 pagesize 200 verify off
col job_name form A20
col "DB load %" form 999D00
col waits_by_wclass form A40
col time_range form A20
col task_ form A60

def DT_FMT_ISO="YYYY-MM-DD HH24:MI"

col bdate new_val bdate noprint
col edate new_val edate noprint
select
  to_char(trunc(sysdate - (2/24),'HH24'),'&&DT_FMT_ISO') as bdate,
  to_char(sysdate,'&&DT_FMT_ISO') as edate
from dual;


prompt ===========================================================================
accept ash_src prompt 'ASH source: H - dba_hist, A - v$active_sess (default: A): ' default 'A'
accept last_mins prompt 'Enter # of last minutes to analyze for v$active_ses (default: 30): ' default '30'
accept BGP_NUMBER prompt 'Enter BGP number (default: %): ' default '%'
accept show_wclass prompt 'Show breakdown by wait_class (default: N): ' default 'N'
accept min_db_load prompt 'Enter min. % of db load to report (default: 0.1): ' default '0.1'
ACCEPT bdate  DEFAULT '&bdate'  PROMPT 'Enter start date for DBA_HIST_ as &&DT_FMT_ISO [&bdate]: '
ACCEPT edate  DEFAULT '&edate'  PROMPT 'Enter end date for DBA_HIST_ as &&DT_FMT_ISO [&edate]: '
prompt ===========================================================================


col ash_table new_val ash_table noprint
select decode(upper(trim('&ash_src')),'A','v$active_session_history','H','dba_hist_active_sess_history','dba_hist_active_sess_history') ash_table from dual;
col wclass_col new_val wclass_col noprint
select decode(upper(trim('&show_wclass')),'Y',',waits_by_wclass','N','') wclass_col from dual;


break on time_range on job_name on avg_active_bgp skip 1
--break on report
--compute sum of avg_active_bgp on time_range


with
jobs as (
  select session_id,actual_start_date,log_date,job_name
  from dba_scheduler_job_run_details
  where actual_start_date > to_date('&bdate','&DT_FMT_ISO') - 3
  union all
  select rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate,job_name
  from dba_scheduler_running_jobs drj
    , v$scheduler_running_jobs rj
    , v$session s
  where drj.session_id=rj.session_id
    and rj.session_id=s.sid and rj.session_serial_num=s.serial#
), t1 as (
select
  ttv.user_id task_template
  ,coalesce(ttv.user_id,k.task_def#.task#name(oi.obj_id)) task_
  ,to_char(oj.id) task_id
  ,coalesce(oj.parent_task_id,oj.id) task_id_
  ,oj.userstamp username
  --,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI:SS') start_time
  ,oj.timestamp_start as start_time
  --,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI:SS')) end_time
  ,decode(oj.out_status_id,3,null,oj.timestamp) end_time
  , oj.parallel_exec_nr_prc prl_proc
  --, oj.prl_exec_max_nr_prc
  --, oj.parallel_exec_seq_nr prl_seq
  ,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  ,k.task_def#.task#name(oi.obj_id) task_name
  --,s.user_id
  --,s.id
  ,s.name status
  ,oj.sid session_id
  --,oj.err_log_id
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
  --oj.sid
  oj.out_status_id=s.id
  and oj.timestamp_start >= to_date('&bdate','&DT_FMT_ISO') - interval '1' minute
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
)
,ash as (
select
  substr(job_name,1,15) job_name
  ,t1.task_
  ,nvl(ash.wait_class,'CPU') wait_class
  ,count(*) cnt
  ,sum(count(*)) over() cnt_all
  ,min(sample_time) min_time
  ,max(sample_time) max_time
from &ash_table ash
  left outer join jobs
  on (ash.session_id||','||ash.session_serial#=jobs.session_id and ash.sample_time between jobs.actual_start_date and jobs.log_date)
  left outer join t1
  on (ash.session_id=t1.session_id and ash.sample_time between t1.start_time and t1.end_time)
where ( sample_time > sysdate - interval '&last_mins' minute or upper(trim('&ash_src')) = 'H')
  and ( sample_time between to_date('&bdate','&DT_FMT_ISO') and  to_date('&edate','&DT_FMT_ISO') or upper(trim('&ash_src')) = 'A')
group by substr(job_name,1,15)
  ,nvl(ash.wait_class,'CPU')
  ,t1.task_
)
,ash2 as (
  select job_name,avg(active_bgp) active_bgp
  from (
    select
      sample_time
      ,substr(job_name,1,15) job_name
      ,count(*) active_bgp
    from &ash_table ash
      left outer join jobs
        on (ash.session_id||','||ash.session_serial#=jobs.session_id and ash.sample_time between jobs.actual_start_date and jobs.log_date)
    where ( sample_time > sysdate - interval '&last_mins' minute or upper(trim('&ash_src')) = 'H')
      and ( sample_time between to_date('&bdate','&DT_FMT_ISO') and  to_date('&edate','&DT_FMT_ISO') or upper(trim('&ash_src')) = 'A')
    group by sample_time,substr(job_name,1,15)
  ) group by job_name
)
,ash3 as (
select
  min(min_time) min_time
  ,max(max_time) max_time
  ,ash.job_name
  ,ash.task_
  ,ash.wait_class
  ,round(avg(ash2.active_bgp)) avg_active_bgp
  ,round(sum(cnt)/cnt_all*100,2) pct_of_db_load
  ,round(sum(cnt)/sum(sum(cnt)) over()*100,2) pct_of_waits_in_bgp
from ash, ash2
where ash.job_name like 'AVQ$AAA_BGP_&BGP_NUMBER.%'
  and ash.job_name=ash2.job_name
group by (ash.job_name,ash.task_,wait_class,cnt_all)
order by pct_of_db_load desc
)
,ash4 as (
select
  min(min_time) min_time,max(max_time) max_time
  ,job_name
  ,task_
  ,avg_active_bgp
  ,sum(pct_of_db_load) pct_of_db_load
  ,listagg(rpad(wait_class,13,' ')||': '||trim(to_char(pct_of_db_load,'990D0'))||'%'||chr(10)) waits_by_wclass
from ash3
--where avg_active_bgp >= 5 --do not display BGPs with less than 5 active instances
group by job_name,task_,avg_active_bgp
order by 3 desc
)
select
  to_char(min(min_time) over(),'Mon-DD HH24:MI')||'-'||to_char(max(max_time) over(),'HH24:MI') time_range
  ,job_name
  ,avg_active_bgp
  ,task_
  ,pct_of_db_load "DB load %" &wclass_col
from ash4
where pct_of_db_load >= &min_db_load
order by avg_active_bgp desc, "DB load %" desc;

clear breaks
clear computes


