set termout off
set linesize 300
set verify off
set heading off feedback off

whenever sqlerror exit
whenever oserror exit

col today new_val today noprint
col dbname new_val dbname noprint
col svg_script new_val svg_script noprint
col html_script new_val html_script noprint

select to_char(sysdate,'YYYYMMDD') today,name dbname
,'/tmp/.gen_hprof_svg_'||to_char(systimestamp,'YYYYMMDDHH24MISS')||'_'||sys_context('userenv','sessionid')||'.sql' as svg_script
,'/tmp/.gen_hprof_html'||to_char(systimestamp,'YYYYMMDDHH24MISS')||'_'||sys_context('userenv','sessionid')||'.sql' as html_script
from v$database;



set termout on
col name form A120
set line 150 pagesize 100
prompt ==================================================================
prompt Available HPROF files (first 50)
prompt ==================================================================

SELECT id,name FROM K.HPROF_LOOKUP_V where rownum <=50;

prompt ==================================================================
ACCEPT file_pattern DEFAULT 'Y'     PROMPT 'Enter file pattern to process [%]: '
ACCEPT gen_svg DEFAULT 'Y'     PROMPT 'Generate SVG files? [Y]: '
ACCEPT gen_html DEFAULT 'Y'     PROMPT 'Generate HTML files? [Y]: '
ACCEPT out_dir  DEFAULT '.'   PROMPT 'Enter output directory for reports [.]: '
prompt ==================================================================

set termout off
host mkdir -p &&out_dir

spool &&svg_script
with f as(
SELECT id,name,trim(regexp_substr(name,'(.+/)(.+\.hpf)',1,1,'i',2)) file_name, replace(trim(regexp_substr(name,'(.+/)(.+\.hpf)',1,1,'i',2)),'.hpf','.svg') out_file_name
FROM K.HPROF_LOOKUP_V where name like '&file_pattern'
)
select
'prompt Generating report '||out_file_name||chr(10)||
'set echo off feedback off termout off trimspool on heading off pagesize 0 linesize 1000 long 10000000 longchunk 1000000'||chr(10)||
'spool &&out_dir./'||out_file_name||chr(10)||
'SELECT TEXT FROM K.HPROF_SVG_V WHERE ID = '||id||';'||chr(10)||
'spool off'||chr(10)||
'set termout on'||chr(10)
from f where upper(trim('&gen_svg')) = 'Y';
spool off
@@&&svg_script
host rm &&svg_script

set termout off
set line 300
spool &&html_script

with f as(
SELECT id,name,trim(regexp_substr(name,'(.+/)(.+\.hpf)',1,1,'i',2)) file_name, replace(trim(regexp_substr(name,'(.+/)(.+\.hpf)',1,1,'i',2)),'.hpf','.html') out_file_name
FROM K.HPROF_LOOKUP_V where name like '&file_pattern'
)
select
'prompt Generating report '||out_file_name||chr(10)||
'set echo off feedback off termout off trimspool on heading off pagesize 0 linesize 1000 long 10000000 longchunk 1000000'||chr(10)||
'spool &&out_dir./'||out_file_name||chr(10)||
'SELECT TEXT FROM K.HPROF_HTML_V WHERE ID = '||id||';'||chr(10)||
'spool off'||chr(10)||
'set termout on'||chr(10)
from f where upper(trim('&gen_html')) = 'Y';
spool off
@@&&html_script
host rm &&html_script


prompt ==================================================================
prompt Generated reports in &&out_dir
prompt ==================================================================

