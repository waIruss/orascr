set line 250 pagesize 200 verify off

accept item_name prompt 'Enter GC run item intl_id [%]: ' default '%'
accept last_days prompt 'Enter last days to show [30]: ' default 30


col intl_id form A16
col gc_run_status form A15
col start_time form A21
col end_time form A21
col elapsed form A16

col item_name form A40
col status form A10
col stmt form A50

select cgi.intl_id,cgi.name  item_name
   ,to_char(ir.start_time,'YYYY-MM-DD HH24:MI') start_time 
   ,to_char(ir.end_time,'YYYY-MM-DD HH24:MI') end_time
   ,cast(ir.end_time-ir.start_time as interval day(1) to second(0)) elapsed
   ,s2.name status
   ,cgi.stmt
   ,cgi.has_soft_timeout
   ,ir.err_cnt,ir.sid,ir.task_id 
from k.garbcol_item_run ir
  , k.code_garbcol_item cgi
  , k.code_garbcol_status s2
where 1=1
  --and cgi.intl_id like 'bde%'
  and cgi.intl_id like trim('&item_name')
  and cgi.id=ir.garbcol_item_id
  and ir.garbcol_status_id=s2.id
  and ir.start_time > trunc(sysdate-&last_days)
  --and ir.sid=9982 and ir.task_id=58827330
  --and upper(cgi.name) like '%LIST_NUMB%'
order by ir.start_time desc;

undef item_name
undef last_days
