set verify off
set heading on
def startdate="&1"
def enddate="&2"

select
  ttv.user_id task_template
  ,oj.id task_id
  ,oj.parent_task_id
  ,oj.userstamp username
  ,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI') start_time
  ,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI')) end_time
  ,oj.parallel_exec_id
  , oj.parallel_exec_nr_prc prl_proc
  , oj.parallel_exec_seq_nr prl_seq
  ,case when oj.out_status_id=3 then
    cast(sysdate-oj.timestamp_start  as interval day(1) to second(0))
   else
    cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0))
  end exec_time
  ,oj.exec_time/100 exec_time_seconds
  ,k.task_def#.task#name(oi.obj_id) task_name
  ,s.name status
  ,oj.sid session_id
  ,oj.err_log_id
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
  and oj.timestamp_ins between to_date('&&startdate','YYYY-MM-DD HH24:MI') and to_date('&enddate','YYYY-MM-DD HH24:MI')
order by oj.id;
