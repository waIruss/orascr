@@lstbs_like %
