
set line 250 pagesize 200 verify off

accept task_id prompt 'Enter task_id: '


col task_template form A50
col task_id form A12
col userstamp form A12
col username form A18
col start_time form A16
col end_time form A16
col exec_time form A14
col task_name form A50
col status form A10
col session_id form 9999999 
col timestamp_ form A20
col ctx form A90 wor
col err_stack form A90 wor
col pga_gb form 990D00


select
  ttv.user_id task_template
  --,to_char(oj.id) task_id
  --,oj.parent_task_id
  ,nvl2(oj.parent_task_id,'   '||oj.id,oj.id) task_id
  ,oj.userstamp username
  ,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI') start_time
  ,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI')) end_time
  --,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI') end_time
  --,oj.parallel_exec_id
  --, oj.parallel_exec_nr_prc prl_proc
  --, oj.prl_exec_max_nr_prc
  , oj.parallel_exec_seq_nr prl_seq
  ,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  --,oj.timestamp-numtodsinterval(oj.exec_time/100,'SECOND')  
  ,k.task_def#.task#name(oi.obj_id) task_name
  --,s.user_id
  ,s.name status
  ,oj.sid session_id
  ,case when oj.out_status_id = 3 then
    (select round(sum(pga_alloc_mem/1024/1024/1024),2) pga_alloc_gb
      from v$session s, v$process p
      where s.sid=oj.sid
        and s.paddr=p.addr)
    else
      null
   end pga_gb
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
  (oj.id=&task_id or oj.parent_task_id=&task_id)
  and oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
order by oj.parallel_exec_id,nvl(parent_task_id,0),parallel_exec_seq_nr;

select /*+ index(l log#i#3) */ id,to_char(timestamp,'YYYY-MM-DD HH24:MI:SS') timestamp_, err_id, ctx, err_stack
from k.log l where task_id=&task_id order by timestamp fetch first 5 rows only;
set heading off
prompt ...
select /*+ index(l log#i#3) */ id,to_char(timestamp,'YYYY-MM-DD HH24:MI:SS') timestamp_, err_id, ctx, err_stack
from k.log l where task_id=&task_id order by timestamp desc fetch first 5 rows only;
set heading on



accept disp_sess prompt 'Display session details? - v$session (default: Y): ' default 'Y'
accept disp_ash prompt 'Display ASH data for all task sessions? (default: N): ' default 'N'
accept disp_ash_sql prompt 'Display ASH data for all SQLs(summary)? (default: Y): ' default 'Y'
accept ash_src prompt 'ASH source: H - dba_hist, A - v$active_sess (default: A): ' default 'A'
accept disp_awr_sql prompt 'Display AWR data for all SQLs(summary)? (default: Y): ' default 'Y'


col sid_ser FORM A12
col c# FORM 99
col username FORM A10
col program FORM A25 trunc
col osinfo FORM A25 trunc
col obj FORM A20
col process FORM A10
col sql_id FORM A13
col event FORM A25
col wait_class_event FORM A38
col wait_class FORM A13
col p1 FORM 999999999999
col p2 FORM 999999999999
col pga_gb form 990D00



SELECT s.sid||','||s.serial# sid_ser,
  s.username, s.program,
  s.osuser||'@'||s.machine osinfo,
  s.process,
  decode(s.state,'WAITING',s.wait_class||': '||s.event,'ON CPU') wait_class_event,
  decode(s.state,'WAITING',s.p1,null) p1,
  decode(s.state,'WAITING',s.p2,null) p2,
  s.seconds_in_wait sec_in_wait,
  CASE WHEN s.ROW_WAIT_OBJ# > 0 THEN (SELECT object_name FROM dba_objects WHERE data_object_id = s.ROW_WAIT_OBJ#) ELSE To_Char(s.ROW_WAIT_OBJ#) END obj,
  s.sql_id, s.sql_child_number c#
  ,round((pga_alloc_mem/1024/1024/1024),2) pga_gb
FROM v$session s, v$process p,
  (select sid from k.out_job oj
   where
    (oj.id=&task_id or oj.parent_task_id=&task_id)
    and oj.out_status_id = 3
  ) t
WHERE
  s.sid=t.sid
  and s.paddr=p.addr
  and status='ACTIVE'
  and (
    state!='WAITING'
    or
    (state='WAITING' and wait_class!='Idle')
  )
  and upper(trim('&disp_sess'))='Y'
ORDER BY s.seconds_in_wait DESC;



break on session_id skip 1
col pctload form 990D00
col ashcnt form 999G999G999
col wclass_pct form A30 heading "% of waits|by wait class"
col event_pct form A55 heading "% of waits|by wait event"
col sql_opname form A14
col sql_text form A60
col min_max_time form A14

col ash_table new_val ash_table noprint
select decode(upper(trim('&ash_src')),'A','v$active_session_history','H','dba_hist_active_sess_history','dba_hist_active_sess_history') ash_table from dual;
col nohist new_val nohist noprint
select decode(upper(trim('&ash_src')),'A','--','H',' ',' ') nohist from dual;



PROMPT ==========================================================================
prompt  ASH statistics by session/sqlid
PROMPT ==========================================================================


with t as
(
select
  oj.timestamp_start start_time
  ,decode(oj.out_status_id,3,sysdate,oj.timestamp) end_time
  ,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  ,oj.sid session_id
from
  k.out_job oj
where
  (oj.parent_task_id=&task_id or oj.id=&task_id)  
), s as (
select 
   (select max(snap_id) bsnap 
   from dba_hist_snapshot where end_interval_time < (select min(timestamp_start) from k.out_job oj where (oj.parent_task_id=&task_id or oj.id=&task_id))
   and dbid = (select dbid from v$database)
   ) bsnap,
   (select max(snap_id) esnap 
    from dba_hist_snapshot where end_interval_time < (select max(decode(oj.out_status_id,3,sysdate,oj.timestamp))+(2/24) from k.out_job oj where (oj.parent_task_id=&task_id or oj.id=&task_id))
    and dbid = (select dbid from v$database)
   ) esnap,
   dbid
from v$database
), a1 as(
select ash.session_id
  ,sql_id,sql_opname
  --,case when session_state = 'WAITING' then wait_class else session_state end wait_class
  ,case when session_state = 'WAITING' then wait_class||': '||event else session_state end event
  ,count(*) ash_cnt
  ,round(count(*)*100/sum(count(*)) over(),2) pctload
  ,round(max(pga_allocated/1024/1024),1) max_pga_alloc
--from dba_hist_active_sess_history ash 
from &ash_table ash 
  &nohist join s on (ash.dbid=s.dbid and ash.snap_id between s.bsnap and s.esnap)
  join t on(ash.session_id=t.session_id and ash.sample_time between t.start_time and t.end_time)
where 'Y' = upper(trim('&disp_ash'))
group by ash.session_id
  ,sql_id
  ,sql_opname
  --,case when session_state = 'WAITING' then wait_class else session_state end 
  ,case when session_state = 'WAITING' then wait_class||': '||event else session_state end 
), a2 as (
select
  session_id
  ,sql_id
  ,sql_opname 
  ,sum(ash_cnt) ash_cnt
  ,sum(pctload) pctload
  ,max_pga_alloc
  --,rtrim(listagg(rpad(wait_class,14,' ')||': '||trim(to_char(pctload,'990D0'))||'%'||chr(10)) within group (order by pctload desc),chr(10))  wclass_pct
  --,listagg(rpad(wait_class||': '||pctload, chr(10)) within group (order by sql_id,pctload desc) wclass_pct
  ,rtrim(listagg(rpad(event,45,' ')||': '||trim(to_char(pctload,'990D0'))||'%'||chr(10)) within group (order by pctload desc),chr(10))  event_pct
  --,listagg(event||' - '||pctload, chr(10)) within group (order by sql_id,pctload desc) event_pct 
from a1
where sql_id is not null
group by session_id,sql_id,sql_opname,max_pga_alloc
), a3 as (
select session_id, sql_id, sql_opname, ash_cnt, pctload
  ,max_pga_alloc
  --,wclass_pct
  ,event_pct
  ,row_number() over(partition by session_id order by pctload desc) rn
from a2
)
select session_id, ash_cnt, pctload
  --,wclass_pct
  ,event_pct
  ,sql_id
  ,sql_opname
  ,max_pga_alloc
  ,coalesce(
    (select substr(ltrim(replace(sql_text,chr(10),' ')),1,60) from v$sql s where s.sql_id=a3.sql_id and rownum <=1),
    (select to_char(substr(ltrim(replace(sql_text,chr(10),' ')),1,60)) from dba_hist_sqltext s where s.sql_id=a3.sql_id and rownum <=1)
   )sql_text 
from a3 where rn <=5;


PROMPT ==========================================================================
prompt  SQL statistics from ASH 
PROMPT ==========================================================================

with t as
(
select
  oj.timestamp_start start_time
  --,oj.timestamp end_time
  ,decode(oj.out_status_id,3,sysdate,oj.timestamp) end_time
  ,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  ,oj.sid session_id
from
  k.out_job oj
where
  (oj.parent_task_id=&task_id or oj.id=&task_id)  
), s as(
select 
   (select max(snap_id) bsnap 
   from dba_hist_snapshot where end_interval_time < (select min(timestamp_start) from k.out_job oj where (oj.parent_task_id=&task_id or oj.id=&task_id))
   and dbid = (select dbid from v$database)
   ) bsnap,
   (select max(snap_id) esnap 
    from dba_hist_snapshot where end_interval_time < (select max(decode(oj.out_status_id,3,sysdate,oj.timestamp))+(2/24) from k.out_job oj where (oj.parent_task_id=&task_id or oj.id=&task_id))
    and dbid = (select dbid from v$database)
   ) esnap,
   dbid
from v$database
), a1 as(
select sql_id,sql_opname,sql_plan_hash_value plan_hash
  --,case when session_state = 'WAITING' then wait_class else session_state end wait_class
  ,case when session_state = 'WAITING' then wait_class||': '||event else session_state end event
  ,count(*) ash_cnt
  ,round(count(*)*100/sum(count(*)) over(),2) pctload
  ,min(sample_time) min_time
  ,max(sample_time) max_time
--from dba_hist_active_sess_history ash
from &ash_table ash
  &nohist join s on (ash.dbid=s.dbid and ash.snap_id between s.bsnap and s.esnap)
  join t on(ash.session_id=t.session_id and ash.sample_time between t.start_time and t.end_time)
where 'Y'=trim(upper('&disp_ash_sql'))
group by sql_id
  ,sql_opname,sql_plan_hash_value
  --,case when session_state = 'WAITING' then wait_class else session_state end
  ,case when session_state = 'WAITING' then wait_class||': '||event else session_state end
), a2 as (
select
  sql_id
  ,plan_hash
  ,min(min_time) min_time
  ,max(max_time) max_time
  ,sql_opname
  ,sum(ash_cnt) ash_cnt
  ,sum(pctload) pctload
  --,listagg(rpad(wait_class,13,' ')||': '||trim(to_char(pctload,'990D0'))||'%'||chr(10)) within group (order by pctload desc)  wclass_pct
  --,listagg(rpad(wait_class||': '||pctload, chr(10)) within group (order by sql_id,pctload desc) wclass_pct
  --,listagg(rpad(event,13,' ')||': '||trim(to_char(pctload,'990D0'))||'%'||chr(10)) within group (order by pctload desc)  event_pct
  --,listagg(event||' - '||pctload, chr(10)) within group (order by sql_id,pctload desc) event_pct
  --,rtrim(listagg(rpad(wait_class,14,' ')||': '||trim(to_char(pctload,'990D0'))||'%'||chr(10)) within group (order by pctload desc),chr(10))  wclass_pct
  --,listagg(rpad(wait_class||': '||pctload, chr(10)) within group (order by sql_id,pctload desc) wclass_pct
  ,rtrim(listagg(rpad(event,45,' ')||': '||trim(to_char(pctload,'990D0'))||'%'||chr(10)) within group (order by pctload desc),chr(10))  event_pct
  --,listagg(event||' - '||pctload, chr(10)) within group (order by sql_id,pctload desc) event_pct
from a1
where sql_id is not null
group by sql_id,sql_opname,plan_hash
), a3 as (
select sql_id, plan_hash, sql_opname, ash_cnt, pctload, min_time,max_time
  --,wclass_pct
  ,event_pct
  ,row_number() over(order by pctload desc) rn
from a2
)
select sql_id, plan_hash
  ,to_char(min_time,'MM/DD HH24:MI')||chr(10)||to_char(max_time,'MM/DD HH24:MI') min_max_time
  , ash_cnt, pctload
  --,wclass_pct
  ,event_pct
  ,sql_opname
  ,coalesce(
    (select substr(ltrim(replace(sql_text,chr(10),' ')),1,50) from v$sql s where s.sql_id=a3.sql_id and rownum <=1),
    (select to_char(substr(ltrim(replace(sql_text,chr(10),' ')),1,50)) from dba_hist_sqltext s where s.sql_id=a3.sql_id and rownum <=1)
   )sql_text
from a3 where rn <=10
order by pctload desc;




PROMPT ==========================================================================
prompt  SQL statistics from AWR
PROMPT ==========================================================================

col schema form A10
col module form A30
col action form A20
col ela form A16
with t as
(
select
  oj.timestamp_start start_date
  --,oj.timestamp end_date
  ,decode(oj.out_status_id,3,sysdate,oj.timestamp) end_date
  ,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  ,oj.sid session_id
  ,s.snap_id
  ,s.dbid
from
  k.out_job oj
  join dba_hist_snapshot s on(s.end_interval_time between timestamp_start and decode(oj.out_status_id,3,sysdate,oj.timestamp))
where
  (oj.parent_task_id=&task_id or oj.id=&task_id)  
  and 'Y' = upper(trim('&disp_awr_sql'))
), s as (
select min(snap_id) bsnap, max(snap_id) esnap, max(dbid) dbid from t
), a1 as(
select sql_id,count(*)
--from dba_hist_active_sess_history ash 
from &ash_table ash 
  &nohist join s on(ash.dbid=s.dbid and ash.snap_id between s.bsnap and s.esnap)
  join t on(ash.session_id=t.session_id and ash.sample_time between t.start_date and t.end_date)
where sql_id is not null
group by sql_id
order by count(*) desc
), t2 as (
select s.snap_id
  ,t.start_date,t.end_date
  ,case
    when (cast(end_date as date)-cast(end_interval_time as date))*24*60 > 5
      then lead(s.snap_id) over(order by s.snap_id)
    else
      s.snap_id
   end last_snap
  ,case
    when (cast(end_date as date)-cast(end_interval_time as date)) > 5 -- >interval '5' minute
      then lead(s.end_interval_time) over(order by s.snap_id)
    else
      s.end_interval_time
   end end_interval_time
from dba_hist_snapshot s left outer join t on s.snap_id=t.snap_id
--order by s.snap_id
), t3 as (
  select min(t2.snap_id) first_snap,max(t2.last_snap) last_snap
  from t2
  where start_date is not null
)
,sn1 as (
select
 s.sql_id
--,s.child_number child#
,s.parsing_schema_name schema
,s.module
,s.action
,s.plan_hash_value plan_hash
,sum(s.executions_delta) execs
,round(sum(s.cpu_time_delta)/1000000,2) as cpu_sec
,round(sum(s.elapsed_time_delta)/1000000,2) as ela_sec
,round(sum(s.ccwait_delta)/1000000,2) as concurr_sec
,round(sum(s.iowait_delta)/1000000,2) as io_wait_sec
,round(sum(s.physical_read_bytes_delta)/1024/1024) phy_read_mb
,round(sum(s.physical_write_bytes_delta)/1024/1024) phy_write_mb
,sum(s.rows_processed_delta) rows_total
from dba_hist_sqlstat s join dba_hist_snapshot snap using(snap_id,dbid,instance_number)
  join t3 on (snap_id between t3.first_snap and t3.last_snap)
  join a1 on (a1.sql_id=s.sql_id)
group by
s.sql_id
,s.parsing_schema_name
,s.module
,s.action
,s.plan_hash_value
)
select
  sql_id, schema
  --, module, action
  , plan_hash
  , execs
  , cast(numtodsinterval(ela_sec,'SECOND') as interval day(1) to second(3)) ela
  , round(ela_sec/decode(execs,0,1,execs),4) AS "Ela/exec(s)"
  , cpu_sec, concurr_sec, io_wait_sec
  , phy_read_mb read_mb, phy_write_mb write_mb, rows_total
  , (select to_char(substr(ltrim(replace(sql_text,chr(10),' ')),1,50)) from dba_hist_sqltext sq where sq.sql_id=sn1.sql_id and rownum <=1) sql_text
from sn1
order by ela_sec desc;




clear breaks
