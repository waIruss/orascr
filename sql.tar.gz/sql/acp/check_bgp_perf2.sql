set line 240 pagesize 100 verify off

col job_name form A35
col "% of DB Activity" form 999D00
col wait_class form A20
col module_ form A25
col blocking_jobs form A30
col sql_text form A60 print


def DT_FMT_ISO="YYYY-MM-DD HH24:MI"

col bdate new_val bdate noprint
col edate new_val edate noprint
select
  to_char(trunc(sysdate - (2/24),'HH24'),'&&DT_FMT_ISO') as bdate,
  to_char(sysdate,'&&DT_FMT_ISO') as edate
from dual;


prompt ===========================================================================
accept BGP_NUMBER prompt 'Enter BGP number to check [% = all | 911 | 989_6] (default: %): ' default '%'
accept ash_src prompt 'ASH source: H - dba_hist, A - v$active_sess (default: A): ' default 'A'
accept last_mins prompt 'Enter # of last minutes to analyze for v$active_ses (default: 10): ' default '10'
ACCEPT bdate  DEFAULT '&bdate'  PROMPT 'Enter start date for DBA_HIST_ as &&DT_FMT_ISO [&bdate]: '
ACCEPT edate  DEFAULT '&edate'  PROMPT 'Enter end date for DBA_HIST_ as &&DT_FMT_ISO [&edate]: '
prompt ===========================================================================


col ash_table new_val ash_table noprint
select decode(upper(trim('&ash_src')),'A','v$active_session_history','H','dba_hist_active_sess_history','dba_hist_active_sess_history') ash_table from dual;


break on job_name skip 1

with
jobs as (
  select session_id,actual_start_date,log_date,job_name
  from dba_scheduler_job_run_details
  where actual_start_date > trunc(sysdate-2)
    and job_name like 'AVQ$AAA_BGP_&BGP_NUMBER%'
  union all
  select rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate,job_name
  from dba_scheduler_running_jobs drj
    , v$scheduler_running_jobs rj
    , v$session s
  where drj.session_id=rj.session_id
    and rj.session_id=s.sid and rj.session_serial_num=s.serial#
    and drj.job_name like 'AVQ$AAA_BGP_&BGP_NUMBER%'
  union all
  select s.sid||','||s.serial# session_id,s.logon_time start_date, sysdate , client_info job_name
  from v$session s
  where client_info like 'BGP_OS.&BGP_NUMBER%'
),
ash as (
select
  --substr(job_name,1,15) job_name
  jobs.job_name
  ,jobs.session_id
  ,nvl(ash.wait_class,'CPU') wait_class
  --,regexp_substr(module,'(\[)(\d*)(\])',1,1,'i',2)
  ,module
  ,sql_id
  ,count(*) cnt
  ,sum(count(*)) over() cnt_all
  ,min(sample_time) min_sample_time,max(sample_time) max_sample_time
  ,j2.job_name blocking_job
from &ash_table ash
   join jobs
  on (ash.session_id||','||ash.session_serial#=jobs.session_id and ash.sample_time between jobs.actual_start_date and jobs.log_date)
  left outer join jobs j2 on(ash.blocking_session||','||ash.blocking_session_serial#=j2.session_id)
where ( sample_time > sysdate - interval '&last_mins' minute or upper(trim('&ash_src')) = 'H')
  and ( sample_time between to_date('&bdate','&DT_FMT_ISO') and  to_date('&edate','&DT_FMT_ISO') or upper(trim('&ash_src')) = 'A')
  --and jobs.job_name like 'AVQ$AAA_BGP_&BGP_NUMBER'
group by
  jobs.job_name
  ,jobs.session_id
  ,nvl(ash.wait_class,'CPU')
  ,module
  ,sql_id
  ,j2.job_name
),
ash2 as (
select
  job_name||' ['||session_id||']' job_name
  ,listagg(substr(blocking_job,9,10),',') blocking_jobs
  ,wait_class
  ,module
  ,sql_id
  ,round(sum(cnt)/cnt_all*100,2) pct_of_db_load
  ,sum(sum(cnt)/cnt_all) over(partition by job_name||' ['||session_id||']')*100 ord
from ash
group by
  job_name||' ['||session_id||']'
  --,blocking_job
  ,wait_class
  --,module_type
  --,cnt
  ,cnt_all
  ,module
  ,sql_id
order by
  --to_number(substr(job_name,17,2))
  job_name
  , 4 desc
)
select
  job_name, module_, wait_class, blocking_jobs, sql_id, "% of Activity"
  ,coalesce(
    (select substr(ltrim(replace(sql_text,chr(10),' ')),1,60) from v$sql s where s.sql_id=a3.sql_id and rownum <=1),
    (select to_char(substr(ltrim(replace(sql_text,chr(10),' ')),1,60)) from dba_hist_sqltext s where s.sql_id=a3.sql_id and rownum <=1)
   ) sql_text
from (
select job_name
  ,module module_
  ,wait_class
  ,blocking_jobs
  ,sql_id
  ,pct_of_db_load "% of Activity"
  ,row_number() over(partition by job_name order by pct_of_db_load desc) rn
from ash2
order by ord desc, pct_of_db_load desc
) a3 where rn <=5;


