set termout off
set trimspool on
set linesize 300
set verify off
set heading off feedback off

whenever sqlerror exit
whenever oserror exit

def DT_FMT_REP="Mon-DD"
def DT_FMT_ISO="YYYY-MM-DD HH24:MI"
def DT_FMT_ISO_S="YYYY-MM-DD"
def DT_FMT_ASH="MM/DD/YY HH24:MI"

alter session set nls_date_format = 'YYYY/MM/DD HH24:MI:SS';
alter session set nls_timestamp_format = 'YYYY/MM/DD HH24:MI:SS.FF6';

col bdate new_val bdate noprint
col edate new_val edate noprint
col today new_val today noprint
col dbname new_val dbname noprint
col out_dir new_val out_dir noprint



select
  to_char(sysdate-2,'&DT_FMT_ISO') as bdate
  ,to_char(sysdate,'&DT_FMT_ISO') as edate
  ,to_char(sysdate,'YYYYMMDD') today
  ,sys_context('userenv','db_name') dbname
from dual;


set termout on

prompt ==================================================================
ACCEPT acp_user  PROMPT 'Enter ACP username who started Ex-Post tasks [IMED_...]: '
ACCEPT bdate  DEFAULT '&bdate'  PROMPT 'Enter start date as &&DT_FMT_ISO [&bdate]: '
ACCEPT edate  DEFAULT '&edate'  PROMPT 'Enter end date as &&DT_FMT_ISO [&edate]: '
ACCEPT email_addr  DEFAULT 'apobank-polanddbasupport@dxc.com'  PROMPT 'Enter e-mail address to send generated extracts [apobank-polanddbasupport@dxc.com]: '
ACCEPT out_dir  DEFAULT '/home/oracle/'   PROMPT 'Enter output directory for reports [ /home/oracle/ ]: '
prompt ==================================================================

--def start_time="to_date('&&bdate','&&DT_FMT_ISO')"
--def end_time="to_date('&&edate','&&DT_FMT_ISO')"
def start_time="&bdate"
def end_time="&edate"
set heading on

prompt Generating ex-post_pga.csv, please wait...
set termout off
--set echo on
host mkdir -p &&out_dir


spool &&out_dir./ex-post_pga.csv
set markup csv on
with t1 as (
select
  ttv.user_id task_template
  ,oj.id task_id
  --,oj.parent_task_id
  --,oj.userstamp username
  ,oj.timestamp_start start_time
  , oj.timestamp end_time
  --, oj.parallel_exec_nr_prc prl_proc
  --,case when oj.out_status_id=3 then
  --  cast(sysdate-oj.timestamp_start  as interval day(1) to second(0))
  -- else
  --  cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0))
  --end exec_time
  ,k.task_def#.task#name(oi.obj_id) task_name
  --,s.name status
  ,oj.sid session_id
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
 oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
  and oj.timestamp_ins >=  to_date('&start_time','&&DT_FMT_ISO')
  and upper(oj.userstamp)=upper(trim('&acp_user'))    --user who run Ex-post
order by oj.id
)
,j as (
select substr(job_name,13,3) bgp
   --,session_id
   ,to_number(regexp_substr(session_id,'(\d+)(,)(\d+)',1,1,'i',1)) session_id,to_number(regexp_substr(session_id,'(\d+)(,)(\d+)',1,1,'i',3)) session_serial#
   ,start_time,end_time from 
   (
   select job_name,session_id,actual_start_date start_time,log_date end_time
   from dba_scheduler_job_run_details where job_name like 'AVQ$AAA_BGP_915%' 
   and (log_date >= to_date('&start_time','&DT_FMT_ISO') or actual_start_date >= to_date('&start_time','&DT_FMT_ISO'))
   union all
   select job_name,rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate
   from dba_scheduler_running_jobs drj
      , v$scheduler_running_jobs rj
      , v$session s
   where drj.session_id=rj.session_id
      and rj.session_id=s.sid and rj.session_serial_num=s.serial#
      and drj.job_name like 'AVQ$AAA_BGP_915%'
   )
)
, t2 as (
select task_id,task_template,task_name,session_id,null as session_serial#,start_time,end_time from t1 
union all
select -1,'BGP_915','BGP_915',session_id, session_serial#,start_time,end_time from j
)
--,lg as (select distinct l.task_id,l.session_id,l.session_serial# from k.log l, t1 where l.task_id=t1.task_id)
,ash1 as(
select
  sample_time
  ,count(*)  cnt
  ,nvl2(t2.task_id,'Ex-post','Other') task_type
  ,t2.task_name
  ,sum(pga_allocated) pga_allocated
from dba_hist_active_sess_history ash
  left outer
  join t2 on (ash.session_id=t2.session_id and ash.sample_time between t2.start_time and t2.end_time)
  --left outer join dba_scheduler_job_run_details jrd on ash.sample_time between jrd.actual_start_date and jrd.log_date and ash.session_id||','||ash.session_serial# = jrd.session_id
  --left outer join lg on ash.session_id=lg.session_id and ash.session_serial#=lg.session_serial#
where sample_time between to_date('&start_time','&DT_FMT_ISO') and to_date('&end_time','&DT_FMT_ISO')
and (dbid,snap_id) in(select dbid,snap_id from dba_hist_snapshot s where s.end_interval_time between to_date('&start_time','&DT_FMT_ISO')-(2/24) and to_date('&end_time','&DT_FMT_ISO')+(2/24))
group by
  sample_time
  --,nvl2(coalesce(t2.task_id,lg.task_id),'Ex-post','Other')
  ,nvl2(t2.task_id,'Ex-post','Other') 
  ,t2.task_name
--order by sample_time, count(*) desc
)
select /*+ parallel(4) */
  to_char(trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 15 ) * 15 , 'minute'),'YYYY-MM-DD HH24:MI') snap_time
  ,task_type
  ,task_name
  ,max(round(pga_allocated/1024/1024/1024,2)) pga_gb
  --6 snaps/minute, interval 15 minute
  ,round(sum(cnt)/6/15,2) avg_aas
from ash1
group by
  to_char(trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 15 ) * 15 , 'minute'),'YYYY-MM-DD HH24:MI')
  ,task_type
  ,task_name
order by 1,2;


spool off
set markup csv off
set termout on
prompt Generating ex-post_ash.csv, please wait...
set termout off
set markup csv on

spool &&out_dir./ex-post_ash.csv
with t1 as (
select
  ttv.user_id task_template
  ,oj.id task_id
  --,oj.parent_task_id
  --,oj.userstamp username
  ,oj.timestamp_start start_time
  , oj.timestamp end_time
  --, oj.parallel_exec_nr_prc prl_proc
  --,case when oj.out_status_id=3 then
  --  cast(sysdate-oj.timestamp_start  as interval day(1) to second(0))
  -- else
  --  cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0))
  --end exec_time
  ,k.task_def#.task#name(oi.obj_id) task_name
  --,s.name status
  ,oj.sid session_id
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
 oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
  and oj.timestamp_ins >=  to_date('&start_time','&&DT_FMT_ISO')
  and upper(oj.userstamp)=upper(trim('&acp_user'))    --user who run Ex-post
--order by oj.id
)
,j as (
select substr(job_name,13,3) bgp
   --,session_id
   ,to_number(regexp_substr(session_id,'(\d+)(,)(\d+)',1,1,'i',1)) session_id,to_number(regexp_substr(session_id,'(\d+)(,)(\d+)',1,1,'i',3)) session_serial#
   ,start_time,end_time from 
   (
   select job_name,session_id,actual_start_date start_time,log_date end_time
   from dba_scheduler_job_run_details where job_name like 'AVQ$AAA_BGP_915%' 
   and (log_date >= to_date('&start_time','&DT_FMT_ISO') or actual_start_date >= to_date('&start_time','&DT_FMT_ISO'))
   union all
   select job_name,rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate
   from dba_scheduler_running_jobs drj
      , v$scheduler_running_jobs rj
      , v$session s
   where drj.session_id=rj.session_id
      and rj.session_id=s.sid and rj.session_serial_num=s.serial#
      and drj.job_name like 'AVQ$AAA_BGP_915%'
   )
)
, t2 as (
select task_id,task_template,task_name,session_id,null as session_serial#,start_time,end_time from t1 
union all
select -1,'BGP_915','BGP_915',session_id, session_serial#,start_time,end_time from j
)
--,lg as (select distinct l.task_id,l.session_id,l.session_serial# from k.log l, t1 where l.task_id=t1.task_id)
,ash1 as(
select
  sample_time
  --,sql_id
  ,nvl(wait_class,session_state) wait_class
  ,count(*)  cnt
  --,nvl2(coalesce(t2.task_id,lg.task_id),'Ex-post','Other') task_type
  ,nvl2(t2.task_id,'Ex-post','Other') task_type
  ,t2.task_name
  --,substr(job_name,9,7) bgp
  ,sum(pga_allocated) pga_allocated
from dba_hist_active_sess_history ash
  --left outer
  join t2 on (ash.session_id=t2.session_id and ash.sample_time between t2.start_time and t2.end_time)
  --left outer join dba_scheduler_job_run_details jrd on ash.sample_time between jrd.actual_start_date and jrd.log_date and ash.session_id||','||ash.session_serial# = jrd.session_id
  --left outer join lg on ash.session_id=lg.session_id and ash.session_serial#=lg.session_serial#
where sample_time between to_date('&start_time','YYYY-MM-DD HH24:MI') and to_date('&end_time','YYYY-MM-DD HH24:MI')
   and (dbid,snap_id) in(select dbid,snap_id from dba_hist_snapshot s where s.end_interval_time between to_date('&start_time','YYYY-MM-DD HH24:MI')-(2/24) and to_date('&end_time','YYYY-MM-DD HH24:MI')+(2/24))
group by
  sample_time
  ,sql_id
  ,nvl(wait_class,session_state)
  --,nvl2(coalesce(t2.task_id,lg.task_id),'Ex-post','Other')
  ,nvl2(t2.task_id,'Ex-post','Other') 
  --,substr(job_name,9,7)
  ,t2.task_name
--order by sample_time, count(*) desc
)
, ash2 as (
select /*+ parallel(4) */
  to_char(trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 15 ) * 15 , 'minute'),'YYYY-MM-DD HH24:MI') snap_time
  --,sql_id
  ,wait_class
  ,task_type
  ,task_name
  ,max(round(pga_allocated/1024/1024/1024,2)) pga_gb
  --6 snaps/minute, interval 15 minute
  ,round(sum(cnt)/6/15,2) avg_aas
  --,trim(replace(replace(replace(
  -- coalesce(
  --  (select substr(sql_text,1,100) from v$sql s where s.sql_id=ash1.sql_id and rownum<=1)
  --  ,(select to_char(substr(sql_text,1,100)) from dba_hist_sqltext s where s.sql_id=ash1.sql_id and rownum<=1)
  --)
  --,chr(10),' '),'  ',' '),'"',' ')) sql_text
from ash1
group by
  to_char(trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 15 ) * 15 , 'minute'),'YYYY-MM-DD HH24:MI')
  --,sql_id
  ,wait_class
  ,task_type
  ,task_name
--order by 1,2
)
select snap_time, wait_class, task_type, task_name, pga_gb, avg_aas
from ash2
order by snap_time,avg_aas desc;

spool off
set markup csv off
set termout on
prompt Generating ex-post_cpu.csv, please wait...
set termout off
set markup csv on

spool &&out_dir./ex-post_cpu.csv
select
  to_char(end_time,'YYYY-MM-DD HH24:MI') time_
  ,sum(round((value/100)/threads,4))*100 server_cpu_usage  
  ,cores
  ,threads cpu_count
from dba_hist_sysmetric_history, (select cpu_core_count_current cores,cpu_count_current threads from v$license) cpu
where metric_name in('Background CPU Usage Per Sec','CPU Usage Per Sec')
  and group_id=2
  and end_time between to_date('&start_time','YYYY-MM-DD HH24:MI') and to_date('&end_time','YYYY-MM-DD HH24:MI')
group by
  end_time
  ,cores,threads
order by end_time;
spool off
set markup csv off
set termout on

set define "^"
prompt ==================================================================
prompt Generated reports in &&out_dir
prompt ==================================================================
host cd ^out_dir && zip ex-post.zip ex-post_cpu.csv ex-post_pga.csv ex-post_ash.csv
set define "&"
host ls -ltr &&out_dir./ex-post_cpu.csv &&out_dir./ex-post_pga.csv &&out_dir./ex-post_ash.csv &&out_dir./ex-post.zip
prompt ==================================================================
prompt Sending reports via email
prompt ==================================================================
host echo "Ex-Post reports - &&dbname"|mail -a &&out_dir./ex-post.zip -s "Ex-Post reports &&dbname" &&email_addr

