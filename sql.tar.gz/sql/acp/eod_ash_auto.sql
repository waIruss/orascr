set trimspool on
set feedback off linesize 10000
set termout off
set echo off
set pagesize 0
set verify off

def days_back=&1
def outfile=&2

set markup csv on
spool &outfile

with a1 as (
select /*+ leading(a) */ sample_time
  ,case
    when event is null   then 'CPU'
    when event in ('latch: cache buffers chains'
                  ,'enq: UL - contention'
                  ,'buffer busy waits'
                  )      then event
    when event like '%latch%' then 'latch'
    when event like '%mutex%' then 'mutex'
    when wait_class in ('Administrative'
                        ,'Application'
                        ,'Cluster'
                        ,'Commit'
                        ,'Concurrency'
                        ,'Configuration'
                        ,'Idle'
                        ,'Network'
                        ,'Queueing'
                        ,'Scheduler'
                        ,'System I/O'
                        ,'User I/O'
                        ,'Other'
                        ) then wait_class
    else 'Unacc'
  end wait_class
  ,count(*) aas
from dba_hist_active_sess_history a
where (dbid,snap_id) in (select dbid,snap_id from dba_hist_snapshot where begin_interval_time between trunc(sysdate-1-&days_back) + interval '11' hour and trunc(sysdate-&days_back) + interval '14' hour)
  and a.sample_time between trunc(sysdate-1-&days_back) + interval '12' hour and trunc(sysdate-&days_back) + interval '12' hour  
group by sample_time
  ,case
    when event is null  then 'CPU'
    when event in ('latch: cache buffers chains'
                  ,'enq: UL - contention'
                  ,'buffer busy waits'
                  )      then event
    when event like '%latch%' then 'latch'
    when event like '%mutex%' then 'mutex'
    when wait_class in ('Administrative'
                        ,'Application'
                        ,'Cluster'
                        ,'Commit'
                        ,'Concurrency'
                        ,'Configuration'
                        ,'Idle'
                        ,'Network'
                        ,'Queueing'
                        ,'Scheduler'
                        ,'System I/O'
                        ,'User I/O'
                        ,'Other'
                        ) then wait_class
    else 'Unacc'
  end
)
select to_char(sample_time,'YYYY-MM-DD HH24:MI') sample_ival, wait_class, min(aas) min_as, round(avg(aas),2)  avg_as, max(aas) max_as  
from a1
group by to_char(sample_time,'YYYY-MM-DD HH24:MI'), wait_class
order by 1;


spool off
set markup csv off
exit;
