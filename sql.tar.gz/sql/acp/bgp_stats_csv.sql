set trimspool on
set feedback off linesize 10000
set termout off
set echo off
set pagesize 0
set verify off

col global_name new_val db_n noprint
col inst_name new_val inst_name noprint
col instance_number new_val inst_num noprint
col repdate new_val repdate noprint
select global_name from global_name;
select instance_name inst_name,trim(instance_number) as instance_number from v$instance;

def last_days=&1
select to_char(trunc(sysdate-&last_days),'YYYYMMDD') repdate from dual;
def CSVFILE=bgp_activity_&&db_n._&repdate..csv

set markup csv on
spool &CSVFILE

with bgp2 as (
  select /*+ parallel(2) */ to_number(replace(substr(session_id,1,instr(session_id,',')-1),chr(0),'')) session_sid
    ,to_number(replace(substr(session_id,instr(session_id,',')+1,length(session_id)),chr(0),'')) session_serial#
    ,actual_start_date started
    ,log_date stopped
    ,job_name
    ,substr(job_name,9,7) bgp
  from dba_scheduler_job_run_details
  where job_name like 'AVQ$AAA_BGP_%'
    --and trim(session_id) is not null
    and session_id != chr(0)
    and (log_date >= trunc(sysdate-&last_days) or actual_start_date >= trunc(sysdate-&last_days))
  union all
  select rj.session_id,rj.session_serial_num session_id,s.logon_time start_date,sysdate,job_name, substr(job_name,9,7) bgp
  from dba_scheduler_running_jobs drj
    , v$scheduler_running_jobs rj
    , v$session s
  where drj.session_id=rj.session_id
    and rj.session_id=s.sid and rj.session_serial_num=s.serial#
    and drj.job_name like 'AVQ$AAA_BGP_%'
  union all
  select s.sid,s.serial# ,s.logon_time start_date, sysdate , client_info job_name,'BGP_'||substr(client_info,8,3) bgp
  from v$session s
  where client_info like 'BGP_OS.%'
)
,ash as (
  select /*+ parallel(2) */
    sample_time
    ,nvl(bgp2.bgp,ash.program) bgp
    ,nvl(ash.wait_class,'ON CPU') wait_class
  from  bgp2, dba_hist_active_sess_history ash
  where ash.session_id = bgp2.session_sid and ash.session_serial# = bgp2.session_serial#
    and ash.sample_time between bgp2.started and bgp2.stopped
    and trunc(ash.sample_time) = trunc(sysdate - &last_days)
  union all
  select /*+ parallel(2) */
    sample_time
    ,nvl(bgp2.bgp,ash.program) bgp
    ,nvl(ash.wait_class,'ON CPU') wait_class
  from  bgp2, dba_hist_active_sess_history ash
  where ash.qc_session_id = bgp2.session_sid and ash.qc_session_serial# = bgp2.session_serial#
    and ash.sample_time between bgp2.started and bgp2.stopped
    and trunc(ash.sample_time) = trunc(sysdate - &last_days)
  union all
  select /*+ parallel(2) */
    sample_time
    ,decode(ash.program,'IntegrationServer.exe','IntegrationServer.exe','Other') program
    ,nvl(ash.wait_class,'ON CPU') wait_class
  from dba_hist_active_sess_history ash
  where trunc(sample_time) = trunc(sysdate - &last_days)
    and program = 'IntegrationServer.exe'
)
,s1 as (
  select count(distinct sample_time) total_samples
    ,trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 10 ) * 10 , 'minute') sample_time
  from ash
  group by trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 10 ) * 10 , 'minute')
)
,ash2 as (
select sample_time,bgp,wait_class,count(*) cnt
from ash
group by bgp
  ,wait_class
  ,sample_time
)
, ash3 as (
select
  trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 10 ) * 10 , 'minute') sample_time
  ,bgp
  ,wait_class
  ,sum(cnt) cnt
  ,round(avg(cnt)) as avg_active_bgp
from ash2
group by trunc(sample_time, 'hh24') + numtodsinterval( floor ( extract ( minute from sample_time ) / 10 ) * 10 , 'minute')
  ,bgp
  ,wait_class
 order by sample_time
)
select
  instance_name
  ,to_char(ash3.sample_time,'YYYY-MM-DD HH24:MI') sample_time
  ,bgp,wait_class
  ,round(sum(cnt)/s1.total_samples,0) avg_active_bgp
from ash3, s1,v$instance
where ash3.sample_time=s1.sample_time
group by
  instance_name
  ,ash3.sample_time,bgp
  ,s1.total_samples
  ,wait_class
having sum(cnt)/s1.total_samples >=1
order by sample_time;

spool off
set markup csv off
exit;

