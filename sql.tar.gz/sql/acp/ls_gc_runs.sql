set line 250 pagesize 200 verify off

accept gc_type prompt 'Enter GC type [std|maint|excl|%]  (default: %): ' default '%'
accept last_days prompt 'Enter last days to show (defautl: 30): ' default 30

col intl_id form A10
col gc_run_status form A15
col start_time form A21
col end_time form A21
col elapsed form A16


select r.id run_id,t.intl_id 
   ,to_char(r.start_time,'YYYY-MM-DD Dy HH24:MI') start_time 
   ,to_char(r.end_time,'YYYY-MM-DD Dy HH24:MI') end_time
  , cast(r.end_time-r.start_time as interval day(1) to second(0)) elapsed
  ,s.name gc_run_status
  ,r.all_item_cnt, executed_item_cnt, prcd_item_cnt ,r.err_cnt
  --,ir.start_time,ir.end_time, ir.end_time-ir.start_time ela
  --,cgi.intl_id,cgi.name,cgi.stmt,cgi.has_soft_timeout
  --,ir.err_cnt,ir.sid,ir.task_id ,s2.name item_status
from k.code_garbcol_type t
  , k.garbcol_run r
  , k.code_garbcol_status s
where t.id=r.garbcol_type_id
  and r.garbcol_status_id=s.id
  and r.start_time > trunc(sysdate-&last_days)
  and t.intl_id like trim('&gc_type')
order by r.start_time desc ;

undef gc_type
undef last_days
