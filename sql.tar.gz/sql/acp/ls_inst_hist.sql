set line 240 pagesize 100
col release form A20
col pkg_kind form a10
col app_name form A8
col content form A30
col client form A9
col REPOSITORY_PKG_IDS form A80



with s1 as (
select distinct ia.install_id,to_char(ia.timestp_ins,'YYYY-MM-DD HH24:MI:SS') timestp_ins
   ,ip.repository_pkg_id
   ,ic.intl_id
   ,ip.release
   ,ip.extl_name
   ,cipk.name pkg_kind
   ,iap.name app_name
   , ips.src_type
   , count(*) over(partition by ia.install_id, ia.timestp_ins, intl_id, release,iap.name,ips.src_type)  cnt
from x.install_action ia
   ,x.install_pkg ip
   ,x.install_clt ic
   ,x.code_install_pkg_kind cipk
   ,x.install_app iap
   ,x.install_pkg_key ipk
   ,x.install_pkg_src ips
   ,x.install_file if
where 1=1
and ia.timestp_ins > sysdate - 60
and ia.install_id=ip.install_id
and ic.id=ip.install_clt_id
and ip.install_pkg_kind_id = cipk.id
and ip.install_app_id=iap.id
and ip.install_pkg_key_id=ipk.id
and ip.id=ips.install_pkg_id
and ips.install_file_id=if.id(+)
order by to_char(ia.timestp_ins,'YYYY-MM-DD HH24:MI:SS') desc
)
select 
   install_id
   , timestp_ins
   , intl_id client
   , release   
   , app_name
   , listagg(distinct src_type||': '||(cnt),chr(10) on overflow truncate '...') within group (order by src_type) content
   , listagg(distinct repository_pkg_id,', ' on overflow truncate '...') within group(order by repository_pkg_id) repository_pkg_ids
from s1
group by install_id, timestp_ins, intl_id, release, app_name
order by timestp_ins desc;
