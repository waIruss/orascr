set line 230
set pagesize 100
set verify off


accept oracle_user prompt 'Enter Avaloq username: '

col name form A30 wor
col oracle_user form A30 wor
col email form A30
col descn form A100 wor
with u(id,name,oracle_user,user_type_id,email,sec_owner_id, auth_user_id) as
(select id,name,oracle_user,user_type_id,email,sec_owner_id, auth_user_id from k.sec_user
  where upper(oracle_user)=trim(upper('&oracle_user'))
  or auth_user_id in(select id from k.sec_user where upper(oracle_user)=trim(upper('&oracle_user')))
  or sec_owner_id in(select id from k.sec_user where upper(oracle_user)=trim(upper('&oracle_user')))
union all
select u2.id,u2.name,u2.oracle_user,u2.user_type_id,u2.email,u2.sec_owner_id, u2.auth_user_id from k.sec_user u2, u where u2.id=u.auth_user_id)
, uu(id,name,oracle_user,user_type_id,email,sec_owner_id, auth_user_id) as
(select id,name,oracle_user,user_type_id,email,sec_owner_id, auth_user_id from u
union all
select u2.id,u2.name,u2.oracle_user,u2.user_type_id,u2.email,u2.sec_owner_id, u2.auth_user_id from k.sec_user u2, uu where u2.id=uu.sec_owner_id)
select distinct uu.id, uu.name, oracle_user,email,ut.descn
from uu, k.code_user_type ut
where uu.user_type_id=ut.id
order by id;

