set heading off
set verify off
set feedback off
set echo off
set termout off
set line 200
set pagesize 0

spool &1 append

def bgp_number="%"
def last_mins=15
with
jobs as (
  select session_id,actual_start_date,log_date,job_name
  from dba_scheduler_job_run_details
  where log_date > trunc(sysdate-1)
    and job_name like 'AVQ$AAA_BGP_&BGP_NUMBER%'
  union all
  select rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate,job_name
  from dba_scheduler_running_jobs drj
    , v$scheduler_running_jobs rj
    , v$session s
  where drj.session_id=rj.session_id
    and rj.session_id=s.sid and rj.session_serial_num=s.serial#
    and drj.job_name like 'AVQ$AAA_BGP_&BGP_NUMBER%'
  union all
  select s.sid||','||s.serial# session_id,s.logon_time start_date, sysdate , client_info job_name
  from v$session s
  where client_info like 'BGP_OS.&BGP_NUMBER%'
),
ash as (
select
  substr(job_name,1,15) job_name
  ,nvl(ash.wait_class,'CPU') wait_class
  ,count(*) cnt
  ,sum(count(*)) over() cnt_all
from v$active_session_history ash
  left outer join jobs
  on (ash.session_id||','||ash.session_serial#=jobs.session_id and ash.sample_time between jobs.actual_start_date and jobs.log_date)
where sample_time > sysdate - interval '&last_mins' minute
group by substr(job_name,1,15)
  ,nvl(ash.wait_class,'CPU')
),
ash2 as (
  select job_name,avg(active_bgp) active_bgp
  from (
    select
      sample_time
      ,substr(job_name,1,15) job_name
      ,count(*) active_bgp
    from v$active_session_history ash
      left outer join jobs
        on (ash.session_id||','||ash.session_serial#=jobs.session_id and ash.sample_time between jobs.actual_start_date and jobs.log_date)
    where sample_time > sysdate - interval '&last_mins' minute
    group by sample_time,substr(job_name,1,15)
  ) group by job_name
)
,ash3 as (
select
  ash.job_name
  ,ash.wait_class
  ,round(avg(ash2.active_bgp)) avg_active_bgp
  ,round(sum(cnt)/cnt_all*100,2) pct_of_db_load
  ,round(sum(cnt)/sum(sum(cnt)) over(partition by ash.job_name)*100,2) pct_of_waits_in_bgp
from ash, ash2
where ash.job_name=ash2.job_name
group by (ash.job_name,wait_class,cnt_all)
order by pct_of_db_load desc
)
,bs as (
  select b.obj_id,active_bgp started_bgps,to_number(regexp_substr(dflt_instn_cnt,'[0-9]+')) def_cnt
    ,active_bgp-regexp_substr(dflt_instn_cnt,'[0-9]+') extra_bgp_started
  from k.obj_bgp ob, (select obj_id,count(*) active_bgp from k.obj_bgp_instn where session_id is not null group by obj_id order by active_bgp desc) b
  where ob.obj_id=b.obj_id
)
select
  --job_name
  '"'||instance_name||'",'||
  '"'||to_char(sysdate,'YYYY-MM-DD HH24:MI')||'",'||
 '"'||case when job_name like 'AVQ$AAA%' then substr(job_name,9,7)
  when job_name like 'BGP_OS%' then 'BGP_'||substr(job_name,8,3)
  end||'",'||
  avg_active_bgp||','||
  trim(to_char(sum(pct_of_db_load) over (partition by job_name),'990D00'))||',"'||
  wait_class||'",'||
  trim(to_char(pct_of_waits_in_bgp,'990D00'))||','||
  (select started_bgps from bs where regexp_substr(ash3.job_name,'[0-9]+') = bs.obj_id)||','||
  (select def_cnt from bs where regexp_substr(ash3.job_name,'[0-9]+') = bs.obj_id)
from ash3, v$instance
--where avg_active_bgp > 2
order by avg_active_bgp desc;


spool off
exit;

