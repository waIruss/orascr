set line 230
set pagesize 200
set verif off
col prcq_key form A30
col prcq_name form A80

accept bgp_num  prompt 'Enter BGP number (default: %): ' default '%'
accept prcq_id  prompt 'Enter PRCQ number (default: %): ' default '%'


select obj_1_id bgp, obj_2_id prcq_id, key_val prcq_key, oi.name prcq_name
from k.obj_rel, k.obj_key k, k.obj_name_intl oi
where obj_rel_type_id=100 and obj_1_id in(select obj_id from k.obj_bgp where obj_id like trim('&bgp_num'))
and k.obj_id=obj_2_id
and obj_2_id=oi.obj_id
and obj_2_id like trim('&prcq_id')
order by bgp,prcq_id;

undef bgp_num
undef prcq_id

