set line 240 pagesize 100 verify off
col job_name form A20
col "DB load %" form 9990D00
col waits_by_wclass form A30
col bgp_setup form A20
col status form A20
col wait_class form A15
col server_cpu_usage form 9990D0 heading "Server |CPU util. %"
set feedback off

--accept last_mins prompt 'Enter # of last minutes to analyze  (default: 10): ' default '10'
--accept BGP_NUMBER prompt 'Enter BGP number to check [% = all | 911 | 989_6] (default: %): ' default '%'

def last_mins=10
def BGP_NUMBER="%"
spool &1


prompt ===========================================================================
prompt = Server CPU utilization
prompt ===========================================================================
select
  to_char(end_time,'YYYY-MM-DD HH24:MI') time_
  ,sum(round((value/100)/threads,4))*100 server_cpu_usage
  ,case
    when sum(round((value/100)/threads,4))*100 > 90 then 'Alarm'
    when sum(round((value/100)/threads,4))*100 > 70 then 'Warning'
    else 'OK'
   end status
  ,threads cpu_count
from v$sysmetric_history, (select cpu_core_count_current cores,cpu_count_current threads from v$license) cpu
where metric_name in('Background CPU Usage Per Sec','CPU Usage Per Sec')
  and group_id=2
  and end_time > sysdate - interval '&last_mins' minute
group by
  end_time
  ,cores,threads
order by end_time desc;

prompt ***********************************************************
prompt Thresholds for CPU utilzation:
prompt 70% - Warning
prompt 90% - Alarm
prompt ***********************************************************
prompt
prompt


prompt ===========================================================================
prompt = Current database utilization
prompt ===========================================================================
with m as (
select end_time,wait_class,aas
  ,sum(aas) over(partition by end_time) total_aas
  --,rpad(' ',ratio_to_report(aas) over()*50,'*') chart
  ,round(ratio_to_report(aas) over()*100,2) pctload
  ,threads
  ,cores
from
(
select
  end_time
  ,decode(wait_class,'Application','Application',wait_class) wait_class
  ,round((wc.time_waited)/intsize_csec,2) aas
from v$waitclassmetric wc join v$system_wait_class using(wait_class#)
where wait_class <> 'Idle'
union all
select
  end_time
  ,decode(metric_name,'Background CPU Usage Per Sec','DB CPU','CPU Usage Per Sec','DB CPU') metric_name
  ,round(sum(value)/100,2)
from v$sysmetric
where metric_name in('Background CPU Usage Per Sec','CPU Usage Per Sec')
  and group_id=2
group by end_time,decode(metric_name,'Background CPU Usage Per Sec','DB CPU','CPU Usage Per Sec','DB CPU')
order by aas desc
) w,(select cpu_core_count_current cores,cpu_count_current threads from v$license) cpu
)
select
  to_char(end_time,'YYYY-MM-DD HH24:MI') time_
  ,wait_class
  ,aas avg_active_sess
  --,round(total_aas/threads*100,2)
  ,case
    when wait_class in('Application','Concurrency') then
      case
        when total_aas/threads*100 > 30 /* AAS vs CPU count ration at least 1:10*/ and  aas/(select sum(aas) from m where wait_class in ('DB CPU','User I/O')) > 1 then 'Alarm'
        when total_aas/threads*100 > 10 /* AAS vs CPU count ration at least 1:10*/ and  aas/(select sum(aas) from m where wait_class in ('DB CPU','User I/O')) > .5 then 'Warning'
        when total_aas/threads*100 > 10 /* AAS vs CPU count ration at least 1:10*/ and  aas/(select sum(aas) from m where wait_class in ('DB CPU','User I/O')) > .2 then 'Minor imperfections'
        else 'OK'
      end
    when wait_class = 'DB CPU' then
      case
        when aas/threads > 0.7 then 'Warning'
        when aas/threads > 0.9 then 'Alarm'
        else 'OK'
      end
    else
      '-n/a-'
  end status
  --,cores
from m
order by 3 desc
fetch first 5 rows only;


prompt ***********************************************************
prompt Thresholds for DB utilization:
prompt CPU - 70% - Warning, 90% - Alarm
prompt Alarm - Active Sess > 30% of CPU count and no. of sessions waiting for Application(locks) or Concurrenycy > sess. count on CPU and I/O
prompt Warning - Active Sess > 10% of CPU count and no. of sessions waiting for Application(locks) or Concurrenycy > 50% of sess. count on CPU and I/O
prompt Minor imperfection - Active Sess > 10% of CPU count and no. of sessions waiting for Application(locks) or Concurrenycy > 20% of sess. count on CPU and I/O
prompt ***********************************************************
prompt
prompt

prompt ===========================================================================
prompt = BGP details
prompt ===========================================================================

--check all BGPs or selected one
--def BGP_NUMBER="%"
--def BGP_NUMBER=516

compute sum of avg_active_bgp on report
break on report

with
jobs as (
  select session_id,actual_start_date,log_date,job_name
  from dba_scheduler_job_run_details
  where log_date > trunc(sysdate-1)
    and job_name like 'AVQ$AAA_BGP_&BGP_NUMBER%'
  union all
  select rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate,job_name
  from dba_scheduler_running_jobs drj
    , v$scheduler_running_jobs rj
    , v$session s
  where drj.session_id=rj.session_id
    and rj.session_id=s.sid and rj.session_serial_num=s.serial#
    and drj.job_name like 'AVQ$AAA_BGP_&BGP_NUMBER%'
  union all
  select s.sid||','||s.serial# session_id,s.logon_time start_date, sysdate , client_info job_name
  from v$session s
  where client_info like 'BGP_OS.&BGP_NUMBER%'
),
ash as (
select
  substr(job_name,1,15) job_name
  ,nvl(ash.wait_class,'CPU') wait_class
  ,count(*) cnt
  ,sum(count(*)) over() cnt_all
from v$active_session_history ash
  left outer join jobs
  on (ash.session_id||','||ash.session_serial#=jobs.session_id and ash.sample_time between jobs.actual_start_date and jobs.log_date)
where sample_time > sysdate - interval '&last_mins' minute
group by substr(job_name,1,15)
  ,nvl(ash.wait_class,'CPU')
),
ash2 as (
  select job_name,avg(active_bgp) active_bgp
  from (
    select
      sample_time
      ,substr(job_name,1,15) job_name
      ,count(*) active_bgp
    from v$active_session_history ash
      left outer join jobs
        on (ash.session_id||','||ash.session_serial#=jobs.session_id and ash.sample_time between jobs.actual_start_date and jobs.log_date)
    where sample_time > sysdate - interval '&last_mins' minute
    group by sample_time,substr(job_name,1,15)
  ) group by job_name
)
,ash3 as (
select
  ash.job_name
  ,ash.wait_class
  ,round(avg(ash2.active_bgp)) avg_active_bgp
  ,round(sum(cnt)/cnt_all*100,2) pct_of_db_load
  ,round(sum(cnt)/sum(sum(cnt)) over(partition by ash.job_name)*100,2) pct_of_waits_in_bgp
from ash, ash2
where ash.job_name=ash2.job_name
group by (ash.job_name,wait_class,cnt_all)
order by pct_of_db_load desc
)
,bs as (
  select b.obj_id,active_bgp started_bgps,to_number(regexp_substr(dflt_instn_cnt,'[0-9]+')) def_cnt
    ,active_bgp-regexp_substr(dflt_instn_cnt,'[0-9]+') extra_bgp_started
  from k.obj_bgp ob, (select obj_id,count(*) active_bgp from k.obj_bgp_instn where session_id is not null group by obj_id order by active_bgp desc) b
  where ob.obj_id=b.obj_id
)
select job_name
  ,avg_active_bgp
  ,sum(pct_of_db_load) "DB load %"
  --,pct_of_waits_in_bgp
  --,wait_class
  ,listagg(rpad(wait_class,13,' ')||': '||trim(to_char(pct_of_waits_in_bgp,'990D0'))||'%'||chr(10)) waits_by_wclass
  ,listagg(case
    when wait_class = 'Application' then
      case
        when pct_of_db_load > 5 and pct_of_waits_in_bgp > 50 then 'Locks - Alarm'
        when pct_of_db_load > 5 and pct_of_waits_in_bgp > 30 then 'Locks - Warning'
        else 'Locks - OK'
      end
    when wait_class = 'Concurrency' then
      case
        when pct_of_db_load > 5 and pct_of_waits_in_bgp > 50 then 'Concurrency - Alarm (too many BGPs?)'
        when pct_of_db_load > 5 and pct_of_waits_in_bgp > 30 then 'Concurrency - Warning (too many BGPs?)'
        else 'Concurrency - OK'
      end
   end,chr(10)) status
   ,rpad('Started:',15,' ')||(select started_bgps from bs where regexp_substr(ash3.job_name,'[0-9]+') = bs.obj_id) ||chr(10)||
   rpad('Default:',15,' ')||(select def_cnt from bs where regexp_substr(ash3.job_name,'[0-9]+') = bs.obj_id)||chr(10)||
   rpad('Extra started:',15,' ')||(select extra_bgp_started from bs where regexp_substr(ash3.job_name,'[0-9]+') = bs.obj_id)
   bgp_setup
from ash3
where (avg_active_bgp >= 5 or '&BGP_NUMBER' <> '%') --do not display BGPs with less than 5 active instances
group by job_name,avg_active_bgp
  --,pct_of_waits_in_bgp,wait_class,pct_of_db_load
order by 3 desc;


prompt ***********************************************************
prompt Thresholds for BGP activity:
prompt Alarm - BGP waits for App or Conc. are > 5% of db load and Application/Concurrency waits are more than 50% of total BGP activity
prompt Warning - BGP waits for App or Conc. are > 5% of db load and Application/Concurrency waits are more than 30% of total BGP activity
prompt ***********************************************************
prompt

set feedback on

col instance_name form A20
col snap_time form A16
col bgp form 999999
set line 200 pagesize 200


prompt ***********************************************************
prompt  Started BGPs
prompt ***********************************************************
select
  instance_name,
  to_char(sysdate,'YYYY-MM-DD HH24:MI') snap_time,
  b.obj_id as bgp,
  active_bgp as started_bgp,
  to_number(regexp_substr(dflt_instn_cnt,'[0-9]+')) as default_cnt,
  (active_bgp-to_number(regexp_substr(dflt_instn_cnt,'[0-9]+'))) as extra_started
from k.obj_bgp ob, (select obj_id,count(*) active_bgp from k.obj_bgp_instn where session_id is not null group by obj_id order by active_bgp desc) b
  ,v$instance
where ob.obj_id=b.obj_id
order by bgp;



spool off
exit;


