set line 250 pagesize 1000
set verify off
set long 200000
col file1 form A110
col file2 form A110

accept file_id1 prompt 'Enter install_file_id 1: '
accept file_id2 prompt 'Enter install_file_id 2: '


select
   (select to_clob(bin_val) from x.install_file where id=&file_id1) as file1
   ,(select to_clob(bin_val) from x.install_file where id=&file_id2) as file2
from dual;

