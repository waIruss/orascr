set heading off
set feedback off
set echo off
set termout off
set line 200
set pagesize 0

spool &1 append

select
  '"'||instance_name||'","'||
  to_char(sysdate,'YYYY-MM-DD HH24:MI')||'",'||
  b.obj_id||','||
  active_bgp||','||
  (regexp_substr(dflt_instn_cnt,'[0-9]+'))||','||
  to_char(active_bgp-to_number(regexp_substr(dflt_instn_cnt,'[0-9]+')))
from k.obj_bgp ob, (select obj_id,count(*) active_bgp from k.obj_bgp_instn where session_id is not null group by obj_id order by active_bgp desc) b
  ,v$instance
where ob.obj_id=b.obj_id;

spool off
exit;

