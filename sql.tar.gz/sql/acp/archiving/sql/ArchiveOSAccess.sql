create or replace and compile java source named "ArchiveOSAccess"
as
package de.apobank;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ArchiveOSAccess
{
  /**
   * Determines whether a directory exists.
   *
   * Parameters
   *  baseDir: the path of the directory
   *
   * Returns
   *  0 if the directory exists; otherwise -1
   */
  public static int DirectoryExists(String baseDir)
  {
    Path path = Paths.get(baseDir);
    if (!Files.isDirectory(path))
      return -1;
    
    return 0;
  }

  /**
   * Determines whether a directory, whose path is the combination of baseDir and relativePath, exists.
   *
   * Parameters
   *  baseDir: the name of the base directory
   *  relativePath: the path, relative to the base directory, of the directory
   *
   * Returns
   *  -2 if the base directory does not exist
   *  -1 if the directory does not exist
   *   0 if the directory exists
   */
  public static int DirectoryExists(String baseDir, String relativePath)
  {
    if (DirectoryExists(baseDir) != 0)
      return -2;

    Path path = Paths.get(baseDir, relativePath);
    if (!Files.isDirectory(path))
      return -1;

    return 0;
  }

  /**
   * Creates a directory, whose path is the combination of baseDir and relativePath.
   *
   * Parameters
   *  baseDir: the name of the base directory
   *  relativePath: the path, relative to the base directory, of the directory
   *
   * Returns
   *  -2 if the base directory does not exist
   *  -1 if the directory was not created
   *   0 if the directory was created
   */
  public static int CreateDirectory(String baseDir, String relativePath)
  {
    if (DirectoryExists(baseDir) != 0)
      return -2;
    
    Path path = Paths.get(baseDir, relativePath);
    if (Files.exists(path))
      return -1;
    
    try
    {
      Files.createDirectory(path);
      return 0;
    }
    catch (Exception e)
    {
      return -1;
    }
  }

  /**
   * Removes a directory, whose path is the combination of baseDir and relativePath.
   *
   * Parameters
   *  baseDir: the name of the base directory
   *  relativePath: the path, relative to the base directory, of the directory
   *
   * Returns
   *  -2 if the base directory does not exist
   *  -1 if the directory was not removed
   *   0 if the directory was removed
   */
  public static int RemoveDirectory(String baseDir, String relativePath)
  {
    if (DirectoryExists(baseDir) != 0)
      return -2;
    
    Path path = Paths.get(baseDir, relativePath);
    if (!Files.isDirectory(path))
      return -1;
    
    try
    {
      Files.delete(path);
      return 0;
    }
    catch (Exception e)
    {
      return -1;
    }
  }
}
/
