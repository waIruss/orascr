def passw=&1
create user arch_admin identified by "&passw";
grant
     create session,
     create any directory,
     drop any directory,
     select any dictionary,
     create procedure
to arch_admin;



PROMPT =========================================================================
PROMPT User created: ARCH_ADMIN/&&passw
PROMPT =========================================================================

