def BASEDIR=&1
CREATE OR REPLACE PACKAGE apo_archive_os_access AS

  /**
   * Defines the location of the base directory.
   * All operations executed by routines of this package refers to directories and/or files relative to this location.
   */
  BASEDIR CONSTANT VARCHAR2(100) DEFAULT '&BASEDIR';
  
  /**
   * Determines whether a directory object and the corresponding operating system directory exist.
   * 
   * Parameters
   *  p_directory_name: the case-sensitive name of the directory object
   *  p_directory_relative_path: the operating system path, relative to BASEDIR, of the directory
   * 
   * Returns
   *  0 if neither the directory object nor the operating system directory exist
   *  1 if only the directory object exists
   *  2 if only the operating system directory exists
   *  3 if both the directory object and the operating system directory exist
   * 
   * Exceptions
   *  -20000: BASEDIR does not exist or is not accessible
   *  -20001: Invalid input argument (<param>=<value>)
   *  -20002: Invalid relative path (<param>=<value>)
   */
  FUNCTION directory_exists(p_directory_name IN VARCHAR2, p_directory_relative_path IN VARCHAR2) RETURN PLS_INTEGER;

  /**
   * Creates a directory object and its operating system directory, and provides read/write privileges to the caller.
   * 
   * Parameters
   *  p_directory_name: the case-sensitive name of the directory object
   *  p_directory_relative_path: the operating system path, relative to BASEDIR, of the directory
   * 
   * Returns
   *  1 if the directory object and the operating system directory are created; otherwise, 0
   * 
   * Exceptions
   *  -20000: BASEDIR does not exist or is not accessible
   *  -20001: Invalid input argument (<param>=<value>)
   *  -20002: Invalid relative path (<param>=<value>)
   *  -20003: Directory object already exists (<name>)
   */
  FUNCTION create_directory(p_directory_name IN VARCHAR2, p_directory_relative_path IN VARCHAR2) RETURN PLS_INTEGER;

  /**
   * Drops a directory object and removes the associated operating system directory.
   * 
   * Parameters
   *  p_directory_name: the case-sensitive name of the directory object
   *  p_directory_relative_path: the operating system path, relative to BASEDIR, of the directory
   * 
   * Returns
   *  1 if the directory object and the operating system directory are removed; otherwise, 0
   * 
   * Exceptions
   *  -20000: BASEDIR does not exist or is not accessible
   *  -20001: Invalid input argument (<param>=<value>)
   *  -20002: Invalid relative path (<param>=<value>)
   *  -20003: Invalid directory (<name>, <relative path>)
   */
  FUNCTION drop_directory(p_directory_name IN VARCHAR2, p_directory_relative_path IN VARCHAR2) RETURN PLS_INTEGER;

END apo_archive_os_access;
/

CREATE OR REPLACE PACKAGE BODY apo_archive_os_access IS

  /**
   * Functions exposing Java methods
   */
   
  FUNCTION archive_os_access_directory_exists(basedir_path IN VARCHAR2, relative_path IN VARCHAR2) RETURN PLS_INTEGER IS
  LANGUAGE JAVA NAME 'de.apobank.ArchiveOSAccess.DirectoryExists(java.lang.String, java.lang.String) return int';

  FUNCTION archive_os_access_create_directory(basedir_path IN VARCHAR2, relative_path IN VARCHAR2) RETURN PLS_INTEGER IS
  LANGUAGE JAVA NAME 'de.apobank.ArchiveOSAccess.CreateDirectory(java.lang.String, java.lang.String) return int';
  
  FUNCTION archive_os_access_remove_directory(basedir_path IN VARCHAR2, relative_path IN VARCHAR2) RETURN PLS_INTEGER IS
  LANGUAGE JAVA NAME 'de.apobank.ArchiveOSAccess.RemoveDirectory(java.lang.String, java.lang.String) return int';

  /**
   * Internal routines
   */
   
  PROCEDURE validate_argument_not_null(p_argument_name IN VARCHAR2, p_argument_value IN VARCHAR2) IS
  BEGIN
    IF p_argument_value IS NULL THEN
      RAISE_APPLICATION_ERROR(-20001, 'Invalid input argument ('||p_argument_name||'='||NVL(p_argument_value,'<null>')||')', FALSE);
    END IF;
  END validate_argument_not_null;

  PROCEDURE validate_relative_path(p_argument_name IN VARCHAR2, p_argument_value IN VARCHAR2) IS
  BEGIN
    IF NOT REGEXP_LIKE(p_argument_value, '^[0-9A-Za-z\/\-_]+$') THEN
      RAISE_APPLICATION_ERROR(-20002, 'Invalid relative path ('||p_argument_name||'='||NVL(p_argument_value,'<null>')||')', FALSE);
    END IF;
  END validate_relative_path;
  
  PROCEDURE validate_directory_object(p_directory_name IN VARCHAR2, p_directory_relative_path IN VARCHAR2) IS
    l_count PLS_INTEGER;
  BEGIN
    SELECT count(*) INTO l_count
    FROM dba_directories
    WHERE directory_name = p_directory_name AND directory_path = BASEDIR||'/'||p_directory_relative_path;
    IF l_count = 0 THEN
      RAISE_APPLICATION_ERROR(-20003, 'Invalid directory ('||p_directory_name||', '||p_directory_relative_path||')', FALSE);
    END IF;
  END validate_directory_object;

  FUNCTION directory_object_exists(p_directory_name IN VARCHAR2) RETURN BOOLEAN AS
    l_count PLS_INTEGER;
  BEGIN
    SELECT count(*) INTO l_count
    FROM dba_directories
    WHERE directory_name = p_directory_name;
    RETURN l_count = 1;
  END directory_object_exists;

  /**
   * Public routines
   */
   
  FUNCTION directory_exists(p_directory_name IN VARCHAR2, p_directory_relative_path IN VARCHAR2) RETURN PLS_INTEGER IS
    l_return_value PLS_INTEGER := 0;
  BEGIN
    -- validate input arguments
    validate_argument_not_null('p_directory_name', p_directory_name);
    validate_argument_not_null('p_directory_relative_path', p_directory_relative_path);
    validate_relative_path('p_directory_relative_path', p_directory_relative_path);
    
    -- does the directory object exist?
    IF directory_object_exists(p_directory_name) THEN
      l_return_value := 1;
    END IF;
    
    -- does the operating system directory exist?
    CASE archive_os_access_directory_exists(BASEDIR, p_directory_relative_path)
      WHEN 0 THEN
        l_return_value := l_return_value + 2;
      WHEN -1 THEN
        NULL;
      WHEN -2 THEN
        RAISE_APPLICATION_ERROR(-20000, 'BASEDIR does not exist or is not accessible', FALSE);
      ELSE
        RAISE PROGRAM_ERROR;
    END CASE;
    
    RETURN l_return_value;
  END directory_exists;

  FUNCTION create_directory(p_directory_name IN VARCHAR2, p_directory_relative_path IN VARCHAR2) RETURN PLS_INTEGER IS
    l_return_value PLS_INTEGER;
  BEGIN
    -- validate input arguments
    validate_argument_not_null('p_directory_name', p_directory_name);
    validate_argument_not_null('p_directory_relative_path', p_directory_relative_path);
    validate_relative_path('p_directory_relative_path', p_directory_relative_path);

    -- create the operating system directory, and create the directory object and grant privileges to caller
    IF directory_object_exists(p_directory_name) THEN
      RAISE_APPLICATION_ERROR(-20003, 'Directory object already exists ('||p_directory_name||')', FALSE);
    ELSE    
      CASE archive_os_access_create_directory(BASEDIR, p_directory_relative_path)
        WHEN 0 THEN
          EXECUTE IMMEDIATE 'CREATE DIRECTORY '||p_directory_name||' AS '''||BASEDIR||'/'||p_directory_relative_path||'''';
          EXECUTE IMMEDIATE 'GRANT READ, WRITE ON DIRECTORY '||p_directory_name||' TO '||user;
          l_return_value := 1;
        WHEN -1 THEN
          l_return_value := 0;
        WHEN -2 THEN
          RAISE_APPLICATION_ERROR(-20000, 'BASEDIR does not exist or is not accessible', FALSE);
        ELSE
          RAISE PROGRAM_ERROR;
      END CASE;
    END IF;
    
    RETURN l_return_value;
  END create_directory;

  FUNCTION drop_directory(p_directory_name IN VARCHAR2, p_directory_relative_path IN VARCHAR2) RETURN PLS_INTEGER IS
    l_return_value PLS_INTEGER;
  BEGIN
    -- validate input arguments
    validate_argument_not_null('p_directory_name', p_directory_name);
    validate_argument_not_null('p_directory_relative_path', p_directory_relative_path);
    validate_relative_path('p_directory_relative_path', p_directory_relative_path);
    validate_directory_object(p_directory_name, p_directory_relative_path);
    
    -- drop the operating system directory and the directory object
    IF directory_object_exists(p_directory_name) THEN
      CASE archive_os_access_remove_directory(BASEDIR, p_directory_relative_path)
        WHEN 0 THEN
          EXECUTE IMMEDIATE 'DROP DIRECTORY '||p_directory_name;
          l_return_value := 1;
        WHEN -1 THEN
          l_return_value := 0;
        WHEN -2 THEN
          RAISE_APPLICATION_ERROR(-20000, 'BASEDIR does not exist or is not accessible', FALSE);
        ELSE
          RAISE PROGRAM_ERROR;
      END CASE;
    ELSE
      l_return_value := 0;
    END IF;
    
    RETURN l_return_value;
  END drop_directory;

END apo_archive_os_access;
/
