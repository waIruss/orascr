set line 240 pagesize 100
set verify off
set termout off
set serveroutput on size unlimited

col new_pass new_val NEW_PASSWD noprint
def uName="ARCH_ADMIN"
whenever sqlerror exit
whenever oserror exit

spool install_arch_admin.log

select to_char(sysdate,'YYYY-MM-DD HH24:MI:SS') as install_start from dual;

with function
  gen_new_pass(v_user varchar2, v_acc_type varchar2 default 'S', v_old_pass varchar2 default null)
  return varchar2
  as
    type chararr is table of char(1) index by binary_integer;
    pass_chars chararr;
    --v_user varchar2(50) := 'USER_123455';
    --v_old_pass varchar2(50);
    v_new_pass varchar2(50);
    --v_acc_type char(1) := 'S';  -- U - user, S - service
    v_pass_len pls_integer;
    v_pass_ok boolean := false;
    v_att pls_integer := 1;
  begin
    if v_acc_type = 'U' then
      v_pass_len := 8;
    elsif v_acc_type = 'S' then
      v_pass_len := 12;
    else
      v_pass_len := 16;
    end if;

    select c
      bulk collect into pass_chars
    from
      (select chr(to_number(column_value)) c, to_number(column_value) n from xmltable('1 to 128'))
    where (
      n between 48 and 57 --[0-9]
      or n between 65 and 90 --[a-z]
      or n between 97 and 122 --[A-Z]
      or c in('[',']','-','.','^','{','}') --allowed special chars
    );

    while (not v_pass_ok)
    loop
      v_new_pass := chr(round(dbms_random.value(65,90)));
      v_att := v_att+1;
      for i in 1..20
        loop
          v_new_pass := v_new_pass||pass_chars(round(dbms_random.value(1,pass_chars.count)));
        end loop;
          v_new_pass := substr(regexp_replace(v_new_pass,'(.)\1+','\1'),1,v_pass_len+1);
      begin
        if v_acc_type = 'S' then
          v_pass_ok := sys.passwd_verify_function_service(v_user,v_new_pass,v_old_pass);
        elsif v_acc_type = 'U' then
          v_pass_ok := sys.passwd_verify_function_user(v_user,v_new_pass,v_old_pass);
        end if;
      exception
        when others then
          null;
      end;
      exit when v_att >= 20;
    end loop;
    return v_new_pass;
  end;
select gen_new_pass(upper(trim('&uName')),'S') new_pass
from dual
/

set termout on

PROMPT =========================================================================
PROMPT   This script will create ARCH_ADMIN schema
PROMPT   It will act as a proxy for creating/removing directories on OS level
PROMPT =========================================================================


ACCEPT uAsk  DEFAULT 'Y'  PROMPT 'Continue? [Y]: '

begin
   if trim(upper('&uAsk')) != 'Y' then
      raise_application_error(-20001,'Aborted by user request!');
   end if;
end;
/

accept BASEDIR prompt 'Enter basedir for archive (default: /oracle/archive): ' default '/oracle/archive'
accept SCRIPTDIR prompt 'Enter scriptdir for shell scripts (external table preprocessor) (default: /oracle/scripts): ' default '/oracle/scripts'
accept TGTSCHEMA prompt 'Enter schema name which should be granted privileges on ARCH_ADMIN objects: '

host mkdir -p &&BASEDIR
host mkdir -p &&SCRIPTDIR
host echo '#!/bin/bash' > &&SCRIPTDIR./gunzip.sh
host echo '/usr/bin/gzip -dc "$1"' >> &&SCRIPTDIR./gunzip.sh
host chmod u+x &&SCRIPTDIR./gunzip.sh
create or replace directory SCRIPTSDIR as '&&SCRIPTDIR';
prompt Directory SCRIPTSDIR created as '&&SCRIPTDIR'
prompt Preprocessor script created: &&SCRIPTDIR./gunzip.sh

@@sql/cre_admin_user.sql &&NEW_PASSWD
call dbms_java.grant_permission('&uName', 'java.io.FilePermission', trim('&BASEDIR'), 'read,write');
call dbms_java.grant_permission('&uName', 'java.io.FilePermission', trim('&BASEDIR./-'), 'read,write,delete');

connect ARCH_ADMIN/&&NEW_PASSWD

@@sql/ArchiveOSAccess.sql
@@sql/apo_archive_os_access.sql &&BASEDIR

declare
   basedir varchar2(1000);
begin
   basedir := apo_archive_os_access.basedir;
   dbms_output.put_line('=========================================================================');
   dbms_output.put_line('Package apo_archive_os_access created using basedir: '||basedir);
   dbms_output.put_line('=========================================================================');
end;
/


begin
  if length(trim('&TGTSCHEMA')) >= 1 then
     execute immediate 'grant execute on  ARCH_ADMIN.APO_ARCHIVE_OS_ACCESS to &&TGTSCHEMA';
     execute immediate 'grant read,execute on directory SCRIPTSDIR to &&TGTSCHEMA';
     dbms_output.put_line('Access granted to schema: &TGTSCHEMA');
  else
     dbms_output.put_line('=========================================================================');
     dbms_output.put_line('Target schema not specified!');
     dbms_output.put_line('Add required grants manualy:');
     dbms_output.put_line('grant execute on ARCH_ADMIN.APO_ARCHIVE_OS_ACCESS to ...');
     dbms_output.put_line('grant read,execute on directory SCRIPTSDIR to ...');
     dbms_output.put_line('=========================================================================');
  end if;
end;
/


select to_char(sysdate,'YYYY-MM-DD HH24:MI:SS') as install_end from dual;

spool off

