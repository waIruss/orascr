set line 250  pagesize 300
col lock_path form a35
col sid_serial form a13
col username form a25
col osinfo form a25 wor
col program form a25 wor
col wait_class form a12 trunc
col event form a25 trunc
col wait_time form a12
col obj_wait form A40
col sql_id form a13 


select
  lpad(' ', level-1)||ltrim(sys_connect_by_path(wc.sid, '->'),'->')||'['||wc.num_waiters||']' lock_path,
  --wc.chain_id,
  --wc.chain_signature,
  --nvl2(wc.blocker_sid,wc.blocker_sid||','||wc.blocker_sess_serial#||'@'||wc.blocker_instance,null) blocker,
  wc.sid||','||wc.sess_serial#||'@'||wc.instance sid_serial,
  --wc.num_waiters waiters#,
  --s.username,
  nvl2(avs.sid,s.username||chr(10)||avs.name||chr(10)||avs.oracle_user||chr(10)||avs.email,s.username) username,
  s.osuser||'@'||s.machine osinfo,
  --s.program,
  nvl2(j.sid,j.job_name,s.program) program,
  Nvl(s.sql_id,s.prev_sql_id) sql_id,
  wc.wait_event_text event,
  --wc.sid,wc.sess_serial#,wc.instance,
  --wc.blocker_is_valid,
  --wc.blocker_sid,wc.blocker_sess_serial#,wc.blocker_instance,
  case when wc.row_wait_obj# > 0 then (select object_type||' - '||object_name from dba_objects where data_object_id = wc.row_wait_obj#) ||chr(10) else null end||
  case when wc.row_wait_row# > 0 then ('ROWID: '||dbms_rowid.rowid_create(1,wc.row_wait_obj#,wc.row_wait_file#,wc.row_wait_block#,wc.row_wait_row#)) else null end obj_wait,
  --wc.in_wait_secs,
  --lpad(floor(in_wait_secs/60/60)|| 'hr '||floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60) || 'min '|| (in_wait_secs-(floor(in_wait_secs/60/60)*60*60)-(floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60)*60)) ||'s',15,' ') as wait_time
  --lpad(replace(to_char(floor(in_wait_secs/60/60),'990')|| ':'||to_char(floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60),'00') || ':'|| to_char((in_wait_secs-(floor(in_wait_secs/60/60)*60*60)-(floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60)*60)),'00'),' ',''),10,' ') as wait_time
  cast(numtodsinterval(wc.in_wait_secs,'SECOND') as interval day(0) to second(0)) wait_time
from v$wait_chains wc left outer join
 v$session s on (wc.sid = s.sid and wc.sess_serial# = s.serial#)
 --gv$session bs
 left outer join
  (select s.inst_id,s.sid,s.serial,s.logon_time,s.ip_addr,s.hostname,u.name,u.oracle_user,coalesce(u.email,u2.email) email 
    from k.session_det s, k.sec_user u, k.sec_user u2 
    where s.sec_user_id=u.id 
      and s.logoff_time is null 
      and u.sec_owner_id=u2.id(+)
  ) avs on (s.sid=avs.sid and s.serial#=avs.serial)
  left outer join 
  (select rj.session_id sid,rj.session_serial_num serial,job_name,os_process_id 
    from dba_scheduler_running_jobs drj, v$scheduler_running_jobs rj 
    where drj.session_id=rj.session_id 
      and drj.slave_os_process_id=rj.os_process_id
  ) j on (s.sid=j.sid and s.serial#=j.serial)
where
  (
      num_waiters > 0 or ( blocker_osid is not null and in_wait_secs > 1)
  )
connect by prior wc.sid=wc.blocker_sid and prior wc.sess_serial#=wc.blocker_sess_serial# and prior wc.instance=wc.blocker_instance start with wc.blocker_is_valid='FALSE'
order by nvl(blocker_sid,s.sid) nulls first,num_waiters desc;


