set line 240
set pagesize 200
set verify off

col sample_time form A13
col bgp form A7
col max_pga_gb form 9G990D00
col bar form A185

accept task_id prompt 'Enter task_id: '
accept HR_FMT prompt 'Enter time format for grouping (default: HH24): ' default 'HH24'
accept tgroup prompt 'Enter task grouping [P - parent|S - slave] (default: P): ' default 'P'


with b as (
  select id,nvl(parent_task_id,id) parent_task_id,parallel_exec_seq_nr prl_seq,timestamp_start start_time,timestamp as end_time,sid session_id
  from k.out_job where id=&task_id or parent_task_id=&task_id
)
, a as (
  select /*+ parallel(4) */
    sample_time
    ,decode(upper(trim('&tgroup')),'P',parent_task_id,'S',id) run_id
    ,sum(round(pga_allocated/1024/1024/1024,2)) pga_gb
    ,count(*) ses_cnt
  from dba_hist_active_sess_history ash, b
  where ash.session_id=b.session_id and ash.sample_time between b.start_time and b.end_time
  group by sample_time,decode(upper(trim('&tgroup')),'P',parent_task_id,'S',id)
  order by 1
)
select to_char(sample_time,'MM/DD &HR_FMT') sample_time,run_id
  ,max(pga_gb) max_pga_gb
  ,max(ses_cnt) ses_cnt
  ,lpad('*',max(pga_gb),'*') bar
from a
group by run_id,to_char(sample_time,'MM/DD &HR_FMT')
order by run_id,sample_time;



undef task_id

