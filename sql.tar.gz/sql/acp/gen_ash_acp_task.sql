set termout off
set linesize 300
set verify off
set heading off feedback off
set pagesize 500

whenever sqlerror exit
whenever oserror exit

def DT_FMT_REP="Mon-DD"
def DT_FMT_ISO="YYYY-MM-DD HH24:MI"
def DT_FMT_ASH="MM/DD/YY HH24:MI"

col today new_val today noprint
col dbname new_val dbname noprint
col awr_script new_val awr_script noprint
col ash_script new_val ash_script noprint

select to_char(sysdate,'YYYYMMDD') today,name dbname
,'/tmp/.gen_awr_'||to_char(systimestamp,'YYYYMMDDHH24MISS')||'_'||sys_context('userenv','sessionid')||'.sql' as awr_script
,'/tmp/.gen_ash_'||to_char(systimestamp,'YYYYMMDDHH24MISS')||'_'||sys_context('userenv','sessionid')||'.sql' as ash_script
from v$database;


set termout on

prompt ==================================================================
ACCEPT taskID DEFAULT ''        PROMPT 'Enter Avaloq task run_id []: '
prompt ==================================================================
set heading on
set trimspool on
col TMPL_INTL_ID form A50
col run_id form A12
col userstamp form A12
col username form A18
col start_time form A16
col end_time form A16
col exec_time form A14
col task_name form A50
col status form A10
col session_id form 9999999

select
  ttv.user_id TMPL_INTL_ID
  ,nvl2(oj.parent_task_id,'   '||oj.id,oj.id) run_id
  ,oj.userstamp username
  ,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI') start_time
  ,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI')) end_time
  , oj.parallel_exec_seq_nr prl_seq
  ,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  --,k.task_def#.task#name(oi.obj_id) task_name
  ,ttv.task_name
  ,s.name status
  ,oj.sid session_id
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
  (oj.id=&&taskID or oj.parent_task_id=&&taskID)
  and oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
order by oj.parallel_exec_id,nvl(parent_task_id,0),parallel_exec_seq_nr;
set heading off

prompt ==================================================================
ACCEPT bGenAWR DEFAULT 'Y'      PROMPT 'Generate AWR reports? [Y]: '
ACCEPT bGenASH DEFAULT 'Y'      PROMPT 'Generate ASH reports? [Y]: '
ACCEPT prl_prc DEFAULT '1,2,3'       PROMPT 'List of parallel slaves to include (0=all) [1,2,3]: '
ACCEPT ash_ival  DEFAULT '30'   PROMPT 'Enter interval for ASH reports (in minutes) [30]: '
ACCEPT out_dir  DEFAULT '../awr/&&taskID'   PROMPT 'Enter output directory for reports [../awr/&&taskID ]: '
prompt ==================================================================

set termout off
host mkdir -p &&out_dir

col task_template form A50
col task_id form A12
col userstamp form A12
col username form A18
col start_time form A16
col end_time form A16
col exec_time form A14
col task_name form A50
col status form A10
col session_id form 9999999
col timestamp_ form A20
set heading on

spool &&out_dir./task_info_run_&&taskID..txt
select
  ttv.user_id task_template
  ,nvl2(oj.parent_task_id,'   '||oj.id,oj.id) task_id
  ,oj.userstamp username
  ,to_char(oj.timestamp_start,'YYYY-MM-DD HH24:MI') start_time
  ,decode(oj.out_status_id,3,null,to_char(oj.timestamp,'YYYY-MM-DD HH24:MI')) end_time
  , oj.parallel_exec_seq_nr prl_seq
  ,cast(numtodsinterval(oj.exec_time/100,'SECOND') as interval day(1) to second(0)) exec_time
  --,k.task_def#.task#name(oi.obj_id) task_name
  ,ttv.task_name
  ,s.name status
  ,oj.sid session_id
from
  k.out_job oj
  ,k.code_out_status s
  ,k.obj_name_intl oi
  ,k.obj_task_templ_v ttv
where
  (oj.id=&&taskID or oj.parent_task_id=&&taskID)
  and oj.out_status_id=s.id
  and oi.obj_id=oj.meta_out_id
  and oj.meta_out_templ_id=ttv.id(+)
order by oj.parallel_exec_id,nvl(parent_task_id,0),parallel_exec_seq_nr;
spool off

set heading off

spool &&awr_script
select
'define report_type="html"'||chr(10)||
'define num_days=30'||chr(10)||
'define inst_num=1'||chr(10)||
'define dbname='||upper(d.name)||chr(10)||
'define dbid='||trim(to_char(d.dbid))||chr(10)||
'define begin_snap='||bsnap||chr(10)||
'define end_snap='||esnap||chr(10)||
'define report_name="&&out_dir./awrrpt_'||upper(d.name)||'_'||to_char(btime,'YYYY-MM-DD_HH24MI-')||to_char(etime,'HH24MI')||'.html"'||chr(10)||
'set termout on'||chr(10)||
'prompt Generating AWR report for '||to_char(btime,'YYYY-MM-DD_HH24MI-')||to_char(etime,'HH24MI')||chr(10)||
'set termout off'||chr(10)||
'@?/rdbms/admin/awrrpti'||chr(10)||chr(10)||chr(10)
--bsnap,esnap,btime,etime,to_char(btime,'YYYY-MM-DD_HH24MI-')||to_char(etime,'HH24MI') time_range
from
(
  select snap_id bsnap
    ,lead(snap_id) over(partition by startup_time order by end_interval_time) esnap
    ,end_interval_time btime
    ,lead(end_interval_time) over(partition by startup_time order by end_interval_time) etime
  from
  (
    select snap_id,startup_time,begin_interval_time,end_interval_time
    from dba_hist_snapshot s
    where s.snap_id >= (select max(s1.snap_id) from dba_hist_snapshot s1
                where s1.begin_interval_time <= (select min(cast(oj.timestamp_start as date)) from k.out_job oj where id=&&taskID or parent_task_id=&&taskID) and s.dbid=s1.dbid)
      and s.snap_id <= (select min(s2.snap_id) from dba_hist_snapshot s2
                where s2.end_interval_time >= (select max(decode(oj.out_status_id,3,cast(sysdate as date),cast(oj.timestamp as date))) from k.out_job oj where id=&&taskID or parent_task_id=&&taskID) and s.dbid=s2.dbid)
      and s.dbid = (select dbid from v$database)
    order by s.begin_interval_time
  )
) s, v$database d
where esnap  is not null
  and 'Y' = upper(trim('&&bGenAWR'));

spool off
@&&awr_script
host rm &&awr_script



set termout off
set line 300
spool &&ash_script
prompt alter session set optimizer_index_caching=0;
prompt alter session set optimizer_index_cost_adj=100;
prompt alter session set db_file_multiblock_read_count=128;

with j as(
select id
  ,nvl(parent_task_id,id) parent_task_id
  --,timestamp_start
  --,timestamp
  ,cast(oj.timestamp_start as date) start_time
  ,decode(oj.out_status_id,3,cast(sysdate as date),cast(oj.timestamp as date))  end_time
  ,round((decode(oj.out_status_id,3,cast(sysdate as date),cast(oj.timestamp as date))-cast(oj.timestamp_start as date))*24*60) ela_min
  ,round((decode(oj.out_status_id,3,cast(sysdate as date),cast(oj.timestamp as date))-cast(oj.timestamp_start as date))*24*60/30) buckets
  ,sid,exec_time
  ,&ash_ival as ival
  ,parallel_exec_seq_nr prl_seq
from k.out_job oj
where id=&&taskID or parent_task_id=&&taskID
and (parallel_exec_seq_nr in(&prl_prc) or '&prl_prc'='0')
)
,b as(
select id,parent_task_id,prl_seq,ival
  ,start_time
  ,start_time+numtodsinterval((level-1)*ival,'MINUTE') bucket_start
  ,start_time+numtodsinterval(level*ival,'MINUTE') bucket_end
  ,end_time
  ,ela_min
  ,sid
from j
connect by id = prior id
  and start_time + numtodsinterval(level*ival,'MINUTE') <= end_time+numtodsinterval(ival,'MINUTE')
  and prior sys_guid() is not null
order by id,start_time
)
, c as (
select id, parent_task_id, prl_seq,ival
  , start_time
  , bucket_start
  , bucket_end
  , case
      when bucket_end >= end_time then
        case
          when bucket_start = start_time then
            end_time
          when (bucket_end-end_time)*24*60 < ival/2 then
            end_time
          else
            cast(null as date)
        end
      when bucket_end < end_time then
        case
          when (end_time-bucket_end)*24*60 < ival/2 then
            --round((end_time-bucket_end)*24*60)
            end_time
          else
            bucket_end
        end
    end bucket_end_adj
  , round((bucket_end-bucket_start)*24*60) bucket_width_min
  , end_time
  , ela_min
  , sid
from b
order by id,bucket_start )
,d as(
select id, parent_task_id, prl_seq, ival, start_time
  , to_char(bucket_start,'MM/DD/YY HH24:MI') bucket_start
  --, bucket_start
  , bucket_end_adj as bucket_end
  , round((bucket_end_adj-bucket_start)*24*60) bucket_width
  --, end_time, ela_min
  , sid
  , 'ashrpt_task_'||parent_task_id||'_prl_seq_'||prl_seq||'_sid_'||sid||'_'||to_char(bucket_end_adj,'YYYYMMDD_HH24MI') rep_name
from c where bucket_end_adj is not null
)
select
'col db_name new_val dbname'||chr(10)||
'col dbid new_val dbid'||chr(10)||
'select upper(name) db_name, dbid from v$database;'||chr(10)||
'define default_report_type         = "html";'||chr(10)||
'define default_report_duration     = 15;'||chr(10)||
'define default_report_name_prefix  = "ashrpt";'||chr(10)||
'define default_report_name_suffix  = "MMDD_HH24MI";'||chr(10)||
'def report_type_def="html"'||chr(10)||
'def report_type="html"'||chr(10)||
'def dbid='||d.dbid||chr(10)||
'def inst_num=1'||chr(10)||
'def begin_time="'||bucket_start||'"'||chr(10)||
'def duration='||to_char(bucket_width)||chr(10)||
'def slot_width=""'||chr(10)||
'def target_session_id="'||sid||'"'||chr(10)||
'def target_sql_id=""'||chr(10)||
'def target_wait_class=""'||chr(10)||
'def target_service_hash=""'||chr(10)||
'def target_module_name=""'||chr(10)||
'def target_action_name=""'||chr(10)||
'def target_client_id=""'||chr(10)||
'def target_plsql_entry=""'||chr(10)||
'def target_container=""'||chr(10)||
'def report_name="&&out_dir./'||rep_name||'.html"'||chr(10)||
'@?/rdbms/admin/ashrpti'||chr(10)||chr(10)||chr(10)
from d,v$database d
where upper(trim('&&taskID')) is not null
and 'Y' = upper(trim('&&bGenASH'))
order by prl_seq,bucket_start;

spool off

@&&ash_script
--host rm &&ash_script

prompt ==================================================================
prompt Generated reports in &&out_dir
prompt ==================================================================
host ls -ltr &&out_dir/*

