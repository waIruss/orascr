set line 220
set pagesize 100
col range form A30
col partition_name form A30
col last_old_as_of form A16
col next_trunc_as_of form A16
col can_be_trunc_now form A10 heading "Can be|trunc now?"
col mbytes form 999G999
col is_empty form A10
col is_avail form 9999
col time_to_exp form A16
col curr_seq form 999G999G999
col ids#_per_hour form 999G999G999
col first_id form 999G999G999
col last_id form 999G999G999


compute sum of is_avail on report
break on report

select to_char(sysdate,'YYYY-MM-DD HH24:MI:SS') curr_date from dual;

with gc as (select * from k.list_xx_garbcol order by timestamp desc fetch first 1 row only)
--,gcp as (select * from k.list_xx_garbcol order by timestamp desc offset 1 rows fetch first 1 rows only)
, ttl as (
  select last_old_part part_num, cast(numtodsinterval((2-(sysdate-timestamp))*24*60*60,'SECOND') as interval day(0) to second(0)) time_to_exp , timestamp+2 expire_at
  from k.list_xx_garbcol 
  where timestamp > sysdate -2
)
,p as(
select
  p.partition_name,partition_position,to_number(regexp_substr(p.partition_name,'[0-9]+')) high_val,s.bytes
from dba_tab_partitions p, dba_segments s
where p.table_name='LIST_NUMBER' and p.table_owner='K'
and p.table_owner=s.owner
and p.partition_name=s.partition_name
and p.table_name=s.segment_name
order by partition_position
)
,act as (
select
  (select last_old_part from k.list_xx_garbcol where timestamp < (sysdate - 2 /*c_list_xx_keep_days*/) order by timestamp desc fetch first 1 rows only) le_now
  ,(select next_trunc_part from k.list_xx_garbcol order by timestamp desc fetch first 1 row only) nt_now
from dual
)
,p2 as (
select partition_name, partition_position, lag(high_val) over(order by high_val) min_val,high_val, bytes
from p)
,p3 as (
select partition_position part_num, partition_name
  , lpad(to_char(min_val,'999G999G999')||' -'||to_char(high_val-1,'999G999G999'),30,' ') range
  , round(bytes/1024/1024) mbytes
  , curr_seq
  , to_char(gc1.timestamp,'YYYY-MM-DD HH24:MI')
    --||nvl2(gcp1.timestamp,chr(10),null)||to_char(gc1.timestamp,'YYYY-MM-DD HH24:MI')
    last_old_as_of
  , to_char(gc2.timestamp,'YYYY-MM-DD HH24:MI')
    ---||nvl2(gcp2.timestamp,chr(10),null)||to_char(gc2.timestamp,'YYYY-MM-DD HH24:MI')
    next_trunc_as_of
  , act.le_now last_expire
  , act.nt_now next_trunc
  , case
      when bytes = 65536 and curr_seq is null then
        'YES'
      else
        'NO'
    end is_empty
  , case
      when nt_now > le_now+1 then
        case
          when (partition_position >= nt_now and partition_position <= le_now+20 and curr_seq is null) or (partition_position+20 >=nt_now and partition_position <= le_now)then
            'YES'
          else
            'NO'
        end
      when nt_now <= le_now then
        case
          when partition_position >= nt_now and partition_position <= le_now and curr_seq is null then
            'YES'
          else
            'NO'
        end
      else
        'NO'
    end can_be_trunc_now
    ,nvl2(curr_seq,partition_position,null) curr_part
from p2 left outer join (select last_number curr_seq from dba_sequences where sequence_name = 'LIST_ID_SEQ') sq
 on (sq.curr_seq between nvl(min_val,0)-1 and high_val)
 left outer join gc gc1 on(gc1.last_old_part=p2.partition_position)
 left outer join gc gc2 on(gc2.next_trunc_part=p2.partition_position)
 cross join act
order by partition_position
)
select
  p3.part_num, partition_name, range, mbytes, curr_seq, last_old_as_of, next_trunc_as_of, is_empty
  --, can_be_trunc_now
  --, last_expire
  --, next_trunc
  , case when next_trunc=max(curr_part) over() then
    'Overflow!'
    else
      can_be_trunc_now
    end can_be_trunc_now
  , case when (p3.part_num > max(curr_part) over() and is_empty='YES') or (p3.part_num < next_trunc and is_empty='YES') then 1 else 0 end is_avail
  , time_to_exp
  , to_char(expire_at,'YYYY-MM-DD HH24:MI') expire_at
from p3 left outer join ttl on p3.part_num=ttl.part_num
order by p3.part_num;

with j as(
select time_,first_id,last_id,range as range#,rn from (
select time_,first_id,last_id
,case
  when last_id >= first_id then
    last_id-first_id
  else
    1e9-first_id+last_id
  end range
  ,row_number() over(order by time_ desc) rn
from (
  select distinct to_char(timestamp_start,'YYYY-MM-DD HH24') time_
    --,max(list_par_list_id)-min(list_par_list_id) no_of_used_ids
    --,max(list_par_list_id)
    --,min(list_par_list_id)
    ,first_value(list_par_list_id ignore nulls) over (partition by to_char(timestamp_start,'YYYY-MM-DD HH24') order by timestamp_start rows between unbounded preceding and unbounded following) first_id
    ,last_value(list_par_list_id ignore nulls) over (partition by to_char(timestamp_start,'YYYY-MM-DD HH24') order by timestamp_start rows between unbounded preceding and unbounded following) last_id
  from k.out_job j
  where timestamp_start > sysdate-1 and list_par_list_id is not null
  --group by to_char(timestamp_start,'YYYY-MM-DD HH24')
)
) where rn <=10
),
gc as (
select row_number() over(order by timestamp desc) rn,timestamp as garbcol_run,last_old_part,next_trunc_part
  --,prev_old_part
  ,case when last_old_part > prev_old_part
    then
      last_old_part-prev_old_part
    else 20-prev_old_part+last_old_part
   end parts_used_
  --,prev_trunc_part
  ,case when next_trunc_part >= prev_trunc_part
    then
      next_trunc_part-prev_trunc_part
    else 20-prev_trunc_part+next_trunc_part
   end parts_truncated
from(
  select to_char(timestamp,'YYYY-MM-DD HH24:MI') timestamp, last_old_part,lag(last_old_part) over( order by timestamp) prev_old_part,
  next_trunc_part, lag(next_trunc_part) over(order by timestamp ) prev_trunc_part
  from k.list_xx_garbcol order by timestamp desc
)
order by timestamp desc fetch first 10 rows only
)
select garbcol_run, last_old_part, next_trunc_part, parts_used_, parts_truncated, '    ###' as " "
,time_ as job_time,j.first_id,j.last_id,range# ids#_per_hour
from gc,j where gc.rn=j.rn
order by gc.rn;



clear compute
clear break

