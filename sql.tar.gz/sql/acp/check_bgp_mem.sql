set line 240
set pagesize 200
set verify off
set feedback off

col sample_time form A13
col bgp form A11
col max_pga_gb form 990D00
col bar form A185

accept bgp prompt 'Enter BGP number (default: %): ' default '%'
accept last_days prompt 'Enter last days (default: 3): ' default '3'
accept HR_FMT prompt 'Enter time format for grouping (default: HH24): ' default 'HH24'
accept bgpagg prompt 'Enter BGP grouping [B - by bgp|I - by instance] (default: B): ' default 'B'

col joblen new_val joblen noprint
select decode('&bgpagg','B','7','I','11') joblen from dual;

with j as (
select job_name,session_id,actual_start_date start_time,log_date end_time
from dba_scheduler_job_run_details where job_name like 'AVQ$%&BGP%' and log_date > trunc(sysdate-(&last_days+1))
union all
select job_name,rj.session_id||','||rj.session_serial_num session_id,s.logon_time start_date,sysdate
  from dba_scheduler_running_jobs drj
    , v$scheduler_running_jobs rj
    , v$session s
  where drj.session_id=rj.session_id
    and rj.session_id=s.sid and rj.session_serial_num=s.serial#
    and drj.job_name like 'AVQ$%&BGP%'
)
, a as (
select /*+ parallel(4) */ sample_time
  ,case when job_name like 'AVQ$AAA_BGP%' then substr(job_name,9,&joblen )
    when job_name like 'AVQ$ISM%' then 'AVQ$ISM' end bgp
  ,sum(round(pga_allocated/1024/1024/1024,2)) pga_gb,count(*) bgp_cnt
from dba_hist_active_sess_history ash,j
where ash.session_id||','||ash.session_serial#=j.session_id and  ash.sample_time between j.start_time and j.end_time
and sample_time > trunc(sysdate-&last_days)
group by sample_time
  ,case when job_name like 'AVQ$AAA_BGP%' then substr(job_name,9,&joblen )
        when job_name like 'AVQ$ISM%' then 'AVQ$ISM' end
order by 1
)
select to_char(sample_time,'MM/DD &HR_FMT') sample_time,bgp
  ,max(bgp_cnt) ses_cnt
  ,max(pga_gb) max_pga_gb
  ,lpad('*',max(pga_gb),'*') bar
from a
group by (bgp,to_char(sample_time,'MM/DD &HR_FMT'))
order by sample_time,bgp;

undef bgp
undef last_days
set  feedback 6
