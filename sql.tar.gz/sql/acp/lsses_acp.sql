set line 240 pagesize 200 verify off

col sid_ser form A11
col username form A10
col program form A21
col osuser_machine form A35 wor
col sql_id form A15
col wait_class_event form A40
col state form A8
col wait_time form 99999
col sec_in_wait form 99999
col inst_id form 999
col avq_sec_user form A30
col module form A20
col action form A16
col mod_action form A30

accept session_id prompt 'Enter SID (default: %): ' default '%'
accept userpattern prompt 'Enter username pattern (default: %): ' default '%'
accept hostpattern prompt 'Enter client host pattern (default: %): ' default '%'
accept modulpattern prompt 'Enter session.module pattern (default: %): ' default '%'
accept ifactive prompt 'Display only active sessions? Y/N (default: N): ' default 'N'

select s.sid||','||s.serial# sid_ser
  ,username
  ,program
  ,osuser||'@'||machine||chr(10)||'host:'||
  avq_ses.hostname osuser_machine
  ,to_char(s.logon_time,'YYYY-MM-DD HH24:MI') logon_time
  --,avq_ses.logon_time
  --,state
  --,wait_time
  ,seconds_in_wait sec_in_wait
  ,avq_ses.name||chr(10)||avq_ses.email avq_sec_user
  --, avq_ses.oracle_user
  ,'module:'||case
    when module like 'task%[%][%]%' then
      'task: '||(select name from k.obj_name_intl where obj_id=regexp_substr(module,'(\[)(\d*)(\])(\[)(\d*)(\])',1,1,'i',5))
    when module like 'task%[%]%' then
      'task: '||(select name from k.obj_name_intl where obj_id=regexp_substr(module,'(\[)(\d*)(\])',1,1,'i',2))
    when module like 'doc%[%]%' then
      'doc_log:'||(select name from k.code_doc_log_consmr where id=regexp_substr(module,'(\[)(\d*)(\])',1,1,'i',2))
    else
      module
   end
  ||chr(10)
  ||'action:'||chr(10)||nvl(action,'') mod_action
  ,nvl(sql_id,'P:'||prev_sql_id) sql_id
  ,wait_class||': '||event wait_class_event
from gv$session s
  ,(select s.inst_id,s.sid,s.serial,s.logon_time,s.ip_addr,s.hostname,u.name,u.oracle_user,coalesce(u.email,u2.email) email from k.session_det s, k.sec_user u, k.sec_user u2 where s.sec_user_id=u.id and s.logoff_time is null and u.sec_owner_id=u2.id(+)) avq_ses
where avq_ses.inst_id=s.inst_id and avq_ses.sid=s.sid and avq_ses.serial=s.serial#
   and (upper(avq_ses.name) like upper('&userpattern') or trim('&userpattern')='%')
   and (upper(avq_ses.hostname) like upper('&hostpattern') or trim('&hostpattern')='%')
   and (upper(module) like upper('&modulpattern') or trim('&modulpattern')='%')
   and (s.sid like '&session_id' or trim('&session_id')='%')
   --and status like decode('&ifactive','Y','ACTIVE','N','%ACTIVE%')
   and ( s.status like decode('&ifactive','Y','ACTIVE','N','%ACTIVE%') and (wait_class <> decode('&ifactive','Y','Idle','N','%') or upper('&ifactive') = 'N'))
   order by 2 asc
   ;

UNDEF session_id
UNDEF userpattern
UNDEF hostpattern
UNDEF modulpattern

