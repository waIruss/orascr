set line 240
set pagesize 200
set verify off

col sample_time form A13
col bgp form A7
col max_pga_gb form 990D00
col bar form A185

accept bgp prompt 'Enter BGP number (default: %): ' default '%'
accept last_days prompt 'Enter last days (default: 1): ' default '1'
accept HR_FMT prompt 'Enter time format for grouping (default: HH24): ' default 'HH24'

with b as (
  select obj_id as bgp, instn_id as bgp_instn, session_sid session_id, session_serial#, started as start_time
  --, stopped as stp
    ,nvl(nvl(stopped,lead(started) over(partition by obj_id,instn_id order by started)),sysdate)  - interval '1' second  end_time
  from
  (
    select * from
      (select timestp,obj_id,instn_id,session_sid,session_serial#,action from k.bgp_log where action like '%ed' and timestp > sysdate - (&last_days+1)) b
      pivot (
        max(timestp) for action in('Started' as started, 'Stopped' as stopped)
      )
    order by obj_id,started desc
  )
  where obj_id=&bgp
)
, a as (
  select /*+ parallel(4) */sample_time
    --,substr(job_name,9,7) bgp
    ,bgp
    ,sum(round(pga_allocated/1024/1024/1024,2)) pga_gb
    ,count(*) ses_cnt
  from dba_hist_active_sess_history ash, b
  --where ash.session_id||','||ash.session_serial#=j.session_id and  ash.sample_time between j.start_time and j.end_time
  where ash.session_id=b.session_id and ash.session_serial#=b.session_serial# and  ash.sample_time between b.start_time and b.end_time
  and sample_time > sysdate-&last_days
  group by sample_time,bgp
    --,substr(job_name,9,7)
  order by 1
)
select to_char(sample_time,'MM/DD &HR_FMT') sample_time,to_char(bgp) bgp
  ,max(pga_gb) max_pga_gb
  ,max(ses_cnt) ses_cnt
  ,lpad('*',max(pga_gb),'*') bar
from a
group by bgp,to_char(sample_time,'MM/DD &HR_FMT')
order by bgp,sample_time;


undef bgp
undef last_days

