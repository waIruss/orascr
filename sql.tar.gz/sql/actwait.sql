set line 200 pagesize 200 verify off
col sid_ser FORM A12
col c# FORM 99
col username FORM A10
col program FORM A12
col osinfo FORM A15
col obj FORM A15
col process FORM A10
col sql_id FORM A13
col event FORM A25
col wait_class_event FORM A38
col wait_class FORM A13
col p1 FORM 999999999999
col p2 FORM 999999999999

col obj_col new_val obj_col noprint

SELECT
  CASE status
    WHEN 'OPEN' THEN
      q'[CASE WHEN s.ROW_WAIT_OBJ# > 0 THEN (SELECT object_name FROM dba_objects WHERE data_object_id = s.ROW_WAIT_OBJ#) ELSE To_Char(s.ROW_WAIT_OBJ#) END obj,]'
    ELSE ' '
  END obj_col
FROM v$instance;

SELECT s.sid||','||s.serial# sid_ser,
  s.username, s.program,
  s.osuser||'@'||s.machine osinfo,
  s.process,
  decode(s.state,'WAITING',s.wait_class||': '||s.event,'ON CPU') wait_class_event,
  decode(s.state,'WAITING',s.p1,null) p1,
  decode(s.state,'WAITING',s.p2,null) p2,
  s.seconds_in_wait sec_in_wait,
  --CASE WHEN s.ROW_WAIT_OBJ# > 0 THEN (SELECT object_name FROM dba_objects WHERE data_object_id = s.ROW_WAIT_OBJ#) ELSE To_Char(s.ROW_WAIT_OBJ#) END obj,
  &obj_col
  s.sql_id, s.sql_child_number c#
FROM v$session s
WHERE --s.wait_class <> 'Idle'
  status='ACTIVE'
  and (
    state!='WAITING'
    or
    (state='WAITING' and wait_class!='Idle')
  )
ORDER BY s.seconds_in_wait DESC;

undef obj_col
col obj_col clear

