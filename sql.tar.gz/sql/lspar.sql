-------------------------------------------------------------------------------
--
-- DESCRIPTION: 
--    Show spfile parameter values (optionally hidden parameters as well)
--
-------------------------------------------------------------------------------

define param=&1

column sid form A6 trunc
column name form A30
column type form A11
column spfile_value form A30
column sys_value like spfile_value 
column current_value like spfile_value
column isdefault form A12 heading "Is default|in spfile?"
column ismodified form A12 heading "Is modified?"
column isses_mod form A11 heading "Is Session|modifiable?"
column issys_mod form A11 heading "Is System|modifiable?"

set linesize 200 pagesize 200 verify off feedback off

ACCEPT SHOW_HIDDEN PROMPT 'Show hidden params? (y/n) [n]: ' DEFAULT 'N' 

select 
  spfp.sid,
  name,
  spfp.type,
  sesp.display_value current_value,
  --sysp.display_value sys_value,
  spfp.display_value spfile_value,
  --spfp.isspecified,
  sesp.isdefault,
  decode(sesp.ismodified,'MODIFIED','SESSION','SYSTEM_MOD','SYSTEM',sesp.ismodified) ismodified,
  sesp.isses_mod,
  sesp.issys_mod
from (
   select 
     name,type,value,display_value,
     isdefault,isses_modifiable isses_mod, issys_modifiable issys_mod, ismodified 
   from v$system_parameter where lower(name) like lower('%&param%')
   ) sysp inner join 
   (
   select 
     name,type,value,display_value,
     isdefault,isses_modifiable isses_mod, issys_modifiable issys_mod, ismodified 
   from v$parameter where lower(name) like lower('%&param%')
   ) sesp using(name)
   inner join 
   (
   select distinct 
     sid,name,type,
     listagg(display_value,',') within group (order by ordinal) over(partition by sid,name) display_value,
     isspecified 
   from v$spparameter where lower(name) like lower('%&param%') 
   ) spfp using(name)
order by name,sid;


col name form A40 
col value form A10 
col description form A60 

set heading off 
select chr(27)||'[31m'||chr(27)||'[1;'||chr(31)||
'================================================================='
from dual  
where 'Y' = upper(trim('&SHOW_HIDDEN'))
union all 
select 
'   Hidden params like "&param"' 
from dual
where 'Y' = upper(trim('&SHOW_HIDDEN'))
union all
select 
'================================================================='
--|| chr(27)||'[0m'
from dual
where 'Y' = upper(trim('&SHOW_HIDDEN'));

set heading on

select 
  a.ksppinm name, 
  decode (a.ksppity, 1, 'boolean', 2, 'string', 3, 'number', 4, 'file', a.ksppity) type, 
  b.ksppstvl value, 
  b.ksppstdf isdefault, 
  a.ksppdesc description 
from sys.x$ksppi a, sys.x$ksppcv b 
where a.indx = b.indx 
and lower(a.ksppinm) like lower('\_%&param%') escape '\'
and 'Y' = upper(trim('&SHOW_HIDDEN'));  

set heading off

select 
chr(27)||'[0m'
from dual
where 'Y' = upper(trim('&SHOW_HIDDEN')); 

set heading on feedback 6
undef SHOW_HIDDEN param 1

