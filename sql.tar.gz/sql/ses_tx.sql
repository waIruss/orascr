
set verify off
prompt Define SID:
define SID=&1


set linesize 160
col start_time form a15
col logon_user form a10
col owner form a10
col table_name form a20
col operation form a10
col sid form 99999
col undo_sql form a50 truncated

prompt 
prompt Operation count per segment
select to_char(start_timestamp,'dd-mm-yy hh24:mi') start_time,
	vs.sid,
	logon_user,
	table_owner owner,
	table_name,
	operation, 
	count(*) 
from flashback_transaction_query ftq,
	v$transaction vt,
	v$session vs 
where ftq.xid = vt.xid and vt.ses_addr=vs.saddr and vs.sid=&SID 
group by to_char(start_timestamp,'dd-mm-yy hh24:mi'),vs.sid,logon_user,table_owner,table_name,operation 
order by 7; 

Prompt Detailed SQL
select to_char(start_timestamp,'dd-mm-yy hh24:mi') start_time,logon_user,table_owner owner,table_name,undo_change# undo_chg#,operation, undo_sql 
from flashback_transaction_query ftq,
  v$transaction vt,
  v$session vs 
where ftq.xid = vt.xid 
  and vt.ses_addr=vs.saddr 
  and vs.sid=&SID;


undef SID
undef 1