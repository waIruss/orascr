----------------------------------------------------------------------
-- Simple script to save output of sql script to CSV file
-- Usage: @sql2csv <sqlscript.sql> <output.csv>
----------------------------------------------------------------------
whenever sqlerror exit 2
set trimspool on
set feedback off linesize 10000
set termout off
set echo off
set pagesize 0
set verify off

def SQLSCRIPT=&1
def CSVFILE=&2

set markup csv on
spool &CSVFILE

@&SQLSCRIPT

spool off
set markup csv off


