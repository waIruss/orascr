set serveroutput on format wrapped
set line 250 pagesize 300
set verify off
set termout off
def DT_FMT_ISO_S="YYYY-MM-DD"

col day new_val day noprint
col host new_val host noprint
col inst_name new_val inst_name noprint
select to_char(sysdate,'&DT_FMT_ISO_S') day,host_name as host,instance_name as inst_name from v$instance;
set termout on
set feedback off

ACCEPT day  DEFAULT '&day'  PROMPT 'Enter date as &&DT_FMT_ISO_S [&day]: '
ACCEPT func  DEFAULT 'avg'  PROMPT 'Choose function to aggregate CPU util over time intervals avg/min/max [avg]: '


declare
   cursor c1 is
      with c as (
      select
      --to_char(end_time,'YYYY-MM-DD HH24:MI') time_
      cast(end_time as timestamp) as time_
      ,sum(round((value/100)/threads,4))*100 cpu_pct
      ,cores
      ,threads cpu_count
      from dba_hist_sysmetric_history, (select cpu_core_count_current cores,cpu_count_current threads from v$license) cpu
      where metric_name in('Background CPU Usage Per Sec','CPU Usage Per Sec')
      and group_id=2
      and trunc(end_time) = trunc(to_date('&day','&DT_FMT_ISO_S'))
      group by
      end_time
      ,cores,threads
      --order by end_time
      )
      select trunc(time_, 'hh24') + numtodsinterval( floor ( extract ( minute from time_ ) / 10 ) * 10 , 'minute') ival
         ,round(&func (cpu_pct)) cpu_pct
         ,round(&func (cpu_pct)/2) cpu_pos
      from c
      group by trunc(time_, 'hh24') + numtodsinterval( floor ( extract ( minute from time_ ) / 10 ) * 10 , 'minute')
      order by ival;
   TYPE tCpuData is table of c1%rowtype;
   CpuData tCpuData;
   TYPE tCol IS VARRAY(53) OF VARCHAR2(19);
   tmpCol tCol := tCol();
   emptyCol tCol := tCol();
   TYPE tGraph IS TABLE OF tCol;
   Graph tGraph := tGraph();
   vChar CHAR(1);
   vY PLS_INTEGER := 53;
   vHour char(2);
   vPrevHour char(2);
   j pls_integer;
begin
   dbms_output.put_line(lpad('-',150,'-'));
   dbms_output.put_line(lpad(' ',40,' ')||'&host [&inst_name.] CPU utilization on &day');
   dbms_output.put_line(lpad('-',150,'-'));
   dbms_output.put_line(' ');
   open c1;
   fetch c1 bulk collect into CpuData;
   close c1;
   Graph.extend;

   for i in 1..53 loop
      emptyCol.extend;
      emptyCol(i) := ' ';
   end loop;

   for i in 1..53 loop
      tmpCol.extend;
      if mod(i-3,5) = 0 then
         tmpCol(i) := lpad(to_char((i-3)*2)||'|',4,' ');
      else
         tmpCol(i) := '   |';
      end if;
   end loop;
   tmpCol(3) := '  0|';


   Graph(1) := tmpCol;
   vPrevHour := to_char(CpuData(1).ival,'HH24');

   for i in CpuData.first..CpuData.last loop

      tmpCol := emptyCol;
      vHour := to_char(CpuData(i).ival,'HH24');
      if vHour != vPrevHour then
         tmpCol(1) := substr(vHour,2,1);
         tmpCol(2) := substr(vHour,1,1);
      end if;
      tmpCol(3) := '-';
      j := 4;
      while j <= CpuData(i).cpu_pos+4 loop
         tmpCol(j) := '*';
         j := j+1;
      end loop;
      Graph.extend;
      Graph(i+1) := tmpCol;
      vPrevHour := vHour;
   end loop;

   for k in reverse 1..53 loop
      for i in 1..Graph.Count loop
         dbms_output.put(Graph(i)(k));
      end loop;
      dbms_output.put_line('');
   end loop;
end;
/


set feedback 6

