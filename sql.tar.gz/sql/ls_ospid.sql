
def ospid=&1

set line 220 pagesize 100
set verif off

col sid_serial form A16
col spid form A8
col client_info form A160

select s.sid||','||s.serial# as sid_serial
  ,p.spid
  ,p.pname
  ,' <- user: '||s.username||' - prog: '||s.program||', osuser: '||s.osuser||'@'||s.machine||', client_pid: '||s.process||', client_port:'||s.port client_info
from v$session s, v$process p
where s.paddr = p.addr
  and p.spid=trunc('&ospid')
;

undef ospid


