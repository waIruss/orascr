set linesize 200
col tablespace form A10 
col USERNAME form A15 
col "MB Used" form 999G999 
col SID_SER form A12 
col OSUSER form A20 
col PROGRAM form A20 
col sql_id form A15 

SELECT * FROM 
(
   SELECT 
      su.tablespace,
      s.sid||','||s.serial# AS sid_ser,
      su.username,
      s.osuser||'@'||s.machine "OSUSER", 
      s.program,
      su.segtype,
      su.contents,
      su.sql_id_tempseg sql_id, 
      sum(su.blocks*dt.block_size)/1024/1024 "MB Used" 
   FROM v$tempseg_usage su, dba_tablespaces dt, v$session s 
   WHERE dt.tablespace_name=su.tablespace 
      AND dt.CONTENTS='TEMPORARY' 
      AND su.session_addr=s.saddr
   GROUP BY su.tablespace,s.sid||','||s.serial#,su.username,s.osuser||'@'||s.machine, s.program, su.segtype,su.contents, su.sql_id_tempseg
   ORDER BY 9 desc 
) 
WHERE ROWNUM < 11; 
