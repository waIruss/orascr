set line 200 pagesize 100
col lock_path form a25
col sid_serial form a13
col username form a15
col osinfo form a15 trunc
col program form a15 trunc
col wait_class form a12 trunc
col event form a25 trunc
col wait_time form a12
col obj_wait form A28
col sql_id form a13 


select 
  lpad(' ', level-1)||ltrim(sys_connect_by_path(wc.sid, '->'),'->')||'['||wc.num_waiters||']' lock_path,
  wc.chain_id,
  --wc.chain_signature,
  --nvl2(wc.blocker_sid,wc.blocker_sid||','||wc.blocker_sess_serial#||'@'||wc.blocker_instance,null) blocker,
  wc.sid||','||wc.sess_serial#||'@'||wc.instance sid_serial,
  --wc.num_waiters waiters#,
  s.username,s.osuser||'@'||s.machine osinfo
  --,s.program
  ,case when s.program like 'oracle%(J%' then (select job_name from dba_scheduler_running_jobs rj where rj.session_id=s.sid) else s.program end program
  ,Nvl(s.sql_id,s.prev_sql_id) sql_id,
  wc.wait_event_text event,
  --wc.sid,wc.sess_serial#,wc.instance,
  --wc.blocker_is_valid,
  --wc.blocker_sid,wc.blocker_sess_serial#,wc.blocker_instance,
  case when wc.row_wait_obj# > 0 then (select object_type||' - '||object_name from dba_objects where data_object_id = wc.row_wait_obj#) ||chr(10) else null end|| 
  case when wc.row_wait_row# > 0 then ('ROWID: '||dbms_rowid.rowid_create(1,wc.row_wait_obj#,wc.row_wait_file#,wc.row_wait_block#,wc.row_wait_row#)) else null end obj_wait,
  --wc.in_wait_secs,
  --lpad(floor(in_wait_secs/60/60)|| 'hr '||floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60) || 'min '|| (in_wait_secs-(floor(in_wait_secs/60/60)*60*60)-(floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60)*60)) ||'s',15,' ') as wait_time 
  --lpad(replace(to_char(floor(in_wait_secs/60/60),'990')|| ':'||to_char(floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60),'00') || ':'|| to_char((in_wait_secs-(floor(in_wait_secs/60/60)*60*60)-(floor((in_wait_secs-(floor(in_wait_secs/60/60)*60*60))/60)*60)),'00'),' ',''),10,' ') as wait_time
  cast(numtodsinterval(wc.in_wait_secs,'SECOND') as interval day(0) to second(0)) wait_time
from v$wait_chains wc,
 gv$session s
 --gv$session bs
where 
 wc.sid = s.sid (+) and wc.sess_serial# = s.serial# (+)
 --and (s.final_blocking_instance = bs.inst_id (+) and s.final_blocking_session = bs.sid (+)) 
 and( 
      num_waiters > 0 or ( blocker_osid is not null and in_wait_secs > 1) 
    )
connect by prior wc.sid=wc.blocker_sid and prior wc.sess_serial#=wc.blocker_sess_serial# and prior wc.instance=wc.blocker_instance start with wc.blocker_is_valid='FALSE'
order by chain_id,num_waiters desc;

