set linesize 250 pagesize 200 verif off

def OWNER=&1
def TABLE_NAME=&2

col table_name form A30
col constraint_name form A30
col status form A8 heading "STATUS"
col delete_rule form A10 heading "Delete|rule"
col validated form A12 trunc
col r_owner form A10
col r_constraint_name form A30
col ref_cols form A70

prompt
prompt =============================================================================
prompt  Foreign key constraints for: &OWNER..&TABLE_NAME
prompt =============================================================================

select table_name,constraint_name,status,delete_rule,validated
  ,r_constraint_name
  ,(select listagg(column_name,',') from dba_cons_columns dcc where dcc.owner=dc.owner and dcc.constraint_name=dc.constraint_name and dcc.table_name=dc.table_name)||' -> '||
   (select listagg(table_name||'.'||column_name,',') from dba_cons_columns dcc where dcc.owner=dc.r_owner and dcc.constraint_name=dc.r_constraint_name) ref_cols
from dba_constraints dc
where dc.owner=upper(trim('&OWNER'))
  and dc.table_name=upper(trim('&TABLE_NAME'))
  and dc.constraint_type = 'R'
order by table_name;

prompt
prompt =============================================================================
prompt  Incoming Foreign key constraints for: &OWNER..&TABLE_NAME
prompt =============================================================================

select table_name,constraint_name,status,delete_rule,validated
  ,r_constraint_name
  ,(select listagg(table_name||'.'||column_name,',') from dba_cons_columns dcc where dcc.owner=dc.owner and dcc.constraint_name=dc.constraint_name and dcc.table_name=dc.table_name)||' -> '||
   (select listagg(column_name,',') from dba_cons_columns dcc where dcc.owner=dc.r_owner and dcc.constraint_name=dc.r_constraint_name) ref_cols
from dba_constraints dc
where (r_owner,r_constraint_name)
  in (select owner,constraint_name
        from dba_constraints dc2
        where dc2.owner=upper(trim('&OWNER'))
          and dc2.table_name=upper(trim('&TABLE_NAME'))
          and dc2.constraint_type in('P','U')
      )
order by table_name;


