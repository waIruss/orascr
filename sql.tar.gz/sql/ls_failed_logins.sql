set line 200 pagesize 50
col timestamp_ form A18
col dbusername form A30
col os_user form A10
col userhost form A30
col client_program_name form A40
col return_code form 99999
col host_addr form A18

select * from (
select * from (
  select
    to_char(event_timestamp,'YYYY-MM-DD HH24:MI') timestamp
    ,dbusername
    ,os_username os_user
    ,userhost
    ,client_program_name
    ,return_code
    --,authentication_type
    ,regexp_substr(authentication_type,'HOST=[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}') host_addr
  from unified_audit_trail
  where return_code=1017
  order by event_timestamp desc
) where rownum <=100 )
order by timestamp asc;

