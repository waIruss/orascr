set line 200 pagesize 200 feedback off
col param_name form A25
col param_value form A25
col tablespace_name form A12 heading TABLESPACE
col retention form A12
col file_name form A50
col size_gb form 999G990D0 heading "Size GB"
col free_gb form 999G990D0 heading "Free GB"
col max_gb form 999G999D0 heading "Max GB"
col pct_used_max form 90D09 heading  "% Used Max" 
col MB form 999G999D0 heading "MB"
col incr_mb form 9G999D0 heading "Incr MB"
col undoseg_status form A16


SELECT name as param_name,value as param_value 
FROM v$parameter WHERE name LIKE 'undo%';

SELECT tablespace_name,retention 
FROM dba_tablespaces WHERE CONTENTS='UNDO';

compute sum of size_gb on tablespace_name
compute sum of free_gb on tablespace_name
compute sum of max_gb on tablespace_name
compute sum of pct_used_max on tablespace_name
break on tablespace_name skip page
--break on report

WITH free_spc AS (
  SELECT file_id,Sum(bytes) fbytes FROM dba_free_space WHERE tablespace_name IN(SELECT tablespace_name FROM dba_tablespaces WHERE CONTENTS='UNDO') GROUP BY file_id
)
SELECT tablespace_name,file_id,dbf.file_name,
  Round(dbf.bytes/1024/1024/1024,2) size_gb, 
  Round(Nvl(fbytes,0)/1024/1024/1024,2) free_gb,
  Round(dbf.increment_by*t.block_size/1024/1024) incr_mb,
  Round(Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)/1024/1024/1024,2) max_gb,
  Round((Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)-Nvl(fbytes,0)-Decode(dbf.maxbytes,0,0,dbf.maxbytes-dbf.bytes))
  /Decode(dbf.maxbytes,0,dbf.bytes,dbf.maxbytes)*100,2) pct_used_max
FROM dba_data_files dbf 
  JOIN dba_tablespaces t USING(tablespace_name)
  left OUTER JOIN free_spc USING(file_id)
WHERE t.CONTENTS='UNDO'
order by tablespace_name,file_id;

clear breaks
clear computes

WITH undo_segs AS(
SELECT tablespace_name,status as undoseg_status,round((bytes/1024/1024),2) MB 
FROM dba_undo_extents 
)
SELECT tablespace_name,Nvl(active,0) active,Nvl(unexpired,0) unexpired,Nvl(expired,0) expired 
FROM undo_segs 
pivot
  (
    sum(mb) for undoseg_status in('ACTIVE' AS active,'UNEXPIRED' AS unexpired,'EXPIRED' AS expired)
  );

prompt
set feedback 6
