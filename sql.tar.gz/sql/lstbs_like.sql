define TBS_PATTERN=&1
compute sum of alloc_gb on report
compute sum of used_gb on report
compute sum of free_gb on report
compute sum of max_gb on report
compute sum of files# on report
break on report
set line 200 pagesize 200 verify off

col tablespace_name form A20
col files# form 999 heading "df#"
col contents form A4 heading "Cont" trunc
col block_size form A4 heading "Blk|size"
col extent_management form A8 heading "Extent|mgmt"
col allocation_type form A8 heading "Alloc|type"
col segment_space_management form A8 heading "Segment|mgmt"
col alloc_gb form 999G990D0 heading "Alloc GB"
col used_gb form 999G990D0 heading "Used GB"
col free_gb form 999G990D0 heading "Free GB"
col max_gb form 999G990D0 heading "Max GB"
col max_free_gb form 999G990D0 heading "Max|Free GB"
col autoext form A4 heading "Auto|ext"
col pct_used form 990D09 heading "% Used"
col pct_usedmax form 990D09 heading "% Used|Max"
col bigfile form A5 heading "BigF"
col encrypted form A4 heading "Encr"

SELECT tablespace_name,files#,contents,block_size/1024||'K' block_size,extent_management,allocation_type,segment_space_management,bigfile,encrypted,
   autoext,
   round(alloc_mb/1024,2) as alloc_gb,
   round(used_mb/1024,2) as used_gb,
   pct_used,
   round(free_mb/1024,2) as free_gb,      
   round(max_mb/1024,2) as max_gb,
   round((max_mb-used_mb)/1024,2) as max_free_gb,
   pct_usedmax
   /*
   ,CASE
     WHEN pct_usedmax > 90 THEN 'Critical'
     WHEN pct_usedmax > 80 THEN 'Warning'
     ELSE 'OK'
   END status
   */
FROM (
	SELECT t.tablespace_name,files#,df.autoext,t.contents,t.block_size,t.status,t.extent_management,t.allocation_type,t.segment_space_management,t.bigfile,t.encrypted,
      df.alloc_mb,
		df.alloc_mb-Nvl(fs.free_mb,0) used_mb,
		Nvl(fs.free_mb,0) free_mb,
		df.max_mb,
		Round(((df.alloc_mb-Nvl(fs.free_mb,0))/df.alloc_mb)*100,2) pct_used,
		Round(((df.alloc_mb-Nvl(fs.free_mb,0))/Decode(df.max_mb,0,df.alloc_mb,df.max_mb))*100,2) pct_usedmax
	FROM dba_tablespaces t,
	  (SELECT d.tablespace_name,Count(*) files#,Max(d.autoextensible) autoext,
         Sum(Round(d.bytes/1024/1024,4)) alloc_mb,
         --Sum(Round(d.user_bytes/1024/1024/1024)) used_gb,
         Sum(Round(decode(d.maxbytes,0,d.bytes,d.maxbytes)/1024/1024,4)) max_mb
		FROM dba_data_files d
		GROUP BY d.tablespace_name
	  ) df,
	  (SELECT f.tablespace_name, Sum(Round(f.bytes/1024/1024,4)) free_mb
		FROM dba_free_space f
		GROUP BY f.tablespace_name
	  ) fs
	WHERE t.tablespace_name = df.tablespace_name (+)
	  AND t.tablespace_name = fs.tablespace_name (+)
	  AND t.contents <> 'TEMPORARY'
     AND t.tablespace_name like '&&TBS_PATTERN'
	UNION all
	SELECT t.tablespace_name,files#,df.autoext,t.contents,t.block_size,t.status,t.extent_management,t.allocation_type,t.segment_space_management,t.bigfile,t.encrypted,
		df.alloc_mb,
		Nvl(fs.used_mb,0) used_mb,
		df.alloc_mb-Nvl(fs.used_mb,0) free_mb,
		df.max_mb,
		Round(((fs.used_mb)/df.alloc_mb)*100,2) pct_used,
		Round((Nvl(fs.used_mb,0)/Decode(df.max_mb,0,df.alloc_mb,df.max_mb))*100,2) pct_usedmax
	FROM dba_tablespaces t,
	  (SELECT d.tablespace_name,Count(*) files#,Max(d.autoextensible) autoext,
         Sum(Round(d.bytes/1024/1024,4)) alloc_mb,
         --Sum(Round(d.user_bytes/1024/1024)) used_mb,
         Sum(Round(decode(d.maxbytes,0,d.bytes,d.maxbytes)/1024/1024,4)) max_mb
		FROM dba_temp_files d
		GROUP BY d.tablespace_name
		) df,
	  (SELECT f.tablespace_name, Sum(Round(f.bytes_used/1024/1024,4)) used_mb
      FROM v$temp_extent_pool f
      GROUP BY f.tablespace_name
     ) fs
	WHERE t.tablespace_name = df.tablespace_name (+)
	  AND t.tablespace_name = fs.tablespace_name (+)
	  AND t.contents = 'TEMPORARY'
     AND t.tablespace_name like '&&TBS_PATTERN'
)
ORDER BY 1;

undef 1
clear break
clear compute
