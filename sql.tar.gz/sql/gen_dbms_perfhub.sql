set termout off
set linesize 300
set verify off
set heading off feedback off

whenever sqlerror exit
whenever oserror exit

def DT_FMT_ISO="YYYY-MM-DD HH24:MI"


col bdate new_val bdate noprint
col edate new_val edate noprint
col today new_val today noprint
col dbname new_val dbname noprint
col outfile new_val outfile noprint
col ash_script new_val ash_script noprint

select to_char(sysdate,'YYYYMMDD') today,name dbname
,'dbms_perfhub_'||name||'_'||to_char(systimestamp,'YYYYMMDDHH24MISS')||'.html' as outfile
from v$database;

select
  to_char(greatest(sysdate-1,min(end_interval_time)),'&&DT_FMT_ISO') as bdate,
  to_char(least(sysdate,max(end_interval_time)),'&&DT_FMT_ISO') as edate
from dba_hist_snapshot where end_interval_time > sysdate-1;


set termout on

prompt ==================================================================
ACCEPT bdate  DEFAULT '&bdate'  PROMPT 'Enter start date as &&DT_FMT_ISO [&bdate]: '
ACCEPT edate  DEFAULT '&edate'  PROMPT 'Enter end date as &&DT_FMT_ISO [&edate]: '
ACCEPT replvl  DEFAULT 'typical'  PROMPT 'Enter report level: {basic|typical|all} [typical]: '
ACCEPT out_dir  DEFAULT '../awr/'   PROMPT 'Enter output directory for reports [../awr/ ]: '
prompt ==================================================================

var starttime varchar2(40)
var endtime varchar2(40)

begin
    :starttime := '&bdate';
    :endtime := '&edate';
end;
/


set termout off
host mkdir -p &&out_dir


set pages 0 linesize 32767 trimspool on trim on long 1000000 longchunksize 10000000
set heading off feedback off
spool &&out_dir./&&outfile
select dbms_perf.report_perfhub(
  outer_start_time    => to_date(:starttime,'&DT_FMT_ISO')
 ,outer_end_time      => to_date(:endtime,'&DT_FMT_ISO')
 ,selected_start_time => to_date(:starttime,'&DT_FMT_ISO')
 ,selected_end_time   => to_date(:endtime,'&DT_FMT_ISO')
 ,report_level        => '&replvl'
) report_
from dual;
spool off

set termout on

prompt ==================================================================
prompt Generated report: &&out_dir./&&outfile
prompt ==================================================================
host ls -ltr &&out_dir/&&outfile


