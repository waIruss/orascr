set linesize 220 verif off
set pagesize 100
compute sum of MB on report
break on report
col owner form A10
col segment_name form A50
col segment_type form A15
col mb form 999G999G999G999

ACCEPT OWNER PROMPT 'Enter table owner : '
ACCEPT TABLE PROMPT 'Enter table name : '



SELECT
  ds.owner
  ,ds.segment_type
  ,coalesce(ds.partition_name,ds.segment_name) segment_name
  ,Round(ds.bytes/1024/1024) MB
FROM dba_segments ds, dba_tables dt
WHERE dt.owner = '&&OWNER'
  AND dt.table_name = '&&TABLE'
  AND dt.table_name=ds.segment_name
  AND dt.owner=ds.owner
UNION ALL
SELECT
  ds.owner
  ,ds.segment_type
  ,coalesce(ds.partition_name,ds.segment_name)
  ,Round(ds.bytes/1024/1024) MB
FROM dba_segments ds, dba_indexes di
WHERE di.table_owner = '&&OWNER'
  AND di.table_name = '&&TABLE'
  AND di.index_name=ds.segment_name
  AND di.owner=ds.owner
UNION ALL
SELECT
  ds.owner
  ,ds.segment_type
  ,coalesce(ds.partition_name,ds.segment_name)|| '['||dl.column_name||'] '
  ,Round(ds.bytes/1024/1024) MB
FROM dba_segments ds, dba_lobs dl
WHERE dl.owner = '&&OWNER'
  AND dl.table_name = '&&TABLE'
  AND dl.segment_name=ds.segment_name
  AND dl.owner=ds.owner
ORDER BY 4 DESC;

undef table owner
clear breaks 
clear computes
