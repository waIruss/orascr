-------------------------------------------------------------------------------
-- Script will create manual AWR snapshot when databse is in restricted mode
-- In non-restricted mode, script will do nothing
-------------------------------------------------------------------------------

set serveroutput on
declare
   v_logins varchar2(100);
   v_awr_snap_ex exception;
   pragma exception_init(v_awr_snap_ex,-13516);
begin
   select logins into v_logins from v$instance;
   if upper(v_logins) = 'RESTRICTED' then
      dbms_workload_repository.create_snapshot;
      dbms_output.put_line(to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')||' - snapshot created');
   else
      dbms_output.put_line(to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')||' - restricted session disabled - skipping manual snapshot creation');
   end if;
exception
   when v_awr_snap_ex then
      if upper(v_logins) = 'RESTRICTED' then
         dbms_workload_repository.control_restricted_snapshot(allow=>true);
         dbms_workload_repository.create_snapshot;
         dbms_output.put_line(to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')||' - snapshot created');
      end if;
end;
/

