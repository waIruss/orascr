
PROMPT ==========================================================================
PROMPT Online and Standby redo logs
PROMPT ==========================================================================
col type form A8
col status form A10
col gr# form 99
col th# form 99
col mb form 99G999
col member form A60
col first_time form A15
col first_change# form 999999999999999999
set linesize 200 pagesize 200


break on type skip 1 on gr# on th# on mb

select *
from
  (
    select lf.type,
      lf.group# gr#,
      l.thread# th#,
      (l.bytes/1024/1024) mb,
      l.status,      
      lf.member,
      l.archived,
      to_char(l.first_time,'Mon-DD HH24:MI:SS') first_time,
      first_change#
    from v$logfile lf,
      v$log l
    where l.group#=lf.group#
      and lf.type = 'ONLINE'
    union all
    select lf.type,
      lf.group#,
      l.thread#,
      (l.bytes/1024/1024) mb,
      l.status,
      lf.member,
      l.archived,
      to_char(l.first_time,'Mon-DD HH24:MI:SS') first_time,
      first_change#
    from v$logfile lf,
      v$standby_log l
    where l.group#=lf.group#
      and lf.type = 'STANDBY'
  )
order by type,
  th#,
  gr#,
  member; 
