set line 240
set pagesize 200
def indx=&1
col indx form 99999
col qksxareasons form A150

select indx,qksxareasons from x$qksxa_reason where indx = &indx;

