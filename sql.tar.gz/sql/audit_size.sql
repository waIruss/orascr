set linesize 200
COLUMN event_timestamp FORMAT A30

SELECT to_char(event_timestamp,'YYYY-MM-DD'),
       count(*)
FROM   unified_audit_trail
group by to_char(event_timestamp,'YYYY-MM-DD')
ORDER BY 1 asc;

select sum(bytes)/1024/1024/1024 from dba_segments where segment_name = 'AUD$UNIFIED';
