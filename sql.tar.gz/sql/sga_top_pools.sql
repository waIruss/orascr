set line 200 pagesize 200
column pool form A20 
column name form A25 
column mb form 999G999 
column total_pool_mb form 999G999 
column total_sga_mb form 999G999 
break on pool skip page
compute sum of mb on pool
compute sum of pool_pct on pool

select 
   pool,
   name,
   round(bytes/1024/1024,2) mb,
   pool_pct,
   round(total_pool/1024/1024,2) total_pool_mb, 
   round(total_sga/1024/1024) total_sga_mb 
from 
(
   select 
      nvl(pool,name) as pool,name,bytes
      ,row_number() over(partition by nvl(pool,name) order by bytes desc) rn
      ,round(ratio_to_report(bytes) over(partition by nvl(pool,name))*100,2) as pool_pct
      ,sum(bytes) over(partition by nvl(pool,name)) total_pool
      ,sum(bytes) over() total_sga        
from v$sgastat
) where rn <= 5
order by 1,3 desc;

clear break
clear compute