-------------------------------------------------------------------------------
--
-- DESCRIPTION: 
--    Display monitored SQL executions from last hour
--    DIAGNOSTIC and TUNNING  packs are required
-- Usage:
--   @sqlmon <sql_id>  [Y|N]
--   sql_id - enter '%' to display all monitored SQLs
--   Y|N - whether to display sql_text (default: N)
-------------------------------------------------------------------------------   
set line 240 pagesize 1000 verify off
col status FORM A15
col sid_ser FORM A12
col px FORM 99
col username FORM A10
col status form A12 heading STATUS
col module FORM A15
col sql_id FORM A23
col "Time (sec)" FORM A18
col "IO" FORM A12
col elapsed format A16 head "Elapsed" 
col last_dt FORM A12
col sql_text form A60 wor

set feedback off

def sql_id='&1'
-- optional params
col par2 new_val 2 noprint

select 'dummy' par2 from dual where 1 <> 1;
col show_sql new_val show_sql noprint
select case when '&2' is not null then '&2' else 'N' end show_sql from dual;


col show_sql new_val show_sql noprint
select decode(upper('&&2'),'Y',',sql_text','') show_sql from dual;

whenever sqlerror exit failure;

declare 
  v_pval varchar2(4000);
begin
  select upper(value) into v_pval 
    from v$parameter
     where upper(name)='CONTROL_MANAGEMENT_PACK_ACCESS';
  if v_pval != 'DIAGNOSTIC+TUNING' then
    raise_application_error(-20001, 'License for Tuning Pack is required to use this script!');
  end if;
end;
/

whenever sqlerror continue;

set termout on
set feedback on


SELECT To_Char(last_refresh_time,'MM/DD HH24:MI') last_dt,
  CASE WHEN status LIKE '%ERROR%' THEN status||Chr(10)||error_message ELSE status END status,
  sid_ser,px# px,username,module, --sql_id,plan_hash,
  'sql_id:  '||sql_id||Chr(10)||
  'Plan_HV: '||LPad(plan_hash,13,' ')||Chr(10)||
  'exec_id: '||LPad(sql_exec_id,13,' ') sql_id,
  'Elapsed: '||LPad(elapsed_sec,8,' ')||Chr(10)||
  'CPU:     '||LPad(cpu_sec,8,' ')||Chr(10)||
  Decode(user_io_sec,0,NULL,
    'User IO: '||LPad(user_io_sec,8,' ')||Chr(10))||
  Decode(application_wait_sec,0,NULL,
    'App_wait:'||LPad(application_wait_sec,8,' ')||Chr(10))||
  Decode(concurrency_sec,0,NULL,
    'Concurr: '||LPad(concurrency_sec,8,' ')||Chr(10))||
  Decode(cluster_wait_sec,0,NULL,
    'Cluster: '||LPad(cluster_wait_sec,8,' ')||Chr(10))||
  Decode(java_exec_sec,0,NULL,
    'Java:    '||LPad(java_exec_sec,8,' ')||Chr(10))||
  Decode(plsql_exec_sec,0,NULL,
    'PLSQL:   '||LPad(plsql_exec_sec,8,' ')) AS "Time (sec)",
  'LIO: '||LPad(buff_gets,6,' ')||Chr(10)||
  'PhR: '||LPad(phy_read,6,' ')||Chr(10)||
  'PhW: '||LPad(phy_write,6,' ') AS "IO",
  cast(numtodsinterval(elapsed_sec,'SECOND') as interval day(0) to second(1)) elapsed
  &&show_sql
FROM(
  SELECT status,sid||','||session_serial# sid_ser, PX_SERVERS_ALLOCATED px#, username,MODULE,
    sql_id,sql_plan_hash_value plan_hash,sql_exec_id,
    Round(elapsed_time/1000000,1) elapsed_sec,
    Round(cpu_time/1000000,1) cpu_sec,
    Round(application_wait_time/1000000,1) application_wait_sec,
    Round(concurrency_wait_time/1000000,1) concurrency_sec,
    Round(cluster_wait_time/1000000,1) cluster_wait_sec,
    Round(java_exec_time/1000000,1) java_exec_sec,
    Round(user_io_wait_time/1000000,1) user_io_sec,
    Round(plsql_exec_time/1000000,1) plsql_exec_sec,
    buffer_gets,disk_reads,
    CASE 
      WHEN (buffer_gets*(SELECT Max(Value) FROM v$parameter WHERE name = 'db_block_size')) < 1024*1024 THEN
        Round((buffer_gets*(SELECT Max(Value) FROM v$parameter WHERE name = 'db_block_size'))/1024)||'K'
      WHEN (buffer_gets*(SELECT Max(Value) FROM v$parameter WHERE name = 'db_block_size')) < 1024*1024*1024 THEN
        Round((buffer_gets*(SELECT Max(Value) FROM v$parameter WHERE name = 'db_block_size'))/1024/1024)||'M'
      WHEN (buffer_gets*(SELECT Max(Value) FROM v$parameter WHERE name = 'db_block_size')) < 1024*1024*1024*1024 THEN
        Round((buffer_gets*(SELECT Max(Value) FROM v$parameter WHERE name = 'db_block_size'))/1024/1024/1024)||'G'
      ELSE
        Round((buffer_gets*(SELECT Max(Value) FROM v$parameter WHERE name = 'db_block_size'))/1024/1024/1024/1024)||'T'
    END buff_gets, 
    CASE 
      WHEN physical_read_bytes < 1024*1024 THEN
        Round(physical_read_bytes/1024)||'K'
      WHEN physical_read_bytes < 1024*1024*1024 THEN
        Round(physical_read_bytes/1024/1024)||'M'
      WHEN physical_read_bytes < 1024*1024*1024*1024 THEN
        Round(physical_read_bytes/1024/1024/1024)||'G'
      ELSE
        Round(physical_read_bytes/1024/1024/1024/1024)||'T'
    END phy_read, 
    CASE 
      WHEN physical_write_bytes < 1024*1024 THEN
        Round(physical_write_bytes/1024)||'K'
      WHEN physical_write_bytes < 1024*1024*1024 THEN
        Round(physical_write_bytes/1024/1024)||'M'
      WHEN physical_write_bytes < 1024*1024*1024*1024 THEN
        Round(physical_write_bytes/1024/1024/1024)||'G'
      ELSE
        Round(physical_write_bytes/1024/1024/1024/1024)||'T'
    END phy_write, 
    error_message,last_refresh_time,sql_text
  FROM v$sql_monitor 
  WHERE px_qcsid IS NULL 
    and sql_id like lower(trim('&sql_id'))
   --AND last_refresh_time > SYSDATE - INTERVAL '60' MINUTE
   order by last_refresh_time desc
  )
--ORDER BY last_refresh_time DESC
where rownum <=20
;


set feedback 6
undef show_sql 1
