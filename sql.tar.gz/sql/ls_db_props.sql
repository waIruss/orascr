set pagesize 200 linesize 200
col property_name form a30
col property_value form a60

select property_name,property_value 
from database_properties 
order by property_name;
