set verify off feedback off
set serveroutput on
set linesize 250 pagesize 800 long 100000


col elapsed form A11
col cpu_time form A11
col app_time form A11
col cc_time form A11
col io_time form A11
col plsql_time form A11
col module form A35
col status form A20


def sql_id=&1

prompt ==========================================================================
prompt Recent monitored executions for sql_id=&sql_id
prompt ==========================================================================

select
  sid
  --,serial#
  --,sql_id
  ,sql_plan_hash_value  plan_hash
  ,sql_exec_id
  ,to_char(sql_exec_start,'YYYY-MM-DD HH24:MI') sql_exec_start
  ,status
  ,module
  ,px_servers_allocated  px#
  --,buffer_gets
  ,lpad(case
    when buffer_gets < 1024 then to_char(buffer_gets)
    when buffer_gets < 1024*1024 then round(buffer_gets/1024)||'K'
    when buffer_gets < 1024*1024*1024 then round(buffer_gets/1024/1024)||'M'
    when buffer_gets < 1024*1024*1024*1024 then round(buffer_gets/1024/1024/1024)||'G'
    else round(buffer_gets/1024/1024/1024/1024)||'T'
   end,'8',' ') buf_gets
 ,lpad(case
    when physical_read_requests < 1024 then to_char(physical_read_requests)
    when physical_read_requests < 1024*1024 then round(physical_read_requests/1024)||'K'
    when physical_read_requests < 1024*1024*1024 then round(physical_read_requests/1024/1024)||'M'
    when physical_read_requests < 1024*1024*1024*1024 then round(physical_read_requests/1024/1024/1024,1)||'G'
    else round(physical_read_requests/1024/1024/1024/1024,1)||'T'
   end,'8',' ') phr_req
  ,lpad(case
    when physical_read_bytes < 1024 then to_char(physical_read_bytes)
    when physical_read_bytes < 1024*1024 then round(physical_read_bytes/1024)||'K'
    when physical_read_bytes < 1024*1024*1024 then round(physical_read_bytes/1024/1024)||'M'
    when physical_read_bytes < 1024*1024*1024*1024 then round(physical_read_bytes/1024/1024/1024,1)||'G'
    else round(physical_read_bytes/1024/1024/1024/1024,1)||'T'
   end,'8',' ') phy_reads
  --, physical_read_requests, physical_read_bytes, physical_write_requests, physical_write_bytes
  ,cast(numtodsinterval(elapsed_time/1000000,'SECOND') as interval day(0) to second(0)) elapsed
  ,cast(numtodsinterval(cpu_time/1000000,'SECOND') as interval day(0) to second(0)) cpu_time
  ,cast(numtodsinterval(application_wait_time/1000000,'SECOND') as interval day(0) to second(0)) app_time
  ,cast(numtodsinterval(concurrency_wait_time/1000000,'SECOND') as interval day(0) to second(0)) cc_time
  ,cast(numtodsinterval(user_io_wait_time/1000000,'SECOND') as interval day(0) to second(0)) io_time
  ,cast(numtodsinterval(plsql_exec_time/1000000,'SECOND') as interval day(0) to second(0)) plsql_time
from v$sql_monitor
where sql_id=trim('&sql_id');

prompt


undef sql_id
undef _sql_id
undef _sql_text
undef _fms
undef 1

col sql_id clear
col sql_text clear
set feedback 6

