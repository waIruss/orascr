set pagesize 100
set verify off
set line 250
set feedback off
whenever sqlerror exit


set pagesize 0
set feedback off

prompt
spool switch_tbs_rw.sql
select 'alter tablespace '||TABLESPACE_NAME||' read write;' from dba_tablespaces where status like 'READ ONLY%';
spool off
prompt
prompt Generated: switch_tbs_rw.sql
prompt

spool switch_tbs_ro.sql
select 'alter tablespace '||TABLESPACE_NAME||' read only;' from dba_tablespaces where status like 'READ ONLY%';
spool off
prompt
prompt Generated: switch_tbs_ro.sql
set feedback on

spool switch_tbs.log

set echo on

@switch_tbs_rw.sql

@switch_tbs_ro.sql

spool off

set echo off
exit;
