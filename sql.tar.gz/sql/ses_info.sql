set line 250 pagesize 200
col sid_ser form A10
col username form A25
col program form A22
col osinfo form A25
col client_pid form A10
col sql_id form A16
col event form A30
col wait_class form A13
col last_activity form a15
col server_pid form A15

def SID=&1

SELECT
   s.sid||','||s.serial# sid_ser,
   s.username,
   nvl2(j.sid,s.program||chr(10)||'job: '||j.job_name,s.program) program,
   s.osuser||'@'||s.machine osinfo,
   s.process client_pid,
   to_char(s.logon_time,'DD-MM-YY HH24:MI') logtime,
   s.port,
   CASE
      WHEN s.server='DEDICATED' THEN
         (SELECT 'DED: '||p.spid FROM v$process p WHERE p.addr=s.paddr)
      ELSE
         (SELECT 'D:'||d.name||', SS: '|| ss.name||' - '||p.spid AS sh_serv
            FROM v$dispatcher d, v$circuit c, v$shared_server ss, v$process p
            WHERE c.dispatcher=d.paddr AND c.server=ss.paddr AND c.saddr=s.saddr AND s.paddr=p.addr
         )
   END server_pid,
   CASE
      WHEN s.status = 'INACTIVE' THEN
         To_Char(SYSDATE-(s.last_call_et*1/24/60/60),'DD-MM-YY hh24:mi')
      WHEN s.status = 'ACTIVE' THEN
         'ACTIVE'
   END LAST_ACTIVITY,
   nvl(to_char(sql_exec_start,'YYYY-MM-DD HH24:MI:SS'),'P:'||to_char(prev_exec_start,'YYYY-MM-DD HH24:MI:SS')) sql_exec_start,
   nvl(sql_id,'P:'||prev_sql_id) sql_id,
   event
FROM v$session s left outer join
  (select rj.session_id sid,rj.session_serial_num serial,job_name,os_process_id
    from dba_scheduler_running_jobs drj, v$scheduler_running_jobs rj
    where drj.session_id=rj.session_id
      and drj.slave_os_process_id=rj.os_process_id
  ) j on (s.sid=j.sid and s.serial#=j.serial)
WHERE s.sid=&SID;

undef SID 1

