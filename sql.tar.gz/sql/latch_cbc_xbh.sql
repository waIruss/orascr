set markup csv on
set feedback off
set line 300
set trimspool on
set pagesize 0
set heading off

spool &1 append
WITH ASH as 
(
SELECT /*+ materialize cardinality(15) */ * FROM (
    SELECT
        event
      --, TRIM(TO_CHAR(p1, 'XXXXXXXXXXXXXXXX')) latch_addr
      , hextoraw(lpad(TRIM(TO_CHAR(p1, 'XXXXXXXXXXXXXXXX')),16,'0')) latch_addr
      , COUNT(*) ash_cnt
    FROM
        v$active_session_history
    WHERE
        event = 'latch: cache buffers chains'
    AND session_state = 'WAITING'
    and sample_time >= sysdate - interval '15' minute
    GROUP BY
        event
      , p1
    ORDER BY
        COUNT(*) DESC
)
WHERE ROWNUM <= 15
) ,
bh_obj as (select
   count(*) over () cnt,
   bh.indx                                 bh_indx,
   bh.hladdr,
   bh.tch                                  touch_count,  -- How often the buffer was accessed. Buffers with high tch are considered «hot blocks» and are expected to be at the end of the LRU list
   bh.lru_flag,
   bh.inst_id,
   file#,
   dbablk                                  block#,
         decode(class,
        1, 'data block'            ,
        2, 'sort block'            ,
        3, 'save undo block'       ,
        4, 'segment header'        ,
        5, 'save undo header'      ,
        6, 'free list'             ,
        7, 'extent map'            ,
        8, '1st level bitmap block',
        9, '2nd level bitmap block',
       10, '3rd level bitmap block',
       11, 'bitmap block'          ,
       12, 'bitmap index block'    ,
       13, 'file header block'     ,
       14, 'unused'                ,
       15, 'system undo header'    ,
       16, 'system undo block'     ,
       17, 'undo header'           ,
       18, 'undo block')                      bh_class,
   ob.name                                 obj_name,
   ob.subname                              obj_subname,
   ow.name                                 obj_owner,
   bp.bp_name                              buffer_pool,
   case when bh.tim != 4294967295 then
        date'1970-01-01'+ bh.tim/24/60/60
   end                                     last_touch_time,
   decode(state,
        0,'free'      , -- Not used
        1,'xcur'      , -- Exclusive (current?)
        2,'scur'      , -- Shared current
        3,'cr'        , -- Consistent read
        4,'read'      , -- Being read into buffer
        5,'mrec'      , -- Media recovery mode
        6,'irec'      , -- Instance recovery mode
        7,'write'     ,
        8,'pi'        , -- Past image (RAC mode)
        9,'memory'    ,
       10,'mwrite'    ,
       11,'donated'   ,
       12,'protected' ,
       13,'securefile',
       14,'siop'      ,
       15,'recckpt'   ,
       16,'flashfree' ,
       17,'flashcur'  ,
       18,'flashna'
    )                                      status_decoded,
/*  0                   xnc,
    0                   forced_reads,
    0                   forced_writes, */
   bh.fp_whr,    
   bh.mode_held,
   bh.changes,
   count(*) over (
      partition by bh.dbarfil,
                   bh.dbablk
   )                                       clone_cnt,
   kc.indx                                 kc_indx,
   kc.dbwr_num                             kc_dbwr_num,
   bh.le_addr,
   decode(bitand(bh.flag,     1),0,'N','Y') dirty,
   decode(bitand(bh.flag,    16),0,'N','Y') temp,
   decode(bitand(bh.flag,  1536),0,'N','Y') ping,
   decode(bitand(bh.flag, 16384),0,'N','Y') stale,
   decode(bitand(bh.flag, 65536),0,'N','Y') direct,
   decode(bitand(bh.flag,524288),0,'N','Y') fts,     -- buffer was read in full table scan (http://www.adp-gmbh.ch/ora/tuning/fts_blocks_in_cache.html)
   bh.flag2,
   bh.rflag,
   bh.sflag,
-- 'N'    new,
   ts#,
   lobid,
   bitand(OBJ_FLAG, 240)/16   cachehint,
   decode(bitand(OBJ_FLAG, 48)/16,
        1, 'KEEP',
        2, 'NONE',
           'DEFAULT'
   )                                       flash_cache, 
   decode(
      bitand(OBJ_FLAG, 192)/64,
      1, 'KEEP',
      2, 'NONE',
         'DEFAULT'
   )                                       cell_flash_cache,
   bh.blsiz / 1024                         block_size_kb,
-- kc.blk_size,
   --
   bh.cr_xid_usn, bh.cr_xid_slt, bh.cr_xid_sqn,
   bh.cr_uba_fil, bh.cr_uba_blk, bh.cr_uba_rec,
   --
   bh.cr_sfl,
   bh.lrba_seq,
   bh.lrba_bno,
   bh.hsub_scn,
   --                                 bas / wrp
   bh.cr_scn_bas , bh.cr_scn_wrp,
   bh.fp_scn_bas , bh.fp_scn_wrp,
   bh.cr_cls_bas , bh.cr_cls_wrp,
   bh.hscn_bas   , bh.hscn_wrp,
   --                                 nxt/prv
   bh.us_nxt     , bh.us_prv,
   bh.wa_nxt     , bh.wa_prv,   
   bh.oq_nxt     , bh.oq_prv,
   bh.aq_nxt     , bh.aq_prv,
   --
   bh.nxt_hash   , bh.prv_hash,
   bh.nxt_repl   , bh.prv_repl,
   --
   bh.obj_flag,
   bh.cr_rfcnt,
   bh.shr_rfcnt,
   --
-- bh.hladdr,                                -- Hash-Latch address, used to join to v$latch_children
   --
   bh.cstate,
   bh.dirty_queue,
   bh.set_ds,
   bh.ba,
   bh.obj
from
   x$bh             bh                                 join
   x$kcbwds         kc on bh.set_ds  = kc.addr         join
   x$kcbwbpd        bp on kc.pool_id = bp.bp_id   left join
   obj$             ob on bh.obj     = ob.dataobj#    left join
   user$            ow on ob.owner#  = ow.user#
)
select 
   to_char(sysdate,'YYYY-MM-DD HH24:MI') sample_time,
   ash_cnt,
   latch_addr,
   bh_obj.obj,
   obj_owner,
   obj_name,
   obj_subname,
   bh_class,
   buffer_pool,
   status_decoded,
   dirty, 
   file#, 
   block#, 
   touch_count,
   changes
from bh_obj, ash
where hladdr=ash.latch_addr
order by touch_count desc
/


spool off
exit;
