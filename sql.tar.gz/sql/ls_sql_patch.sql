set pagesize 200 linesize 250 long 4000
set verif off
col patch_name form A30
col sql_text format A80 wor
col signature format 999999999999999999999
col hint format a50 wrap word

accept sql_patch_name prompt 'Enter SQL patch name (default: %): ' default '%'

break on patch_name skip page on signature on status on force_matching on created on sql_text

select
  p.patch_name,
  p.signature,
  p.status,
  p.force_matching,
  to_char(p.created,'YYYY-MM-DD HH24:MI') created,
  p.sql_text,
  extractvalue(value(hnt),'.') hint
from
  (
  select
    so.name patch_name,
    so.signature,
    so.category,
    so.obj_type,
    so.plan_id,
    st.sql_text,
    ad.created,
    decode(bitand(so.flags, 1), 1, 'ENABLED', 'DISABLED') as status,
    decode(bitand(sq.flags, 1), 1, 'YES', 'NO') as force_matching,
    sod.comp_data
    from
      sqlobj$        so,
      sqlobj$data    sod,
      sql$text       st,
      sqlobj$auxdata ad,
      sql$  sq
    where sod.signature = so.signature
      and st.signature = so.signature
      and st.signature = sod.signature
      and sod.category = so.category
      and sod.obj_type = so.obj_type
      and sod.plan_id = so.plan_id
      and so.signature = ad.signature
      and so.category  = ad.category
      and so.signature = sq.signature
      and so.name like trim('&sql_patch_name')
      and so.obj_type = 3
      and ad.obj_type = 3
    order by ad.created
  ) p,
  table (
    select
      xmlsequence(
        extract(xmltype(p.comp_data),'/outline_data/hint')
      )
    from dual
  ) hnt;


clear breaks

