------------------------------------------------------------------------------
-- Display top n tablespaces segments
-- Usage: @top_tbs_segs <tbs_name> <top_n>
------------------------------------------------------------------------------
set verify off
set line 160
set pagesize 100
col owner form A12
col segment_type form A16
col segment_name form A36
col mb form 999G999G999D00
col pct form 990D00
compute sum of mb on report
compute sum of pct on report
break on report


def TBS_NAME=&1
def TOP_N=&2


select * from (
  select
    s.owner
    ,s.segment_type
    --,s.segment_name
    ,case when segment_type in('LOBSEGMENT','LOB PARTITION') then (select 'LOB: '||table_name||'.'||column_name from dba_lobs l where l.segment_name=s.segment_name and l.owner=s.owner) else s.segment_name end segment_name
    --,to_char(round(s.bytes/1024/1024,2),'fm999G999G990D00') MB
    ,round(s.bytes/1024/1024,2) MB
    ,round(ratio_to_report(s.bytes) over()*100,2) pct
  from dba_segments s
  where tablespace_name = upper(trim('&TBS_NAME'))
  order by bytes desc
) where rownum <=&TOP_N;

undef TBS_NAME
undef TOP_N
clear break
clear compute

