set linesize 220 verif off
set pagesize 100
compute sum of MB on report
compute sum of FREE_MB on report
compute sum of LOB_DATA_MB on report
break on report
col owner form A10
col segment_name form A50
col segment_type form A15
col mb form 999G999G999G999
col free_mb form 999G999G999G999
col lob_data_mb form 999G999G999G999

ACCEPT OWNER PROMPT 'Enter table owner : '
ACCEPT TABLE PROMPT 'Enter table name : '

with function freebytes(
  p_seg_subtype varchar2,
  p_segment_owner varchar2,
  p_segment_name varchar2,
  p_segment_type varchar2,
  p_partition_name varchar2
 ) return number
 as
 unf number;
 unfb number;
 fs1 number;
 fs1b number;
 fs2 number;
 fs2b number;
 fs3 number;
 fs3b number;
 fs4 number;
 fs4b number;
 full number;
 fullb number;
 l_segment_size_blocks number;
 l_segment_size_bytes number;
 l_used_blocks number;
 l_used_bytes number;
 l_expired_blocks number;
 l_expired_bytes number;
 l_unexpired_blocks number;
 l_unexpired_bytes number;
begin
  if p_seg_subtype='ASSM' then
    dbms_space.space_usage(p_segment_owner,p_segment_name,p_segment_type,unf,unfb,fs1,fs1b,fs2,fs2b,fs3,fs3b,fs4,fs4b,full,fullb,partition_name=>p_partition_name);
    return unfb+fs1b+fs2b*0.25+fs3b*0.5+fs4b*0.75;
  elsif p_seg_subtype='SECUREFILE' then
    dbms_space.space_usage(segment_owner =>p_segment_owner,segment_name => p_segment_name,segment_type => p_segment_type,
                           segment_size_blocks => l_segment_size_blocks,
                           segment_size_bytes => l_segment_size_bytes,
                           used_blocks => l_used_blocks,
                           used_bytes => l_used_bytes,
                           expired_blocks => l_expired_blocks,
                           expired_bytes => l_expired_bytes,
                           unexpired_blocks => l_unexpired_blocks,
                           unexpired_bytes => l_unexpired_bytes
    );
    return l_expired_bytes;
  else
    return 0;
  end if;
end;
function lob_size(p_owner varchar2,p_table varchar2,p_column varchar2)
return number
as
l_sql varchar2(1000);
l_bytes number;
begin
  l_sql := 'select sum(dbms_lob.getlength('||dbms_assert.simple_sql_name(p_column)||')) from '||dbms_assert.qualified_sql_name(p_owner||'.'||p_table);
  execute immediate l_sql into l_bytes;
  return l_bytes;
end;   
SELECT
  ds.owner
  ,ds.segment_type
  ,coalesce(ds.partition_name,ds.segment_name) segment_name
  ,Round(ds.bytes/1024/1024) MB
  ,round(freebytes(ds.segment_subtype,ds.owner,ds.segment_name,decode(ds.segment_type,'LOBSEGMENT','LOB',ds.segment_type),ds.partition_name)/1024/1024) free_mb
  --,round(lob_size())/1024/1024) data_size_mb
  ,0 lob_data_mb
FROM dba_segments ds, dba_tables dt
WHERE dt.owner = '&&OWNER'
  AND dt.table_name = '&&TABLE'
  AND dt.table_name=ds.segment_name
  AND dt.owner=ds.owner
UNION ALL
SELECT
  ds.owner
  ,ds.segment_type
  ,coalesce(ds.partition_name,ds.segment_name)
  ,Round(ds.bytes/1024/1024) MB
  ,round(freebytes(ds.segment_subtype,ds.owner,ds.segment_name,decode(ds.segment_type,'LOBSEGMENT','LOB','LOBINDEX','INDEX',ds.segment_type),ds.partition_name)/1024/1024) free_mb
  --,0 as free_mb
  ,0
FROM dba_segments ds, dba_indexes di
WHERE di.table_owner = '&&OWNER'
  AND di.table_name = '&&TABLE'
  AND di.index_name=ds.segment_name
  AND di.owner=ds.owner
UNION ALL
SELECT
  ds.owner
  ,ds.segment_type
  ,coalesce(ds.partition_name,ds.segment_name)|| '['||dl.column_name||'] '
  ,Round(ds.bytes/1024/1024) MB
  ,round(freebytes(ds.segment_subtype,ds.owner,ds.segment_name,decode(ds.segment_type,'LOBSEGMENT','LOB',ds.segment_type),ds.partition_name)/1024/1024) free_mb
  ,round(lob_size(dl.owner,dl.table_name,dl.column_name)/1024/1024) lob_data_mb
FROM dba_segments ds, dba_lobs dl, dba_tab_columns dtc
WHERE dl.owner = '&&OWNER'
  AND dl.table_name = '&&TABLE'
  AND dl.segment_name=ds.segment_name
  AND dl.owner=ds.owner
  and dtc.owner=dl.owner
  and dtc.table_name=dl.table_name
  and dtc.column_name=dl.column_name
  and dtc.data_type not in('ANYDATA')
ORDER BY 4 DESC
/


undef table owner
clear breaks
clear computes

