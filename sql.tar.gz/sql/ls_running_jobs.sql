set linesize 240 pagesize 1000
col sid_serial form A12
col job_ form A30
col elapsed_time form A20
col cpu_used form A20
col pname form A5
col spid form A5
col module form A35
col action form A35
col sql_id form A13 




select
  s.sid||','||s.serial# sid_serial
  ,drj.owner||'.'||drj.job_name job_
  ,drj.elapsed_time
  ,drj.cpu_used
  ,p.pname
  ,p.spid
  ,s.module
  ,s.action
  ,s.sql_id
from v$scheduler_running_jobs rj
  ,v$session s
  ,v$process p
  ,dba_objects obj
  ,dba_scheduler_running_jobs drj
where rj.session_id=s.sid
  and rj.session_serial_num=s.serial#
  and rj.job_id=obj.object_id
  and obj.owner=drj.owner
  and obj.object_name=drj.job_name
  and s.paddr=p.addr
order by job_;


