set line 240 pagesize 100
col owner form A8
col directory_name form A40
col directory_path form A140
set verify off


accept dirname prompt 'Enter directory name pattern (default: %): ' default '%'
accept dirpath prompt 'Enter directory path pattern (default: %): ' default '%'

select owner,directory_name,directory_path
from dba_directories
where (directory_name like trim('&dirname') or trim('&dirname') = '%')
and (directory_path like trim('&dirpath') or trim('&dirpath') = '%')
order by owner,directory_name;

