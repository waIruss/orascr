set line 250 pagesize 1000 verify off
col sid form A16
col hostname form A22
col updated form A18
col pathname form A30
col size_gb form 999G990D00 heading "Size GB"
col used_gb form 999G990D00 heading "Used GB"
col free_gb form 999G990D00 heading "Free GB"
col pct_used form 990D09 heading "% Used"
col app form A10



accept sidpattern prompt 'Enter DB SID pattern (default: %): ' default '%'
accept hostpattern prompt 'Enter SERVER pattern (default: %): ' default '%'
accept pathpattern prompt 'Enter FS/ASMDG pattern (default: %): ' default '%'
accept gencsv prompt 'Save output to CSV? [Y/N] (default: N): ' default 'N'

col spool_csv new_value spool_csv noprint
col csv_dest new_value csv_dest noprint
col spool_csv_end new_value spool_csv_end noprint
col feedb_  new_val feedb_ noprint
select
  decode(upper(trim('&gencsv')),'Y',' markup csv on',' markup csv off') spool_csv ,
  decode(upper(trim('&gencsv')),'Y',' feedback off',' feedback on') feedb_,
  decode(upper(trim('&gencsv')),'Y','oem_storage_report_'||to_char(sysdate,'YYYYMMDD')||'.csv','/dev/null') csv_dest
from dual;

set &feedb_
set &spool_csv
spool &csv_dest

select v.* ,
  case 
    when upper(sid) like '%ACP%' then 'ACP'
    when upper(sid) like '%AFP%' then 'AFP'
    when upper(sid) like '%CCM%' then 'CCM'
    when upper(sid) like '%LFR%' then 'LFR'
    when upper(sid) like '%TS%' then 'FIXBRIDGE'
    else 'OTHER'
  end app
from (
SELECT REPLACE(x1.TARGET_NAME, '.apobank.lan', '') AS SID
        ,REPLACE(UPPER(x3.TARGET_NAME), '.APOBANK.LAN', '') AS Hostname
  ,to_char(x3.COLLECTION_TIMESTAMP,'YYYY-MM-DD HH24:MI') AS Updated
        ,x3.KEY_VALUE AS Pathname
        ,TRUNC(COALESCE(TO_NUMBER(x6.VALUE - x5.VALUE), TO_NUMBER(x9.AVERAGE - x8.AVERAGE)) / 1024, 2) AS used_gb
        ,TRUNC(100 - COALESCE(TO_NUMBER(x4.VALUE), TO_NUMBER(x7.AVERAGE)), 2) AS pct_used
        ,TRUNC(COALESCE(TO_NUMBER(x5.VALUE), TO_NUMBER(x8.AVERAGE)) / 1024, 2) AS free_gb
        ,TRUNC(COALESCE(TO_NUMBER(x6.VALUE), TO_NUMBER(x9.AVERAGE)) / 1024, 2) AS size_gb
        --,'GB' AS Unit
FROM SYSMAN.MGMT_TARGETS x1
LEFT JOIN SYSMAN.MGMT_TARGETS x2 ON x1.HOST_NAME = x2.HOST_NAME
        AND x2.TARGET_TYPE = 'host'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x3 ON x2.TARGET_GUID = x3.TARGET_GUID
        AND x3.METRIC_COLUMN = 'fileSystem'
        AND x3.TARGET_TYPE = 'host'
        AND x3.METRIC_NAME = 'Filesystems'
        AND x3.KEY_VALUE LIKE '/oracle%'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x4 ON x3.TARGET_GUID = x4.TARGET_GUID
        AND x3.KEY_VALUE = x4.KEY_VALUE
        AND x4.METRIC_COLUMN = 'pctAvailable'
        AND x4.TARGET_TYPE = 'host'
        AND x4.METRIC_NAME = 'Filesystems'
        AND x4.KEY_VALUE LIKE '/oracle%'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x5 ON x3.TARGET_GUID = x5.TARGET_GUID
        AND x3.KEY_VALUE = x5.KEY_VALUE
        AND x5.METRIC_COLUMN = 'available'
        AND x5.TARGET_TYPE = 'host'
        AND x5.METRIC_NAME = 'Filesystems'
        AND x5.KEY_VALUE LIKE '/oracle%'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x6 ON x3.TARGET_GUID = x6.TARGET_GUID
        AND x3.KEY_VALUE = x6.KEY_VALUE
        AND x6.METRIC_COLUMN = 'size'
        AND x6.TARGET_TYPE = 'host'
        AND x6.METRIC_NAME = 'Filesystems'
        AND x6.KEY_VALUE LIKE '/oracle%'
LEFT JOIN (
        SELECT TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,ROLLUP_TIMESTAMP
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        FROM SYSMAN."MGMT$METRIC_DAILY" y1
        WHERE METRIC_COLUMN = 'pctAvailable'
                AND TARGET_TYPE = 'host'
                AND METRIC_NAME = 'Filesystems'
                AND KEY_VALUE LIKE '/oracle%'
        GROUP BY ROLLUP_TIMESTAMP
                ,TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        HAVING ROLLUP_TIMESTAMP = (
                        SELECT MAX(ROLLUP_TIMESTAMP)
                        FROM SYSMAN."MGMT$METRIC_DAILY" y2
                        WHERE y1.TARGET_GUID = y2.TARGET_GUID
                                AND METRIC_COLUMN = 'pctAvailable'
                                AND TARGET_TYPE = 'host'
                                AND METRIC_NAME = 'Filesystems'
                                AND KEY_VALUE LIKE '/oracle%'
                        )
        ORDER BY ROLLUP_TIMESTAMP
        ) x7 ON x3.TARGET_GUID = x7.TARGET_GUID
        AND x3.KEY_VALUE = x7.KEY_VALUE
LEFT JOIN (
        SELECT TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,ROLLUP_TIMESTAMP
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        FROM SYSMAN."MGMT$METRIC_DAILY" y3
        WHERE METRIC_COLUMN = 'available'
                AND TARGET_TYPE = 'host'
                AND METRIC_NAME = 'Filesystems'
                AND KEY_VALUE LIKE '/oracle%'
        GROUP BY ROLLUP_TIMESTAMP
                ,TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        HAVING ROLLUP_TIMESTAMP = (
                        SELECT MAX(ROLLUP_TIMESTAMP)
                        FROM SYSMAN."MGMT$METRIC_DAILY" y4
                        WHERE y3.TARGET_GUID = y4.TARGET_GUID
                                AND METRIC_COLUMN = 'available'
                                AND TARGET_TYPE = 'host'
                                AND METRIC_NAME = 'Filesystems'
                                AND KEY_VALUE LIKE '/oracle%'
                        )
        ORDER BY ROLLUP_TIMESTAMP
        ) x8 ON x3.TARGET_GUID = x8.TARGET_GUID
        AND x3.KEY_VALUE = x8.KEY_VALUE
LEFT JOIN (
        SELECT TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,ROLLUP_TIMESTAMP
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        FROM SYSMAN."MGMT$METRIC_DAILY" y5
        WHERE METRIC_COLUMN = 'size'
                AND TARGET_TYPE = 'host'
                AND METRIC_NAME = 'Filesystems'
                AND KEY_VALUE LIKE '/oracle%'
        GROUP BY ROLLUP_TIMESTAMP
                ,TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        HAVING ROLLUP_TIMESTAMP = (
                        SELECT MAX(ROLLUP_TIMESTAMP)
                        FROM SYSMAN."MGMT$METRIC_DAILY" y6
                        WHERE y5.TARGET_GUID = y6.TARGET_GUID
                                AND METRIC_COLUMN = 'size'
                                AND TARGET_TYPE = 'host'
                                AND METRIC_NAME = 'Filesystems'
                                AND KEY_VALUE LIKE '/oracle%'
                        )
        ORDER BY ROLLUP_TIMESTAMP
        ) x9 ON x3.TARGET_GUID = x9.TARGET_GUID
        AND x3.KEY_VALUE = x9.KEY_VALUE
WHERE x1.TARGET_TYPE = 'oracle_database'
UNION ALL
SELECT REPLACE(x2.TARGET_NAME, '.apobank.lan', '') AS SID
        ,REPLACE(UPPER(x1.HOST_NAME), '.APOBANK.LAN', '') AS Hostname
        ,to_char(x3.COLLECTION_TIMESTAMP,'YYYY-MM-DD HH24:MI') AS Updated
        ,x3.KEY_VALUE AS Pathname
        ,TRUNC(COALESCE(TO_NUMBER(x6.VALUE - x5.VALUE), TO_NUMBER(x9.AVERAGE - x8.AVERAGE)) / 1024, 2) AS Used_space
        ,TRUNC(COALESCE(TO_NUMBER(x4.VALUE), TO_NUMBER(x7.AVERAGE)), 2) AS Used_percent_space
        ,TRUNC(COALESCE(TO_NUMBER(x5.VALUE), TO_NUMBER(x8.AVERAGE)) / 1024, 2) AS Free_space
        ,TRUNC(COALESCE(TO_NUMBER(x6.VALUE), TO_NUMBER(x9.AVERAGE)) / 1024, 2) AS Total_space
        --,'GB' AS Unit
FROM SYSMAN.MGMT_TARGETS x1
LEFT JOIN SYSMAN.MGMT_TARGETS x2 ON x1.HOST_NAME = x2.HOST_NAME
        AND x2.TARGET_TYPE = 'oracle_database'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x3 ON x1.TARGET_GUID = x3.TARGET_GUID
        AND x3.METRIC_COLUMN = 'type'
        AND x3.TARGET_TYPE = 'osm_instance'
        AND x3.METRIC_NAME = 'DiskGroup_Usage'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x4 ON x3.TARGET_GUID = x4.TARGET_GUID
        AND x3.KEY_VALUE = x4.KEY_VALUE
        AND x4.METRIC_COLUMN = 'percent_used'
        AND x4.TARGET_TYPE = 'osm_instance'
        AND x4.METRIC_NAME = 'DiskGroup_Usage'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x5 ON x3.TARGET_GUID = x5.TARGET_GUID
        AND x3.KEY_VALUE = x5.KEY_VALUE
        AND x5.METRIC_COLUMN = 'free_mb'
        AND x5.TARGET_TYPE = 'osm_instance'
        AND x5.METRIC_NAME = 'DiskGroup_Usage'
LEFT JOIN SYSMAN."MGMT$METRIC_CURRENT" x6 ON x3.TARGET_GUID = x6.TARGET_GUID
        AND x3.KEY_VALUE = x6.KEY_VALUE
        AND x6.METRIC_COLUMN = 'total_mb'
        AND x6.TARGET_TYPE = 'osm_instance'
        AND x6.METRIC_NAME = 'DiskGroup_Usage'
LEFT JOIN (
        SELECT TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,ROLLUP_TIMESTAMP
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        FROM SYSMAN."MGMT$METRIC_DAILY" y1
        WHERE METRIC_COLUMN = 'percent_used'
                AND TARGET_TYPE = 'osm_instance'
                AND METRIC_NAME = 'DiskGroup_Usage'
        GROUP BY ROLLUP_TIMESTAMP
                ,TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        HAVING ROLLUP_TIMESTAMP = (
                        SELECT MAX(ROLLUP_TIMESTAMP)
                        FROM SYSMAN."MGMT$METRIC_DAILY" y2
                        WHERE y1.TARGET_GUID = y2.TARGET_GUID
                                AND METRIC_COLUMN = 'percent_used'
                                AND TARGET_TYPE = 'osm_instance'
                                AND METRIC_NAME = 'DiskGroup_Usage'
                        )
        ORDER BY ROLLUP_TIMESTAMP
        ) x7 ON x3.TARGET_GUID = x7.TARGET_GUID
        AND x3.KEY_VALUE = x7.KEY_VALUE
LEFT JOIN (
        SELECT TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,ROLLUP_TIMESTAMP
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        FROM SYSMAN."MGMT$METRIC_DAILY" y3
        WHERE METRIC_COLUMN = 'free_mb'
                AND TARGET_TYPE = 'osm_instance'
                AND METRIC_NAME = 'DiskGroup_Usage'
        GROUP BY ROLLUP_TIMESTAMP
                ,TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        HAVING ROLLUP_TIMESTAMP = (
                        SELECT MAX(ROLLUP_TIMESTAMP)
                        FROM SYSMAN."MGMT$METRIC_DAILY" y4
                        WHERE y3.TARGET_GUID = y4.TARGET_GUID
                                AND METRIC_COLUMN = 'free_mb'
                                AND TARGET_TYPE = 'osm_instance'
                                AND METRIC_NAME = 'DiskGroup_Usage'
                        )
        ORDER BY ROLLUP_TIMESTAMP
        ) x8 ON x3.TARGET_GUID = x8.TARGET_GUID
        AND x3.KEY_VALUE = x8.KEY_VALUE
LEFT JOIN (
        SELECT TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,ROLLUP_TIMESTAMP
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        FROM SYSMAN."MGMT$METRIC_DAILY" y5
        WHERE METRIC_COLUMN = 'total_mb'
                AND TARGET_TYPE = 'osm_instance'
                AND METRIC_NAME = 'DiskGroup_Usage'
        GROUP BY ROLLUP_TIMESTAMP
                ,TARGET_NAME
                ,KEY_VALUE
                ,TARGET_GUID
                ,METRIC_COLUMN
                ,METRIC_NAME
                ,AVERAGE
        HAVING ROLLUP_TIMESTAMP = (
                        SELECT MAX(ROLLUP_TIMESTAMP)
                        FROM SYSMAN."MGMT$METRIC_DAILY" y6
                        WHERE y5.TARGET_GUID = y6.TARGET_GUID
                                AND METRIC_COLUMN = 'total_mb'
                                AND TARGET_TYPE = 'osm_instance'
                                AND METRIC_NAME = 'DiskGroup_Usage'
                        )
        ORDER BY ROLLUP_TIMESTAMP
        ) x9 ON x3.TARGET_GUID = x9.TARGET_GUID
        AND x3.KEY_VALUE = x9.KEY_VALUE
WHERE x1.TARGET_TYPE = 'osm_instance'
ORDER BY SID
        ,Pathname
) v where sid like upper('&sidpattern')
   and upper(hostname) like upper('&hostpattern')
   and upper(pathname) like upper('&pathpattern')
;

spool off
set markup csv off

set feedback off
select
  decode(upper(trim('&gencsv')),'Y','oem_storage_report_'||to_char(sysdate,'YYYYMMDD')||'.csv','No report saved') output_report
from dual;
set feedback on

undef gencsv
undef pathpattern
undef hostpattern
undef sidpattern
undef spool_csv
undef csv_dest
undef feedb_


