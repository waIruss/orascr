set verify off
def sql_id="&1"

col sql_id form A13
col sql_exec_id form 9999999999
col sql_exec_start form A20
col elapsed form A14
col bind_name form A20
col pos form 99
col data_type form A12
col len form 999
col bind_val form A30
set line 250 pagesize 200
break on sql_id on sql_exec_id on sql_exec_start on elapsed skip 1

with m as (
SELECT
  sm.sql_id,
  sm.sql_exec_id,
  sm.sql_exec_start,
  Round(elapsed_time/1000000,1) elapsed_sec,
  bs.bind_name,bs.pos,bs.dty,bs.dtystr,bs.len,
  CASE
    WHEN bs.dty=180 THEN --decode hex timestamp values
      to_char(dbms_stats.convert_raw_to_date(bs.bval),'SYYYY-MM-DD HH24:MI')
    ELSE
      bs.bval
  END bind_val
  ,row_number() over (partition by sql_id order by elapsed_time desc nulls last) rn
FROM v$sql_monitor sm,
xmltable('for $i in /binds/bind return $i' passing xmltype(sm.binds_xml)
          COLUMNS
            bind_name    VARCHAR2(30)  path '@name',
            pos     NUMBER        path '@pos',
            dty     NUMBER        path '@dty',
            dtystr  VARCHAR2(30)  path '@dtystr',
            len     NUMBER        path '@len',
            bval    VARCHAR2(100)  path 'text()'
        ) bs
WHERE sm.sql_id=trim('&sql_id') --AND sm.binds_xml IS NOT NULL
)
select sql_id, sql_exec_id
  , to_char(sql_exec_start,'YYYY-MM-DD HH24:MI:SS') sql_exec_start
  , cast(numtodsinterval(elapsed_sec,'SECOND') as interval day(1) to second(0)) elapsed
  , bind_name
  , pos
  --, dty
  , dtystr as data_type
  , len
  , bind_val
  --,rn 
from m
where rn <=100
order by elapsed_sec desc,sql_exec_id,pos asc; 

