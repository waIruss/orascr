define report_name = '/tmp/ashrpt.html';
define report_type = 'html';   -- or 'text' for TEXT
define begin_time  = '02/06 11:00:00';  --MM/DD HH24:Mi:SS
define end_time = '02/07 12:04';

column date_diff new_value vmins

select (to_date('&end_time','MM/DD HH24:Mi:ss') - to_date('&begin_time','MM/DD HH24:Mi:ss'))*24*60 date_diff from dual;

define duration    = '&vmins';      -- mins
define dbid        = '';       -- NULL defaults to current database
define inst_num    = '';       -- NULL defaults to current instance
define target_session_id   = '';
define target_sql_id       = '';
define target_wait_class   = '';
define target_service_hash = '';
define target_module_name  = '';
define target_action_name  = '';
define target_client_id    = '';
define target_plsql_entry  = '';
define slot_width          = '';
define target_container    = '';

alter session set optimizer_index_caching=0;
alter session set optimizer_index_cost_adj=100;
alter session set db_file_multiblock_read_count=128;

@?/rdbms/admin/ashrpti.sql

