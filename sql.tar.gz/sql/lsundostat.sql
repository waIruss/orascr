set line 250 pagesize 300
set verify off
set termout off
def DT_FMT_ISO_S="YYYY-MM-DD"

col day new_val day noprint
col host new_val host noprint
col inst_name new_val inst_name noprint
select to_char(sysdate-1,'&DT_FMT_ISO_S') day,host_name as host,instance_name as inst_name from v$instance;
set termout on
set feedback on

ACCEPT day  DEFAULT '&day'  PROMPT 'Enter date as &&DT_FMT_ISO_S [&day]: '
ACCEPT days  DEFAULT '2'  PROMPT 'Number of days to show [2]: '

col tsname form A10
col end_time form A16
col maxquerylen form 999G999 heading "Max|querylen"
col maxquerysqlid form A13 heading "Maxquery|sql_id"
col ssolderrcnt form 99G999 heading "ORA-1555"
col nospaceerrcnt form 99G999 heading "ORA-30036"
col active_gb form 990D00 heading "Active|GB"
col unexp_gb form 990D00 heading "Unexp|GB"
col total_gb form 990D00 heading "Total|GB"
col tuned_undoretention form 999G999 heading "Tuned|undoret"
col max_gb form 990D00 heading "Max GB"
col pct_max form 990D00 heading "% Used| max"
col pct_graph form A100

select t.tablespace_name tsname
   ,to_char(end_time,'YYYY-MM-DD HH24:MI') end_time
   ,maxquerylen,maxquerysqlid
   ,ssolderrcnt, nospaceerrcnt
   ,round(activeblks*block_size/1024/1024/1024,2) active_gb
   ,round(unexpiredblks*block_size/1024/1024/1024,2) unexp_gb
   ,round((activeblks+unexpiredblks)*block_size/1024/1024/1024,2) total_gb
   ,tuned_undoretention
   ,max_gb
   ,round((activeblks+unexpiredblks)*block_size/1024/1024/1024/max_gb*100,2) pct_max
   ,rpad(' ',round((activeblks+unexpiredblks)*block_size/1024/1024/1024/max_gb*100),'*') pct_graph
from dba_hist_undostat u, dba_tablespaces t, v$tablespace vt
   ,(select df.tablespace_name,round(sum(maxbytes)/1024/1024/1024,2) max_gb from dba_data_files df, dba_tablespaces t where df.tablespace_name=t.tablespace_name and t.contents='UNDO' group by df.tablespace_name) df
where u.undotsn=vt.ts#
   and vt.name=t.tablespace_name
   and df.tablespace_name=vt.name
   and begin_time >= to_date('&day','&DT_FMT_ISO_S')
   and end_time <= to_date('&day','&DT_FMT_ISO_S')+&days
order by end_time;

col day clear
col host clear
col inst_name clear

