-----------------------------------------------------------------------------------
-- Script will check if tablespace size can be reduced 
-- If there is unallocated space at the end of datafile, the script will display command to shrink that datafile
-- Usage: @check_tbs_shrink.sql <TBS_NAME>
-----------------------------------------------------------------------------------
set line 200 pagesize 100
set verify off
col cmd_to_resize form A60
compute sum of free_gb_eof on report
break on report
def TBS_NAME=&1

with dbf as (
select /* */ tablespace_name,file_id,block_size,bytes,maxbytes,blocks from dba_data_files dbf join dba_tablespaces dt using(tablespace_name) where tablespace_name=upper(trim('&TBS_NAME'))
),ext as(
select /* */ tablespace_name,file_id,max(block_id+blocks) last_used_block from dba_extents where tablespace_name=upper(trim('&TBS_NAME')) group by tablespace_name,file_id
), fb as (
select  /* */ tablespace_name,file_id,sum(bytes) free_bytes from dba_free_space where tablespace_name=upper(trim('&TBS_NAME')) group by tablespace_name,file_id --having sum(bytes) > power(1024,3)*10
), det1 as (
select
  dbf.tablespace_name
  , dbf.file_id
  , block_size
  , bytes
  , maxbytes
  , blocks
  , round(nvl(free_bytes/1024/1024/1024,0),2) free_gb
  , free_bytes/bytes free_pct
from dbf join fb on(dbf.tablespace_name=fb.tablespace_name and dbf.file_id=fb.file_id)
)
select /*+ first_rows(1) leading(det1) */
  det1.tablespace_name
  ,det1.file_id
  ,round(bytes/1024/1024/1024,2) size_gb
  ,round(maxbytes/1024/1024/1024,2) maxsize_gb
  ,free_gb
  ,round(free_pct,2) free_pct
  , floor((blocks - nvl(last_used_block,0))*block_size/1024/1024/1024) free_gb_eof
  , case when floor((blocks - nvl(last_used_block,0))*block_size/1024/1024/1024) > 1 then ceil(round(bytes/1024/1024/1024,2) - floor((blocks - nvl(last_used_block,0))*block_size/1024/1024/1024))
    else null
    end new_size
  ,case when floor((blocks - nvl(last_used_block,0))*block_size/1024/1024/1024) > 1
    then 'alter database datafile '||det1.file_id||' resize '||ceil(round(bytes/1024/1024/1024,2) - floor((blocks - nvl(last_used_block,0))*block_size/1024/1024/1024))||'G;'
    else '-- resize not feasible'
    end cmd_to_resize
from det1, ext
where det1.tablespace_name=ext.tablespace_name
  and det1.file_id=ext.file_id
  --and det1.free_pct > .1
order by free_gb_eof
;

undef 1
undef tbs_name

clear break
clear compute
